/**
 */
package mobilityResources;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Route</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mobilityResources.Route#getLong_name <em>Long name</em>}</li>
 *   <li>{@link mobilityResources.Route#getAgency <em>Agency</em>}</li>
 *   <li>{@link mobilityResources.Route#getDesc <em>Desc</em>}</li>
 *   <li>{@link mobilityResources.Route#getType <em>Type</em>}</li>
 *   <li>{@link mobilityResources.Route#getUrl <em>Url</em>}</li>
 *   <li>{@link mobilityResources.Route#getTrips <em>Trips</em>}</li>
 *   <li>{@link mobilityResources.Route#getFare_rules <em>Fare rules</em>}</li>
 * </ul>
 *
 * @see mobilityResources.MobilityResourcesPackage#getRoute()
 * @model
 * @generated
 */
public interface Route extends MobilityResource {
	/**
	 * Returns the value of the '<em><b>Long name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Long name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Long name</em>' attribute.
	 * @see #setLong_name(String)
	 * @see mobilityResources.MobilityResourcesPackage#getRoute_Long_name()
	 * @model
	 * @generated
	 */
	String getLong_name();

	/**
	 * Sets the value of the '{@link mobilityResources.Route#getLong_name <em>Long name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Long name</em>' attribute.
	 * @see #getLong_name()
	 * @generated
	 */
	void setLong_name(String value);

	/**
	 * Returns the value of the '<em><b>Agency</b></em>' reference list.
	 * The list contents are of type {@link mobilityResources.Agency}.
	 * It is bidirectional and its opposite is '{@link mobilityResources.Agency#getRoutes <em>Routes</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Agency</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Agency</em>' reference list.
	 * @see mobilityResources.MobilityResourcesPackage#getRoute_Agency()
	 * @see mobilityResources.Agency#getRoutes
	 * @model opposite="routes"
	 * @generated
	 */
	EList<Agency> getAgency();

	/**
	 * Returns the value of the '<em><b>Desc</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Desc</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Desc</em>' attribute.
	 * @see #setDesc(String)
	 * @see mobilityResources.MobilityResourcesPackage#getRoute_Desc()
	 * @model
	 * @generated
	 */
	String getDesc();

	/**
	 * Sets the value of the '{@link mobilityResources.Route#getDesc <em>Desc</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Desc</em>' attribute.
	 * @see #getDesc()
	 * @generated
	 */
	void setDesc(String value);

	/**
	 * Returns the value of the '<em><b>Type</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link mobilityResources.Transit#getRoute <em>Route</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Type</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' reference.
	 * @see #setType(Transit)
	 * @see mobilityResources.MobilityResourcesPackage#getRoute_Type()
	 * @see mobilityResources.Transit#getRoute
	 * @model opposite="route"
	 * @generated
	 */
	Transit getType();

	/**
	 * Sets the value of the '{@link mobilityResources.Route#getType <em>Type</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' reference.
	 * @see #getType()
	 * @generated
	 */
	void setType(Transit value);

	/**
	 * Returns the value of the '<em><b>Url</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Url</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Url</em>' attribute.
	 * @see #setUrl(String)
	 * @see mobilityResources.MobilityResourcesPackage#getRoute_Url()
	 * @model
	 * @generated
	 */
	String getUrl();

	/**
	 * Sets the value of the '{@link mobilityResources.Route#getUrl <em>Url</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Url</em>' attribute.
	 * @see #getUrl()
	 * @generated
	 */
	void setUrl(String value);

	/**
	 * Returns the value of the '<em><b>Trips</b></em>' reference list.
	 * The list contents are of type {@link mobilityResources.Trip}.
	 * It is bidirectional and its opposite is '{@link mobilityResources.Trip#getRoute <em>Route</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Trips</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Trips</em>' reference list.
	 * @see mobilityResources.MobilityResourcesPackage#getRoute_Trips()
	 * @see mobilityResources.Trip#getRoute
	 * @model opposite="route"
	 * @generated
	 */
	EList<Trip> getTrips();

	/**
	 * Returns the value of the '<em><b>Fare rules</b></em>' reference list.
	 * The list contents are of type {@link mobilityResources.Fare_rule}.
	 * It is bidirectional and its opposite is '{@link mobilityResources.Fare_rule#getRoute <em>Route</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Fare rules</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Fare rules</em>' reference list.
	 * @see mobilityResources.MobilityResourcesPackage#getRoute_Fare_rules()
	 * @see mobilityResources.Fare_rule#getRoute
	 * @model opposite="route"
	 * @generated
	 */
	EList<Fare_rule> getFare_rules();

} // Route
