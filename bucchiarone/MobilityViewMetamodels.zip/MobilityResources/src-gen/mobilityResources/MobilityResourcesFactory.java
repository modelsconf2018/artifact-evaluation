/**
 */
package mobilityResources;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see mobilityResources.MobilityResourcesPackage
 * @generated
 */
public interface MobilityResourcesFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	MobilityResourcesFactory eINSTANCE = mobilityResources.impl.MobilityResourcesFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Mobility Support</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Mobility Support</em>'.
	 * @generated
	 */
	MobilitySupport createMobilitySupport();

	/**
	 * Returns a new object of class '<em>Parking</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Parking</em>'.
	 * @generated
	 */
	Parking createParking();

	/**
	 * Returns a new object of class '<em>Bike Sharing</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Bike Sharing</em>'.
	 * @generated
	 */
	BikeSharing createBikeSharing();

	/**
	 * Returns a new object of class '<em>Geographic Location</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Geographic Location</em>'.
	 * @generated
	 */
	GeographicLocation createGeographicLocation();

	/**
	 * Returns a new object of class '<em>Agency</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Agency</em>'.
	 * @generated
	 */
	Agency createAgency();

	/**
	 * Returns a new object of class '<em>Transit</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Transit</em>'.
	 * @generated
	 */
	Transit createTransit();

	/**
	 * Returns a new object of class '<em>Stop</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Stop</em>'.
	 * @generated
	 */
	Stop createStop();

	/**
	 * Returns a new object of class '<em>Route</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Route</em>'.
	 * @generated
	 */
	Route createRoute();

	/**
	 * Returns a new object of class '<em>Trip</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Trip</em>'.
	 * @generated
	 */
	Trip createTrip();

	/**
	 * Returns a new object of class '<em>Calendar</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Calendar</em>'.
	 * @generated
	 */
	Calendar createCalendar();

	/**
	 * Returns a new object of class '<em>Block</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Block</em>'.
	 * @generated
	 */
	Block createBlock();

	/**
	 * Returns a new object of class '<em>Stop time</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Stop time</em>'.
	 * @generated
	 */
	Stop_time createStop_time();

	/**
	 * Returns a new object of class '<em>Calendar date</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Calendar date</em>'.
	 * @generated
	 */
	Calendar_date createCalendar_date();

	/**
	 * Returns a new object of class '<em>Fare attribute</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Fare attribute</em>'.
	 * @generated
	 */
	Fare_attribute createFare_attribute();

	/**
	 * Returns a new object of class '<em>Fare rule</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Fare rule</em>'.
	 * @generated
	 */
	Fare_rule createFare_rule();

	/**
	 * Returns a new object of class '<em>Zone</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Zone</em>'.
	 * @generated
	 */
	Zone createZone();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	MobilityResourcesPackage getMobilityResourcesPackage();

} //MobilityResourcesFactory
