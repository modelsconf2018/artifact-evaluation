/**
 */
package mobilityResources;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Transit Type</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see mobilityResources.MobilityResourcesPackage#getTransitType()
 * @model
 * @generated
 */
public enum TransitType implements Enumerator {
	/**
	 * The '<em><b>Light Rail</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #LIGHT_RAIL_VALUE
	 * @generated
	 * @ordered
	 */
	LIGHT_RAIL(0, "Light_Rail", "Light_Rail"),

	/**
	 * The '<em><b>Subway</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SUBWAY_VALUE
	 * @generated
	 * @ordered
	 */
	SUBWAY(1, "Subway", "Subway"),

	/**
	 * The '<em><b>Rail</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #RAIL_VALUE
	 * @generated
	 * @ordered
	 */
	RAIL(2, "Rail", "Rail"),

	/**
	 * The '<em><b>Bus</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #BUS_VALUE
	 * @generated
	 * @ordered
	 */
	BUS(3, "Bus", "Bus"),

	/**
	 * The '<em><b>Ferry</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #FERRY_VALUE
	 * @generated
	 * @ordered
	 */
	FERRY(4, "Ferry", "Ferry"),

	/**
	 * The '<em><b>Cable Car</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CABLE_CAR_VALUE
	 * @generated
	 * @ordered
	 */
	CABLE_CAR(5, "Cable_Car", "Cable_Car"),

	/**
	 * The '<em><b>Suspended Cable Car</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SUSPENDED_CABLE_CAR_VALUE
	 * @generated
	 * @ordered
	 */
	SUSPENDED_CABLE_CAR(6, "Suspended_Cable_Car", "Suspended_Cable_Car"),

	/**
	 * The '<em><b>Funicolar</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #FUNICOLAR_VALUE
	 * @generated
	 * @ordered
	 */
	FUNICOLAR(7, "Funicolar", "Funicolar");

	/**
	 * The '<em><b>Light Rail</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Light Rail</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #LIGHT_RAIL
	 * @model name="Light_Rail"
	 * @generated
	 * @ordered
	 */
	public static final int LIGHT_RAIL_VALUE = 0;

	/**
	 * The '<em><b>Subway</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Subway</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #SUBWAY
	 * @model name="Subway"
	 * @generated
	 * @ordered
	 */
	public static final int SUBWAY_VALUE = 1;

	/**
	 * The '<em><b>Rail</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Rail</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #RAIL
	 * @model name="Rail"
	 * @generated
	 * @ordered
	 */
	public static final int RAIL_VALUE = 2;

	/**
	 * The '<em><b>Bus</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Bus</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #BUS
	 * @model name="Bus"
	 * @generated
	 * @ordered
	 */
	public static final int BUS_VALUE = 3;

	/**
	 * The '<em><b>Ferry</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Ferry</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #FERRY
	 * @model name="Ferry"
	 * @generated
	 * @ordered
	 */
	public static final int FERRY_VALUE = 4;

	/**
	 * The '<em><b>Cable Car</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Cable Car</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #CABLE_CAR
	 * @model name="Cable_Car"
	 * @generated
	 * @ordered
	 */
	public static final int CABLE_CAR_VALUE = 5;

	/**
	 * The '<em><b>Suspended Cable Car</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Suspended Cable Car</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #SUSPENDED_CABLE_CAR
	 * @model name="Suspended_Cable_Car"
	 * @generated
	 * @ordered
	 */
	public static final int SUSPENDED_CABLE_CAR_VALUE = 6;

	/**
	 * The '<em><b>Funicolar</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Funicolar</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #FUNICOLAR
	 * @model name="Funicolar"
	 * @generated
	 * @ordered
	 */
	public static final int FUNICOLAR_VALUE = 7;

	/**
	 * An array of all the '<em><b>Transit Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final TransitType[] VALUES_ARRAY = new TransitType[] { LIGHT_RAIL, SUBWAY, RAIL, BUS, FERRY,
			CABLE_CAR, SUSPENDED_CABLE_CAR, FUNICOLAR, };

	/**
	 * A public read-only list of all the '<em><b>Transit Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<TransitType> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Transit Type</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param literal the literal.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static TransitType get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			TransitType result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Transit Type</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param name the name.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static TransitType getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			TransitType result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Transit Type</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the integer value.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static TransitType get(int value) {
		switch (value) {
		case LIGHT_RAIL_VALUE:
			return LIGHT_RAIL;
		case SUBWAY_VALUE:
			return SUBWAY;
		case RAIL_VALUE:
			return RAIL;
		case BUS_VALUE:
			return BUS;
		case FERRY_VALUE:
			return FERRY;
		case CABLE_CAR_VALUE:
			return CABLE_CAR;
		case SUSPENDED_CABLE_CAR_VALUE:
			return SUSPENDED_CABLE_CAR;
		case FUNICOLAR_VALUE:
			return FUNICOLAR;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private TransitType(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getValue() {
		return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLiteral() {
		return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}

} //TransitType
