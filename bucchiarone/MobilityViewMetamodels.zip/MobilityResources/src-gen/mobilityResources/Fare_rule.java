/**
 */
package mobilityResources;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Fare rule</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mobilityResources.Fare_rule#getFare <em>Fare</em>}</li>
 *   <li>{@link mobilityResources.Fare_rule#getRoute <em>Route</em>}</li>
 *   <li>{@link mobilityResources.Fare_rule#getOrigin <em>Origin</em>}</li>
 *   <li>{@link mobilityResources.Fare_rule#getDestination <em>Destination</em>}</li>
 *   <li>{@link mobilityResources.Fare_rule#getContains <em>Contains</em>}</li>
 * </ul>
 *
 * @see mobilityResources.MobilityResourcesPackage#getFare_rule()
 * @model
 * @generated
 */
public interface Fare_rule extends EObject {
	/**
	 * Returns the value of the '<em><b>Fare</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link mobilityResources.Fare_attribute#getFare_rules <em>Fare rules</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Fare</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Fare</em>' reference.
	 * @see #setFare(Fare_attribute)
	 * @see mobilityResources.MobilityResourcesPackage#getFare_rule_Fare()
	 * @see mobilityResources.Fare_attribute#getFare_rules
	 * @model opposite="fare_rules"
	 * @generated
	 */
	Fare_attribute getFare();

	/**
	 * Sets the value of the '{@link mobilityResources.Fare_rule#getFare <em>Fare</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Fare</em>' reference.
	 * @see #getFare()
	 * @generated
	 */
	void setFare(Fare_attribute value);

	/**
	 * Returns the value of the '<em><b>Route</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link mobilityResources.Route#getFare_rules <em>Fare rules</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Route</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Route</em>' reference.
	 * @see #setRoute(Route)
	 * @see mobilityResources.MobilityResourcesPackage#getFare_rule_Route()
	 * @see mobilityResources.Route#getFare_rules
	 * @model opposite="fare_rules"
	 * @generated
	 */
	Route getRoute();

	/**
	 * Sets the value of the '{@link mobilityResources.Fare_rule#getRoute <em>Route</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Route</em>' reference.
	 * @see #getRoute()
	 * @generated
	 */
	void setRoute(Route value);

	/**
	 * Returns the value of the '<em><b>Origin</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link mobilityResources.Zone#getOrigin_fare_rules <em>Origin fare rules</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Origin</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Origin</em>' reference.
	 * @see #setOrigin(Zone)
	 * @see mobilityResources.MobilityResourcesPackage#getFare_rule_Origin()
	 * @see mobilityResources.Zone#getOrigin_fare_rules
	 * @model opposite="origin_fare_rules"
	 * @generated
	 */
	Zone getOrigin();

	/**
	 * Sets the value of the '{@link mobilityResources.Fare_rule#getOrigin <em>Origin</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Origin</em>' reference.
	 * @see #getOrigin()
	 * @generated
	 */
	void setOrigin(Zone value);

	/**
	 * Returns the value of the '<em><b>Destination</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link mobilityResources.Zone#getDestination_fare_rules <em>Destination fare rules</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Destination</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Destination</em>' reference.
	 * @see #setDestination(Zone)
	 * @see mobilityResources.MobilityResourcesPackage#getFare_rule_Destination()
	 * @see mobilityResources.Zone#getDestination_fare_rules
	 * @model opposite="destination_fare_rules"
	 * @generated
	 */
	Zone getDestination();

	/**
	 * Sets the value of the '{@link mobilityResources.Fare_rule#getDestination <em>Destination</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Destination</em>' reference.
	 * @see #getDestination()
	 * @generated
	 */
	void setDestination(Zone value);

	/**
	 * Returns the value of the '<em><b>Contains</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link mobilityResources.Zone#getContains_fare_rules <em>Contains fare rules</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Contains</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Contains</em>' reference.
	 * @see #setContains(Zone)
	 * @see mobilityResources.MobilityResourcesPackage#getFare_rule_Contains()
	 * @see mobilityResources.Zone#getContains_fare_rules
	 * @model opposite="contains_fare_rules"
	 * @generated
	 */
	Zone getContains();

	/**
	 * Sets the value of the '{@link mobilityResources.Fare_rule#getContains <em>Contains</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Contains</em>' reference.
	 * @see #getContains()
	 * @generated
	 */
	void setContains(Zone value);

} // Fare_rule
