/**
 */
package mobilityResources.util;

import mobilityResources.*;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see mobilityResources.MobilityResourcesPackage
 * @generated
 */
public class MobilityResourcesSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static MobilityResourcesPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MobilityResourcesSwitch() {
		if (modelPackage == null) {
			modelPackage = MobilityResourcesPackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
		case MobilityResourcesPackage.MOBILITY_SUPPORT: {
			MobilitySupport mobilitySupport = (MobilitySupport) theEObject;
			T result = caseMobilitySupport(mobilitySupport);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case MobilityResourcesPackage.MOBILITY_RESOURCE: {
			MobilityResource mobilityResource = (MobilityResource) theEObject;
			T result = caseMobilityResource(mobilityResource);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case MobilityResourcesPackage.PARKING: {
			Parking parking = (Parking) theEObject;
			T result = caseParking(parking);
			if (result == null)
				result = caseMobilityResource(parking);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case MobilityResourcesPackage.BIKE_SHARING: {
			BikeSharing bikeSharing = (BikeSharing) theEObject;
			T result = caseBikeSharing(bikeSharing);
			if (result == null)
				result = caseMobilityResource(bikeSharing);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case MobilityResourcesPackage.GEOGRAPHIC_LOCATION: {
			GeographicLocation geographicLocation = (GeographicLocation) theEObject;
			T result = caseGeographicLocation(geographicLocation);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case MobilityResourcesPackage.AGENCY: {
			Agency agency = (Agency) theEObject;
			T result = caseAgency(agency);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case MobilityResourcesPackage.TRANSIT: {
			Transit transit = (Transit) theEObject;
			T result = caseTransit(transit);
			if (result == null)
				result = caseMobilityResource(transit);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case MobilityResourcesPackage.STOP: {
			Stop stop = (Stop) theEObject;
			T result = caseStop(stop);
			if (result == null)
				result = caseMobilityResource(stop);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case MobilityResourcesPackage.ROUTE: {
			Route route = (Route) theEObject;
			T result = caseRoute(route);
			if (result == null)
				result = caseMobilityResource(route);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case MobilityResourcesPackage.TRIP: {
			Trip trip = (Trip) theEObject;
			T result = caseTrip(trip);
			if (result == null)
				result = caseMobilityResource(trip);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case MobilityResourcesPackage.CALENDAR: {
			Calendar calendar = (Calendar) theEObject;
			T result = caseCalendar(calendar);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case MobilityResourcesPackage.BLOCK: {
			Block block = (Block) theEObject;
			T result = caseBlock(block);
			if (result == null)
				result = caseMobilityResource(block);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case MobilityResourcesPackage.STOP_TIME: {
			Stop_time stop_time = (Stop_time) theEObject;
			T result = caseStop_time(stop_time);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case MobilityResourcesPackage.CALENDAR_DATE: {
			Calendar_date calendar_date = (Calendar_date) theEObject;
			T result = caseCalendar_date(calendar_date);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case MobilityResourcesPackage.FARE_ATTRIBUTE: {
			Fare_attribute fare_attribute = (Fare_attribute) theEObject;
			T result = caseFare_attribute(fare_attribute);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case MobilityResourcesPackage.FARE_RULE: {
			Fare_rule fare_rule = (Fare_rule) theEObject;
			T result = caseFare_rule(fare_rule);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case MobilityResourcesPackage.ZONE: {
			Zone zone = (Zone) theEObject;
			T result = caseZone(zone);
			if (result == null)
				result = caseMobilityResource(zone);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		default:
			return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Mobility Support</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Mobility Support</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseMobilitySupport(MobilitySupport object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Mobility Resource</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Mobility Resource</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseMobilityResource(MobilityResource object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Parking</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Parking</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseParking(Parking object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Bike Sharing</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Bike Sharing</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseBikeSharing(BikeSharing object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Geographic Location</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Geographic Location</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseGeographicLocation(GeographicLocation object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Agency</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Agency</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAgency(Agency object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Transit</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Transit</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTransit(Transit object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Stop</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Stop</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseStop(Stop object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Route</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Route</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseRoute(Route object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Trip</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Trip</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTrip(Trip object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Calendar</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Calendar</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCalendar(Calendar object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Block</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Block</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseBlock(Block object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Stop time</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Stop time</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseStop_time(Stop_time object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Calendar date</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Calendar date</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCalendar_date(Calendar_date object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Fare attribute</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Fare attribute</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseFare_attribute(Fare_attribute object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Fare rule</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Fare rule</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseFare_rule(Fare_rule object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Zone</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Zone</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseZone(Zone object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //MobilityResourcesSwitch
