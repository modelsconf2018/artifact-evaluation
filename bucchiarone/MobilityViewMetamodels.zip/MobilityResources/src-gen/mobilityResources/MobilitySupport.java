/**
 */
package mobilityResources;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Mobility Support</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mobilityResources.MobilitySupport#getCity <em>City</em>}</li>
 *   <li>{@link mobilityResources.MobilitySupport#getMobilityresources <em>Mobilityresources</em>}</li>
 *   <li>{@link mobilityResources.MobilitySupport#getGeographicLocations <em>Geographic Locations</em>}</li>
 *   <li>{@link mobilityResources.MobilitySupport#getAgency <em>Agency</em>}</li>
 *   <li>{@link mobilityResources.MobilitySupport#getStop_times <em>Stop times</em>}</li>
 *   <li>{@link mobilityResources.MobilitySupport#getCalendar <em>Calendar</em>}</li>
 *   <li>{@link mobilityResources.MobilitySupport#getCalendar_dates <em>Calendar dates</em>}</li>
 *   <li>{@link mobilityResources.MobilitySupport#getFares <em>Fares</em>}</li>
 *   <li>{@link mobilityResources.MobilitySupport#getFare_zones <em>Fare zones</em>}</li>
 * </ul>
 *
 * @see mobilityResources.MobilityResourcesPackage#getMobilitySupport()
 * @model
 * @generated
 */
public interface MobilitySupport extends EObject {
	/**
	 * Returns the value of the '<em><b>City</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>City</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>City</em>' attribute.
	 * @see #setCity(String)
	 * @see mobilityResources.MobilityResourcesPackage#getMobilitySupport_City()
	 * @model
	 * @generated
	 */
	String getCity();

	/**
	 * Sets the value of the '{@link mobilityResources.MobilitySupport#getCity <em>City</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>City</em>' attribute.
	 * @see #getCity()
	 * @generated
	 */
	void setCity(String value);

	/**
	 * Returns the value of the '<em><b>Mobilityresources</b></em>' containment reference list.
	 * The list contents are of type {@link mobilityResources.MobilityResource}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Mobilityresources</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Mobilityresources</em>' containment reference list.
	 * @see mobilityResources.MobilityResourcesPackage#getMobilitySupport_Mobilityresources()
	 * @model containment="true"
	 * @generated
	 */
	EList<MobilityResource> getMobilityresources();

	/**
	 * Returns the value of the '<em><b>Geographic Locations</b></em>' containment reference list.
	 * The list contents are of type {@link mobilityResources.GeographicLocation}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Geographic Locations</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Geographic Locations</em>' containment reference list.
	 * @see mobilityResources.MobilityResourcesPackage#getMobilitySupport_GeographicLocations()
	 * @model containment="true"
	 * @generated
	 */
	EList<GeographicLocation> getGeographicLocations();

	/**
	 * Returns the value of the '<em><b>Agency</b></em>' containment reference list.
	 * The list contents are of type {@link mobilityResources.Agency}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Agency</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Agency</em>' containment reference list.
	 * @see mobilityResources.MobilityResourcesPackage#getMobilitySupport_Agency()
	 * @model containment="true"
	 * @generated
	 */
	EList<Agency> getAgency();

	/**
	 * Returns the value of the '<em><b>Stop times</b></em>' containment reference list.
	 * The list contents are of type {@link mobilityResources.Stop_time}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Stop times</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Stop times</em>' containment reference list.
	 * @see mobilityResources.MobilityResourcesPackage#getMobilitySupport_Stop_times()
	 * @model containment="true"
	 * @generated
	 */
	EList<Stop_time> getStop_times();

	/**
	 * Returns the value of the '<em><b>Calendar</b></em>' containment reference list.
	 * The list contents are of type {@link mobilityResources.Calendar}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Calendar</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Calendar</em>' containment reference list.
	 * @see mobilityResources.MobilityResourcesPackage#getMobilitySupport_Calendar()
	 * @model containment="true"
	 * @generated
	 */
	EList<Calendar> getCalendar();

	/**
	 * Returns the value of the '<em><b>Calendar dates</b></em>' containment reference list.
	 * The list contents are of type {@link mobilityResources.Calendar_date}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Calendar dates</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Calendar dates</em>' containment reference list.
	 * @see mobilityResources.MobilityResourcesPackage#getMobilitySupport_Calendar_dates()
	 * @model containment="true"
	 * @generated
	 */
	EList<Calendar_date> getCalendar_dates();

	/**
	 * Returns the value of the '<em><b>Fares</b></em>' containment reference list.
	 * The list contents are of type {@link mobilityResources.Fare_attribute}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Fares</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Fares</em>' containment reference list.
	 * @see mobilityResources.MobilityResourcesPackage#getMobilitySupport_Fares()
	 * @model containment="true"
	 * @generated
	 */
	EList<Fare_attribute> getFares();

	/**
	 * Returns the value of the '<em><b>Fare zones</b></em>' containment reference list.
	 * The list contents are of type {@link mobilityResources.Fare_rule}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Fare zones</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Fare zones</em>' containment reference list.
	 * @see mobilityResources.MobilityResourcesPackage#getMobilitySupport_Fare_zones()
	 * @model containment="true"
	 * @generated
	 */
	EList<Fare_rule> getFare_zones();

} // MobilitySupport
