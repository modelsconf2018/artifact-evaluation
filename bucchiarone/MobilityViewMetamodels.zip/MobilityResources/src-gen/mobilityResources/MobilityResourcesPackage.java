/**
 */
package mobilityResources;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see mobilityResources.MobilityResourcesFactory
 * @model kind="package"
 * @generated
 */
public interface MobilityResourcesPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "mobilityResources";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/mobilityResources";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "mobilityResources";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	MobilityResourcesPackage eINSTANCE = mobilityResources.impl.MobilityResourcesPackageImpl.init();

	/**
	 * The meta object id for the '{@link mobilityResources.impl.MobilitySupportImpl <em>Mobility Support</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mobilityResources.impl.MobilitySupportImpl
	 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getMobilitySupport()
	 * @generated
	 */
	int MOBILITY_SUPPORT = 0;

	/**
	 * The feature id for the '<em><b>City</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILITY_SUPPORT__CITY = 0;

	/**
	 * The feature id for the '<em><b>Mobilityresources</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILITY_SUPPORT__MOBILITYRESOURCES = 1;

	/**
	 * The feature id for the '<em><b>Geographic Locations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILITY_SUPPORT__GEOGRAPHIC_LOCATIONS = 2;

	/**
	 * The feature id for the '<em><b>Agency</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILITY_SUPPORT__AGENCY = 3;

	/**
	 * The feature id for the '<em><b>Stop times</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILITY_SUPPORT__STOP_TIMES = 4;

	/**
	 * The feature id for the '<em><b>Calendar</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILITY_SUPPORT__CALENDAR = 5;

	/**
	 * The feature id for the '<em><b>Calendar dates</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILITY_SUPPORT__CALENDAR_DATES = 6;

	/**
	 * The feature id for the '<em><b>Fares</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILITY_SUPPORT__FARES = 7;

	/**
	 * The feature id for the '<em><b>Fare zones</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILITY_SUPPORT__FARE_ZONES = 8;

	/**
	 * The number of structural features of the '<em>Mobility Support</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILITY_SUPPORT_FEATURE_COUNT = 9;

	/**
	 * The number of operations of the '<em>Mobility Support</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILITY_SUPPORT_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link mobilityResources.impl.MobilityResourceImpl <em>Mobility Resource</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mobilityResources.impl.MobilityResourceImpl
	 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getMobilityResource()
	 * @generated
	 */
	int MOBILITY_RESOURCE = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILITY_RESOURCE__NAME = 0;

	/**
	 * The feature id for the '<em><b>Last Update</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILITY_RESOURCE__LAST_UPDATE = 1;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILITY_RESOURCE__ID = 2;

	/**
	 * The number of structural features of the '<em>Mobility Resource</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILITY_RESOURCE_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Mobility Resource</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILITY_RESOURCE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link mobilityResources.impl.ParkingImpl <em>Parking</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mobilityResources.impl.ParkingImpl
	 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getParking()
	 * @generated
	 */
	int PARKING = 2;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARKING__NAME = MOBILITY_RESOURCE__NAME;

	/**
	 * The feature id for the '<em><b>Last Update</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARKING__LAST_UPDATE = MOBILITY_RESOURCE__LAST_UPDATE;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARKING__ID = MOBILITY_RESOURCE__ID;

	/**
	 * The feature id for the '<em><b>Address</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARKING__ADDRESS = MOBILITY_RESOURCE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Slots</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARKING__SLOTS = MOBILITY_RESOURCE_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Total Slots</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARKING__TOTAL_SLOTS = MOBILITY_RESOURCE_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Position</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARKING__POSITION = MOBILITY_RESOURCE_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>Parking</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARKING_FEATURE_COUNT = MOBILITY_RESOURCE_FEATURE_COUNT + 4;

	/**
	 * The number of operations of the '<em>Parking</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARKING_OPERATION_COUNT = MOBILITY_RESOURCE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mobilityResources.impl.BikeSharingImpl <em>Bike Sharing</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mobilityResources.impl.BikeSharingImpl
	 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getBikeSharing()
	 * @generated
	 */
	int BIKE_SHARING = 3;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BIKE_SHARING__NAME = MOBILITY_RESOURCE__NAME;

	/**
	 * The feature id for the '<em><b>Last Update</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BIKE_SHARING__LAST_UPDATE = MOBILITY_RESOURCE__LAST_UPDATE;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BIKE_SHARING__ID = MOBILITY_RESOURCE__ID;

	/**
	 * The feature id for the '<em><b>Address</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BIKE_SHARING__ADDRESS = MOBILITY_RESOURCE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Bikes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BIKE_SHARING__BIKES = MOBILITY_RESOURCE_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Slots</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BIKE_SHARING__SLOTS = MOBILITY_RESOURCE_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Total Slots</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BIKE_SHARING__TOTAL_SLOTS = MOBILITY_RESOURCE_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Position</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BIKE_SHARING__POSITION = MOBILITY_RESOURCE_FEATURE_COUNT + 4;

	/**
	 * The number of structural features of the '<em>Bike Sharing</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BIKE_SHARING_FEATURE_COUNT = MOBILITY_RESOURCE_FEATURE_COUNT + 5;

	/**
	 * The number of operations of the '<em>Bike Sharing</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BIKE_SHARING_OPERATION_COUNT = MOBILITY_RESOURCE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mobilityResources.impl.GeographicLocationImpl <em>Geographic Location</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mobilityResources.impl.GeographicLocationImpl
	 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getGeographicLocation()
	 * @generated
	 */
	int GEOGRAPHIC_LOCATION = 4;

	/**
	 * The feature id for the '<em><b>Lon</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GEOGRAPHIC_LOCATION__LON = 0;

	/**
	 * The feature id for the '<em><b>Lat</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GEOGRAPHIC_LOCATION__LAT = 1;

	/**
	 * The feature id for the '<em><b>Bikesharing</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GEOGRAPHIC_LOCATION__BIKESHARING = 2;

	/**
	 * The feature id for the '<em><b>Parking</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GEOGRAPHIC_LOCATION__PARKING = 3;

	/**
	 * The feature id for the '<em><b>Stop</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GEOGRAPHIC_LOCATION__STOP = 4;

	/**
	 * The number of structural features of the '<em>Geographic Location</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GEOGRAPHIC_LOCATION_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Geographic Location</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int GEOGRAPHIC_LOCATION_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link mobilityResources.impl.AgencyImpl <em>Agency</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mobilityResources.impl.AgencyImpl
	 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getAgency()
	 * @generated
	 */
	int AGENCY = 5;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGENCY__ID = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGENCY__NAME = 1;

	/**
	 * The feature id for the '<em><b>Url</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGENCY__URL = 2;

	/**
	 * The feature id for the '<em><b>Timezone</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGENCY__TIMEZONE = 3;

	/**
	 * The feature id for the '<em><b>Routes</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGENCY__ROUTES = 4;

	/**
	 * The feature id for the '<em><b>Fare attributes</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGENCY__FARE_ATTRIBUTES = 5;

	/**
	 * The number of structural features of the '<em>Agency</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGENCY_FEATURE_COUNT = 6;

	/**
	 * The number of operations of the '<em>Agency</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AGENCY_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link mobilityResources.impl.TransitImpl <em>Transit</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mobilityResources.impl.TransitImpl
	 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getTransit()
	 * @generated
	 */
	int TRANSIT = 6;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSIT__NAME = MOBILITY_RESOURCE__NAME;

	/**
	 * The feature id for the '<em><b>Last Update</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSIT__LAST_UPDATE = MOBILITY_RESOURCE__LAST_UPDATE;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSIT__ID = MOBILITY_RESOURCE__ID;

	/**
	 * The feature id for the '<em><b>Route</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSIT__ROUTE = MOBILITY_RESOURCE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSIT__TYPE = MOBILITY_RESOURCE_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Transit</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSIT_FEATURE_COUNT = MOBILITY_RESOURCE_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Transit</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSIT_OPERATION_COUNT = MOBILITY_RESOURCE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mobilityResources.impl.StopImpl <em>Stop</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mobilityResources.impl.StopImpl
	 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getStop()
	 * @generated
	 */
	int STOP = 7;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP__NAME = MOBILITY_RESOURCE__NAME;

	/**
	 * The feature id for the '<em><b>Last Update</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP__LAST_UPDATE = MOBILITY_RESOURCE__LAST_UPDATE;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP__ID = MOBILITY_RESOURCE__ID;

	/**
	 * The feature id for the '<em><b>Code</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP__CODE = MOBILITY_RESOURCE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Desc</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP__DESC = MOBILITY_RESOURCE_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Stop location</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP__STOP_LOCATION = MOBILITY_RESOURCE_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Url</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP__URL = MOBILITY_RESOURCE_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Location type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP__LOCATION_TYPE = MOBILITY_RESOURCE_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Parent station</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP__PARENT_STATION = MOBILITY_RESOURCE_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Wheelchair boarding</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP__WHEELCHAIR_BOARDING = MOBILITY_RESOURCE_FEATURE_COUNT + 6;

	/**
	 * The feature id for the '<em><b>Zone</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP__ZONE = MOBILITY_RESOURCE_FEATURE_COUNT + 7;

	/**
	 * The number of structural features of the '<em>Stop</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP_FEATURE_COUNT = MOBILITY_RESOURCE_FEATURE_COUNT + 8;

	/**
	 * The number of operations of the '<em>Stop</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP_OPERATION_COUNT = MOBILITY_RESOURCE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mobilityResources.impl.RouteImpl <em>Route</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mobilityResources.impl.RouteImpl
	 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getRoute()
	 * @generated
	 */
	int ROUTE = 8;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROUTE__NAME = MOBILITY_RESOURCE__NAME;

	/**
	 * The feature id for the '<em><b>Last Update</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROUTE__LAST_UPDATE = MOBILITY_RESOURCE__LAST_UPDATE;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROUTE__ID = MOBILITY_RESOURCE__ID;

	/**
	 * The feature id for the '<em><b>Long name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROUTE__LONG_NAME = MOBILITY_RESOURCE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Agency</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROUTE__AGENCY = MOBILITY_RESOURCE_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Desc</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROUTE__DESC = MOBILITY_RESOURCE_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Type</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROUTE__TYPE = MOBILITY_RESOURCE_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Url</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROUTE__URL = MOBILITY_RESOURCE_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Trips</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROUTE__TRIPS = MOBILITY_RESOURCE_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Fare rules</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROUTE__FARE_RULES = MOBILITY_RESOURCE_FEATURE_COUNT + 6;

	/**
	 * The number of structural features of the '<em>Route</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROUTE_FEATURE_COUNT = MOBILITY_RESOURCE_FEATURE_COUNT + 7;

	/**
	 * The number of operations of the '<em>Route</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROUTE_OPERATION_COUNT = MOBILITY_RESOURCE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mobilityResources.impl.TripImpl <em>Trip</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mobilityResources.impl.TripImpl
	 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getTrip()
	 * @generated
	 */
	int TRIP = 9;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP__NAME = MOBILITY_RESOURCE__NAME;

	/**
	 * The feature id for the '<em><b>Last Update</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP__LAST_UPDATE = MOBILITY_RESOURCE__LAST_UPDATE;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP__ID = MOBILITY_RESOURCE__ID;

	/**
	 * The feature id for the '<em><b>Route</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP__ROUTE = MOBILITY_RESOURCE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Service</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP__SERVICE = MOBILITY_RESOURCE_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Headsign</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP__HEADSIGN = MOBILITY_RESOURCE_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Direction id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP__DIRECTION_ID = MOBILITY_RESOURCE_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Block</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP__BLOCK = MOBILITY_RESOURCE_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Wheelchair accessible</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP__WHEELCHAIR_ACCESSIBLE = MOBILITY_RESOURCE_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Bikes allowed</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP__BIKES_ALLOWED = MOBILITY_RESOURCE_FEATURE_COUNT + 6;

	/**
	 * The feature id for the '<em><b>Service dates</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP__SERVICE_DATES = MOBILITY_RESOURCE_FEATURE_COUNT + 7;

	/**
	 * The number of structural features of the '<em>Trip</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP_FEATURE_COUNT = MOBILITY_RESOURCE_FEATURE_COUNT + 8;

	/**
	 * The number of operations of the '<em>Trip</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRIP_OPERATION_COUNT = MOBILITY_RESOURCE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mobilityResources.impl.CalendarImpl <em>Calendar</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mobilityResources.impl.CalendarImpl
	 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getCalendar()
	 * @generated
	 */
	int CALENDAR = 10;

	/**
	 * The feature id for the '<em><b>Service id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CALENDAR__SERVICE_ID = 0;

	/**
	 * The feature id for the '<em><b>Monday</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CALENDAR__MONDAY = 1;

	/**
	 * The feature id for the '<em><b>Tuesday</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CALENDAR__TUESDAY = 2;

	/**
	 * The feature id for the '<em><b>Wednesday</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CALENDAR__WEDNESDAY = 3;

	/**
	 * The feature id for the '<em><b>Thursday</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CALENDAR__THURSDAY = 4;

	/**
	 * The feature id for the '<em><b>Friday</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CALENDAR__FRIDAY = 5;

	/**
	 * The feature id for the '<em><b>Saturday</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CALENDAR__SATURDAY = 6;

	/**
	 * The feature id for the '<em><b>Sunday</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CALENDAR__SUNDAY = 7;

	/**
	 * The feature id for the '<em><b>Start date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CALENDAR__START_DATE = 8;

	/**
	 * The feature id for the '<em><b>End date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CALENDAR__END_DATE = 9;

	/**
	 * The number of structural features of the '<em>Calendar</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CALENDAR_FEATURE_COUNT = 10;

	/**
	 * The number of operations of the '<em>Calendar</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CALENDAR_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link mobilityResources.impl.BlockImpl <em>Block</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mobilityResources.impl.BlockImpl
	 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getBlock()
	 * @generated
	 */
	int BLOCK = 11;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLOCK__NAME = MOBILITY_RESOURCE__NAME;

	/**
	 * The feature id for the '<em><b>Last Update</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLOCK__LAST_UPDATE = MOBILITY_RESOURCE__LAST_UPDATE;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLOCK__ID = MOBILITY_RESOURCE__ID;

	/**
	 * The feature id for the '<em><b>Trips</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLOCK__TRIPS = MOBILITY_RESOURCE_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Block</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLOCK_FEATURE_COUNT = MOBILITY_RESOURCE_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Block</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BLOCK_OPERATION_COUNT = MOBILITY_RESOURCE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mobilityResources.impl.Stop_timeImpl <em>Stop time</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mobilityResources.impl.Stop_timeImpl
	 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getStop_time()
	 * @generated
	 */
	int STOP_TIME = 12;

	/**
	 * The feature id for the '<em><b>Arrival time</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP_TIME__ARRIVAL_TIME = 0;

	/**
	 * The feature id for the '<em><b>Departure time</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP_TIME__DEPARTURE_TIME = 1;

	/**
	 * The feature id for the '<em><b>Stop</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP_TIME__STOP = 2;

	/**
	 * The feature id for the '<em><b>Stop sequence</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP_TIME__STOP_SEQUENCE = 3;

	/**
	 * The feature id for the '<em><b>Stop headsign</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP_TIME__STOP_HEADSIGN = 4;

	/**
	 * The feature id for the '<em><b>Pickup type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP_TIME__PICKUP_TYPE = 5;

	/**
	 * The feature id for the '<em><b>Drop off type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP_TIME__DROP_OFF_TYPE = 6;

	/**
	 * The feature id for the '<em><b>Shape dist traveled</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP_TIME__SHAPE_DIST_TRAVELED = 7;

	/**
	 * The feature id for the '<em><b>Timepoint</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP_TIME__TIMEPOINT = 8;

	/**
	 * The number of structural features of the '<em>Stop time</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP_TIME_FEATURE_COUNT = 9;

	/**
	 * The number of operations of the '<em>Stop time</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int STOP_TIME_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link mobilityResources.impl.Calendar_dateImpl <em>Calendar date</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mobilityResources.impl.Calendar_dateImpl
	 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getCalendar_date()
	 * @generated
	 */
	int CALENDAR_DATE = 13;

	/**
	 * The feature id for the '<em><b>Service id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CALENDAR_DATE__SERVICE_ID = 0;

	/**
	 * The feature id for the '<em><b>Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CALENDAR_DATE__DATE = 1;

	/**
	 * The feature id for the '<em><b>Exception type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CALENDAR_DATE__EXCEPTION_TYPE = 2;

	/**
	 * The number of structural features of the '<em>Calendar date</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CALENDAR_DATE_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Calendar date</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CALENDAR_DATE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link mobilityResources.impl.Fare_attributeImpl <em>Fare attribute</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mobilityResources.impl.Fare_attributeImpl
	 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getFare_attribute()
	 * @generated
	 */
	int FARE_ATTRIBUTE = 14;

	/**
	 * The feature id for the '<em><b>Fare id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FARE_ATTRIBUTE__FARE_ID = 0;

	/**
	 * The feature id for the '<em><b>Price</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FARE_ATTRIBUTE__PRICE = 1;

	/**
	 * The feature id for the '<em><b>Currency type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FARE_ATTRIBUTE__CURRENCY_TYPE = 2;

	/**
	 * The feature id for the '<em><b>Payment method</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FARE_ATTRIBUTE__PAYMENT_METHOD = 3;

	/**
	 * The feature id for the '<em><b>Transfers</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FARE_ATTRIBUTE__TRANSFERS = 4;

	/**
	 * The feature id for the '<em><b>Transfer duration</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FARE_ATTRIBUTE__TRANSFER_DURATION = 5;

	/**
	 * The feature id for the '<em><b>Agency id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FARE_ATTRIBUTE__AGENCY_ID = 6;

	/**
	 * The feature id for the '<em><b>Fare rules</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FARE_ATTRIBUTE__FARE_RULES = 7;

	/**
	 * The number of structural features of the '<em>Fare attribute</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FARE_ATTRIBUTE_FEATURE_COUNT = 8;

	/**
	 * The number of operations of the '<em>Fare attribute</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FARE_ATTRIBUTE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link mobilityResources.impl.Fare_ruleImpl <em>Fare rule</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mobilityResources.impl.Fare_ruleImpl
	 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getFare_rule()
	 * @generated
	 */
	int FARE_RULE = 15;

	/**
	 * The feature id for the '<em><b>Fare</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FARE_RULE__FARE = 0;

	/**
	 * The feature id for the '<em><b>Route</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FARE_RULE__ROUTE = 1;

	/**
	 * The feature id for the '<em><b>Origin</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FARE_RULE__ORIGIN = 2;

	/**
	 * The feature id for the '<em><b>Destination</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FARE_RULE__DESTINATION = 3;

	/**
	 * The feature id for the '<em><b>Contains</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FARE_RULE__CONTAINS = 4;

	/**
	 * The number of structural features of the '<em>Fare rule</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FARE_RULE_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Fare rule</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int FARE_RULE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link mobilityResources.impl.ZoneImpl <em>Zone</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mobilityResources.impl.ZoneImpl
	 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getZone()
	 * @generated
	 */
	int ZONE = 16;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ZONE__NAME = MOBILITY_RESOURCE__NAME;

	/**
	 * The feature id for the '<em><b>Last Update</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ZONE__LAST_UPDATE = MOBILITY_RESOURCE__LAST_UPDATE;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ZONE__ID = MOBILITY_RESOURCE__ID;

	/**
	 * The feature id for the '<em><b>Stops</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ZONE__STOPS = MOBILITY_RESOURCE_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Origin fare rules</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ZONE__ORIGIN_FARE_RULES = MOBILITY_RESOURCE_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Destination fare rules</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ZONE__DESTINATION_FARE_RULES = MOBILITY_RESOURCE_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Contains fare rules</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ZONE__CONTAINS_FARE_RULES = MOBILITY_RESOURCE_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>Zone</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ZONE_FEATURE_COUNT = MOBILITY_RESOURCE_FEATURE_COUNT + 4;

	/**
	 * The number of operations of the '<em>Zone</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ZONE_OPERATION_COUNT = MOBILITY_RESOURCE_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link mobilityResources.Location_Type <em>Location Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mobilityResources.Location_Type
	 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getLocation_Type()
	 * @generated
	 */
	int LOCATION_TYPE = 17;

	/**
	 * The meta object id for the '{@link mobilityResources.Accessibility <em>Accessibility</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mobilityResources.Accessibility
	 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getAccessibility()
	 * @generated
	 */
	int ACCESSIBILITY = 18;

	/**
	 * The meta object id for the '{@link mobilityResources.TravelDirection <em>Travel Direction</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mobilityResources.TravelDirection
	 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getTravelDirection()
	 * @generated
	 */
	int TRAVEL_DIRECTION = 19;

	/**
	 * The meta object id for the '{@link mobilityResources.Pickup_Drop_off_Type <em>Pickup Drop off Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mobilityResources.Pickup_Drop_off_Type
	 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getPickup_Drop_off_Type()
	 * @generated
	 */
	int PICKUP_DROP_OFF_TYPE = 20;

	/**
	 * The meta object id for the '{@link mobilityResources.TimeAdherence <em>Time Adherence</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mobilityResources.TimeAdherence
	 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getTimeAdherence()
	 * @generated
	 */
	int TIME_ADHERENCE = 21;

	/**
	 * The meta object id for the '{@link mobilityResources.Availability <em>Availability</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mobilityResources.Availability
	 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getAvailability()
	 * @generated
	 */
	int AVAILABILITY = 22;

	/**
	 * The meta object id for the '{@link mobilityResources.Exception_type <em>Exception type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mobilityResources.Exception_type
	 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getException_type()
	 * @generated
	 */
	int EXCEPTION_TYPE = 23;

	/**
	 * The meta object id for the '{@link mobilityResources.Payment_method <em>Payment method</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mobilityResources.Payment_method
	 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getPayment_method()
	 * @generated
	 */
	int PAYMENT_METHOD = 24;

	/**
	 * The meta object id for the '{@link mobilityResources.Allowed_transfers <em>Allowed transfers</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mobilityResources.Allowed_transfers
	 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getAllowed_transfers()
	 * @generated
	 */
	int ALLOWED_TRANSFERS = 25;

	/**
	 * The meta object id for the '{@link mobilityResources.TransitType <em>Transit Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see mobilityResources.TransitType
	 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getTransitType()
	 * @generated
	 */
	int TRANSIT_TYPE = 26;

	/**
	 * Returns the meta object for class '{@link mobilityResources.MobilitySupport <em>Mobility Support</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Mobility Support</em>'.
	 * @see mobilityResources.MobilitySupport
	 * @generated
	 */
	EClass getMobilitySupport();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.MobilitySupport#getCity <em>City</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>City</em>'.
	 * @see mobilityResources.MobilitySupport#getCity()
	 * @see #getMobilitySupport()
	 * @generated
	 */
	EAttribute getMobilitySupport_City();

	/**
	 * Returns the meta object for the containment reference list '{@link mobilityResources.MobilitySupport#getMobilityresources <em>Mobilityresources</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Mobilityresources</em>'.
	 * @see mobilityResources.MobilitySupport#getMobilityresources()
	 * @see #getMobilitySupport()
	 * @generated
	 */
	EReference getMobilitySupport_Mobilityresources();

	/**
	 * Returns the meta object for the containment reference list '{@link mobilityResources.MobilitySupport#getGeographicLocations <em>Geographic Locations</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Geographic Locations</em>'.
	 * @see mobilityResources.MobilitySupport#getGeographicLocations()
	 * @see #getMobilitySupport()
	 * @generated
	 */
	EReference getMobilitySupport_GeographicLocations();

	/**
	 * Returns the meta object for the containment reference list '{@link mobilityResources.MobilitySupport#getAgency <em>Agency</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Agency</em>'.
	 * @see mobilityResources.MobilitySupport#getAgency()
	 * @see #getMobilitySupport()
	 * @generated
	 */
	EReference getMobilitySupport_Agency();

	/**
	 * Returns the meta object for the containment reference list '{@link mobilityResources.MobilitySupport#getStop_times <em>Stop times</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Stop times</em>'.
	 * @see mobilityResources.MobilitySupport#getStop_times()
	 * @see #getMobilitySupport()
	 * @generated
	 */
	EReference getMobilitySupport_Stop_times();

	/**
	 * Returns the meta object for the containment reference list '{@link mobilityResources.MobilitySupport#getCalendar <em>Calendar</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Calendar</em>'.
	 * @see mobilityResources.MobilitySupport#getCalendar()
	 * @see #getMobilitySupport()
	 * @generated
	 */
	EReference getMobilitySupport_Calendar();

	/**
	 * Returns the meta object for the containment reference list '{@link mobilityResources.MobilitySupport#getCalendar_dates <em>Calendar dates</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Calendar dates</em>'.
	 * @see mobilityResources.MobilitySupport#getCalendar_dates()
	 * @see #getMobilitySupport()
	 * @generated
	 */
	EReference getMobilitySupport_Calendar_dates();

	/**
	 * Returns the meta object for the containment reference list '{@link mobilityResources.MobilitySupport#getFares <em>Fares</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Fares</em>'.
	 * @see mobilityResources.MobilitySupport#getFares()
	 * @see #getMobilitySupport()
	 * @generated
	 */
	EReference getMobilitySupport_Fares();

	/**
	 * Returns the meta object for the containment reference list '{@link mobilityResources.MobilitySupport#getFare_zones <em>Fare zones</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Fare zones</em>'.
	 * @see mobilityResources.MobilitySupport#getFare_zones()
	 * @see #getMobilitySupport()
	 * @generated
	 */
	EReference getMobilitySupport_Fare_zones();

	/**
	 * Returns the meta object for class '{@link mobilityResources.MobilityResource <em>Mobility Resource</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Mobility Resource</em>'.
	 * @see mobilityResources.MobilityResource
	 * @generated
	 */
	EClass getMobilityResource();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.MobilityResource#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see mobilityResources.MobilityResource#getName()
	 * @see #getMobilityResource()
	 * @generated
	 */
	EAttribute getMobilityResource_Name();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.MobilityResource#getLastUpdate <em>Last Update</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Last Update</em>'.
	 * @see mobilityResources.MobilityResource#getLastUpdate()
	 * @see #getMobilityResource()
	 * @generated
	 */
	EAttribute getMobilityResource_LastUpdate();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.MobilityResource#getId <em>Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id</em>'.
	 * @see mobilityResources.MobilityResource#getId()
	 * @see #getMobilityResource()
	 * @generated
	 */
	EAttribute getMobilityResource_Id();

	/**
	 * Returns the meta object for class '{@link mobilityResources.Parking <em>Parking</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Parking</em>'.
	 * @see mobilityResources.Parking
	 * @generated
	 */
	EClass getParking();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Parking#getAddress <em>Address</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Address</em>'.
	 * @see mobilityResources.Parking#getAddress()
	 * @see #getParking()
	 * @generated
	 */
	EAttribute getParking_Address();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Parking#getSlots <em>Slots</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Slots</em>'.
	 * @see mobilityResources.Parking#getSlots()
	 * @see #getParking()
	 * @generated
	 */
	EAttribute getParking_Slots();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Parking#getTotalSlots <em>Total Slots</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Total Slots</em>'.
	 * @see mobilityResources.Parking#getTotalSlots()
	 * @see #getParking()
	 * @generated
	 */
	EAttribute getParking_TotalSlots();

	/**
	 * Returns the meta object for the reference '{@link mobilityResources.Parking#getPosition <em>Position</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Position</em>'.
	 * @see mobilityResources.Parking#getPosition()
	 * @see #getParking()
	 * @generated
	 */
	EReference getParking_Position();

	/**
	 * Returns the meta object for class '{@link mobilityResources.BikeSharing <em>Bike Sharing</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Bike Sharing</em>'.
	 * @see mobilityResources.BikeSharing
	 * @generated
	 */
	EClass getBikeSharing();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.BikeSharing#getAddress <em>Address</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Address</em>'.
	 * @see mobilityResources.BikeSharing#getAddress()
	 * @see #getBikeSharing()
	 * @generated
	 */
	EAttribute getBikeSharing_Address();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.BikeSharing#getBikes <em>Bikes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Bikes</em>'.
	 * @see mobilityResources.BikeSharing#getBikes()
	 * @see #getBikeSharing()
	 * @generated
	 */
	EAttribute getBikeSharing_Bikes();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.BikeSharing#getSlots <em>Slots</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Slots</em>'.
	 * @see mobilityResources.BikeSharing#getSlots()
	 * @see #getBikeSharing()
	 * @generated
	 */
	EAttribute getBikeSharing_Slots();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.BikeSharing#getTotalSlots <em>Total Slots</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Total Slots</em>'.
	 * @see mobilityResources.BikeSharing#getTotalSlots()
	 * @see #getBikeSharing()
	 * @generated
	 */
	EAttribute getBikeSharing_TotalSlots();

	/**
	 * Returns the meta object for the reference '{@link mobilityResources.BikeSharing#getPosition <em>Position</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Position</em>'.
	 * @see mobilityResources.BikeSharing#getPosition()
	 * @see #getBikeSharing()
	 * @generated
	 */
	EReference getBikeSharing_Position();

	/**
	 * Returns the meta object for class '{@link mobilityResources.GeographicLocation <em>Geographic Location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Geographic Location</em>'.
	 * @see mobilityResources.GeographicLocation
	 * @generated
	 */
	EClass getGeographicLocation();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.GeographicLocation#getLon <em>Lon</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Lon</em>'.
	 * @see mobilityResources.GeographicLocation#getLon()
	 * @see #getGeographicLocation()
	 * @generated
	 */
	EAttribute getGeographicLocation_Lon();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.GeographicLocation#getLat <em>Lat</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Lat</em>'.
	 * @see mobilityResources.GeographicLocation#getLat()
	 * @see #getGeographicLocation()
	 * @generated
	 */
	EAttribute getGeographicLocation_Lat();

	/**
	 * Returns the meta object for the reference '{@link mobilityResources.GeographicLocation#getBikesharing <em>Bikesharing</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Bikesharing</em>'.
	 * @see mobilityResources.GeographicLocation#getBikesharing()
	 * @see #getGeographicLocation()
	 * @generated
	 */
	EReference getGeographicLocation_Bikesharing();

	/**
	 * Returns the meta object for the reference '{@link mobilityResources.GeographicLocation#getParking <em>Parking</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Parking</em>'.
	 * @see mobilityResources.GeographicLocation#getParking()
	 * @see #getGeographicLocation()
	 * @generated
	 */
	EReference getGeographicLocation_Parking();

	/**
	 * Returns the meta object for the reference '{@link mobilityResources.GeographicLocation#getStop <em>Stop</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Stop</em>'.
	 * @see mobilityResources.GeographicLocation#getStop()
	 * @see #getGeographicLocation()
	 * @generated
	 */
	EReference getGeographicLocation_Stop();

	/**
	 * Returns the meta object for class '{@link mobilityResources.Agency <em>Agency</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Agency</em>'.
	 * @see mobilityResources.Agency
	 * @generated
	 */
	EClass getAgency();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Agency#getId <em>Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id</em>'.
	 * @see mobilityResources.Agency#getId()
	 * @see #getAgency()
	 * @generated
	 */
	EAttribute getAgency_Id();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Agency#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see mobilityResources.Agency#getName()
	 * @see #getAgency()
	 * @generated
	 */
	EAttribute getAgency_Name();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Agency#getUrl <em>Url</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Url</em>'.
	 * @see mobilityResources.Agency#getUrl()
	 * @see #getAgency()
	 * @generated
	 */
	EAttribute getAgency_Url();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Agency#getTimezone <em>Timezone</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Timezone</em>'.
	 * @see mobilityResources.Agency#getTimezone()
	 * @see #getAgency()
	 * @generated
	 */
	EAttribute getAgency_Timezone();

	/**
	 * Returns the meta object for the reference list '{@link mobilityResources.Agency#getRoutes <em>Routes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Routes</em>'.
	 * @see mobilityResources.Agency#getRoutes()
	 * @see #getAgency()
	 * @generated
	 */
	EReference getAgency_Routes();

	/**
	 * Returns the meta object for the reference list '{@link mobilityResources.Agency#getFare_attributes <em>Fare attributes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Fare attributes</em>'.
	 * @see mobilityResources.Agency#getFare_attributes()
	 * @see #getAgency()
	 * @generated
	 */
	EReference getAgency_Fare_attributes();

	/**
	 * Returns the meta object for class '{@link mobilityResources.Transit <em>Transit</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Transit</em>'.
	 * @see mobilityResources.Transit
	 * @generated
	 */
	EClass getTransit();

	/**
	 * Returns the meta object for the reference '{@link mobilityResources.Transit#getRoute <em>Route</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Route</em>'.
	 * @see mobilityResources.Transit#getRoute()
	 * @see #getTransit()
	 * @generated
	 */
	EReference getTransit_Route();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Transit#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see mobilityResources.Transit#getType()
	 * @see #getTransit()
	 * @generated
	 */
	EAttribute getTransit_Type();

	/**
	 * Returns the meta object for class '{@link mobilityResources.Stop <em>Stop</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Stop</em>'.
	 * @see mobilityResources.Stop
	 * @generated
	 */
	EClass getStop();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Stop#getCode <em>Code</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Code</em>'.
	 * @see mobilityResources.Stop#getCode()
	 * @see #getStop()
	 * @generated
	 */
	EAttribute getStop_Code();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Stop#getDesc <em>Desc</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Desc</em>'.
	 * @see mobilityResources.Stop#getDesc()
	 * @see #getStop()
	 * @generated
	 */
	EAttribute getStop_Desc();

	/**
	 * Returns the meta object for the reference '{@link mobilityResources.Stop#getStop_location <em>Stop location</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Stop location</em>'.
	 * @see mobilityResources.Stop#getStop_location()
	 * @see #getStop()
	 * @generated
	 */
	EReference getStop_Stop_location();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Stop#getUrl <em>Url</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Url</em>'.
	 * @see mobilityResources.Stop#getUrl()
	 * @see #getStop()
	 * @generated
	 */
	EAttribute getStop_Url();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Stop#getLocation_type <em>Location type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Location type</em>'.
	 * @see mobilityResources.Stop#getLocation_type()
	 * @see #getStop()
	 * @generated
	 */
	EAttribute getStop_Location_type();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Stop#getParent_station <em>Parent station</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Parent station</em>'.
	 * @see mobilityResources.Stop#getParent_station()
	 * @see #getStop()
	 * @generated
	 */
	EAttribute getStop_Parent_station();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Stop#getWheelchair_boarding <em>Wheelchair boarding</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Wheelchair boarding</em>'.
	 * @see mobilityResources.Stop#getWheelchair_boarding()
	 * @see #getStop()
	 * @generated
	 */
	EAttribute getStop_Wheelchair_boarding();

	/**
	 * Returns the meta object for the reference '{@link mobilityResources.Stop#getZone <em>Zone</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Zone</em>'.
	 * @see mobilityResources.Stop#getZone()
	 * @see #getStop()
	 * @generated
	 */
	EReference getStop_Zone();

	/**
	 * Returns the meta object for class '{@link mobilityResources.Route <em>Route</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Route</em>'.
	 * @see mobilityResources.Route
	 * @generated
	 */
	EClass getRoute();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Route#getLong_name <em>Long name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Long name</em>'.
	 * @see mobilityResources.Route#getLong_name()
	 * @see #getRoute()
	 * @generated
	 */
	EAttribute getRoute_Long_name();

	/**
	 * Returns the meta object for the reference list '{@link mobilityResources.Route#getAgency <em>Agency</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Agency</em>'.
	 * @see mobilityResources.Route#getAgency()
	 * @see #getRoute()
	 * @generated
	 */
	EReference getRoute_Agency();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Route#getDesc <em>Desc</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Desc</em>'.
	 * @see mobilityResources.Route#getDesc()
	 * @see #getRoute()
	 * @generated
	 */
	EAttribute getRoute_Desc();

	/**
	 * Returns the meta object for the reference '{@link mobilityResources.Route#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Type</em>'.
	 * @see mobilityResources.Route#getType()
	 * @see #getRoute()
	 * @generated
	 */
	EReference getRoute_Type();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Route#getUrl <em>Url</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Url</em>'.
	 * @see mobilityResources.Route#getUrl()
	 * @see #getRoute()
	 * @generated
	 */
	EAttribute getRoute_Url();

	/**
	 * Returns the meta object for the reference list '{@link mobilityResources.Route#getTrips <em>Trips</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Trips</em>'.
	 * @see mobilityResources.Route#getTrips()
	 * @see #getRoute()
	 * @generated
	 */
	EReference getRoute_Trips();

	/**
	 * Returns the meta object for the reference list '{@link mobilityResources.Route#getFare_rules <em>Fare rules</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Fare rules</em>'.
	 * @see mobilityResources.Route#getFare_rules()
	 * @see #getRoute()
	 * @generated
	 */
	EReference getRoute_Fare_rules();

	/**
	 * Returns the meta object for class '{@link mobilityResources.Trip <em>Trip</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Trip</em>'.
	 * @see mobilityResources.Trip
	 * @generated
	 */
	EClass getTrip();

	/**
	 * Returns the meta object for the reference '{@link mobilityResources.Trip#getRoute <em>Route</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Route</em>'.
	 * @see mobilityResources.Trip#getRoute()
	 * @see #getTrip()
	 * @generated
	 */
	EReference getTrip_Route();

	/**
	 * Returns the meta object for the reference '{@link mobilityResources.Trip#getService <em>Service</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Service</em>'.
	 * @see mobilityResources.Trip#getService()
	 * @see #getTrip()
	 * @generated
	 */
	EReference getTrip_Service();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Trip#getHeadsign <em>Headsign</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Headsign</em>'.
	 * @see mobilityResources.Trip#getHeadsign()
	 * @see #getTrip()
	 * @generated
	 */
	EAttribute getTrip_Headsign();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Trip#getDirection_id <em>Direction id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Direction id</em>'.
	 * @see mobilityResources.Trip#getDirection_id()
	 * @see #getTrip()
	 * @generated
	 */
	EAttribute getTrip_Direction_id();

	/**
	 * Returns the meta object for the reference '{@link mobilityResources.Trip#getBlock <em>Block</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Block</em>'.
	 * @see mobilityResources.Trip#getBlock()
	 * @see #getTrip()
	 * @generated
	 */
	EReference getTrip_Block();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Trip#getWheelchair_accessible <em>Wheelchair accessible</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Wheelchair accessible</em>'.
	 * @see mobilityResources.Trip#getWheelchair_accessible()
	 * @see #getTrip()
	 * @generated
	 */
	EAttribute getTrip_Wheelchair_accessible();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Trip#getBikes_allowed <em>Bikes allowed</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Bikes allowed</em>'.
	 * @see mobilityResources.Trip#getBikes_allowed()
	 * @see #getTrip()
	 * @generated
	 */
	EAttribute getTrip_Bikes_allowed();

	/**
	 * Returns the meta object for the reference '{@link mobilityResources.Trip#getService_dates <em>Service dates</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Service dates</em>'.
	 * @see mobilityResources.Trip#getService_dates()
	 * @see #getTrip()
	 * @generated
	 */
	EReference getTrip_Service_dates();

	/**
	 * Returns the meta object for class '{@link mobilityResources.Calendar <em>Calendar</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Calendar</em>'.
	 * @see mobilityResources.Calendar
	 * @generated
	 */
	EClass getCalendar();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Calendar#getService_id <em>Service id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Service id</em>'.
	 * @see mobilityResources.Calendar#getService_id()
	 * @see #getCalendar()
	 * @generated
	 */
	EAttribute getCalendar_Service_id();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Calendar#getMonday <em>Monday</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Monday</em>'.
	 * @see mobilityResources.Calendar#getMonday()
	 * @see #getCalendar()
	 * @generated
	 */
	EAttribute getCalendar_Monday();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Calendar#getTuesday <em>Tuesday</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Tuesday</em>'.
	 * @see mobilityResources.Calendar#getTuesday()
	 * @see #getCalendar()
	 * @generated
	 */
	EAttribute getCalendar_Tuesday();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Calendar#getWednesday <em>Wednesday</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Wednesday</em>'.
	 * @see mobilityResources.Calendar#getWednesday()
	 * @see #getCalendar()
	 * @generated
	 */
	EAttribute getCalendar_Wednesday();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Calendar#getThursday <em>Thursday</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Thursday</em>'.
	 * @see mobilityResources.Calendar#getThursday()
	 * @see #getCalendar()
	 * @generated
	 */
	EAttribute getCalendar_Thursday();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Calendar#getFriday <em>Friday</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Friday</em>'.
	 * @see mobilityResources.Calendar#getFriday()
	 * @see #getCalendar()
	 * @generated
	 */
	EAttribute getCalendar_Friday();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Calendar#getSaturday <em>Saturday</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Saturday</em>'.
	 * @see mobilityResources.Calendar#getSaturday()
	 * @see #getCalendar()
	 * @generated
	 */
	EAttribute getCalendar_Saturday();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Calendar#getSunday <em>Sunday</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Sunday</em>'.
	 * @see mobilityResources.Calendar#getSunday()
	 * @see #getCalendar()
	 * @generated
	 */
	EAttribute getCalendar_Sunday();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Calendar#getStart_date <em>Start date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Start date</em>'.
	 * @see mobilityResources.Calendar#getStart_date()
	 * @see #getCalendar()
	 * @generated
	 */
	EAttribute getCalendar_Start_date();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Calendar#getEnd_date <em>End date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>End date</em>'.
	 * @see mobilityResources.Calendar#getEnd_date()
	 * @see #getCalendar()
	 * @generated
	 */
	EAttribute getCalendar_End_date();

	/**
	 * Returns the meta object for class '{@link mobilityResources.Block <em>Block</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Block</em>'.
	 * @see mobilityResources.Block
	 * @generated
	 */
	EClass getBlock();

	/**
	 * Returns the meta object for the reference list '{@link mobilityResources.Block#getTrips <em>Trips</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Trips</em>'.
	 * @see mobilityResources.Block#getTrips()
	 * @see #getBlock()
	 * @generated
	 */
	EReference getBlock_Trips();

	/**
	 * Returns the meta object for class '{@link mobilityResources.Stop_time <em>Stop time</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Stop time</em>'.
	 * @see mobilityResources.Stop_time
	 * @generated
	 */
	EClass getStop_time();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Stop_time#getArrival_time <em>Arrival time</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Arrival time</em>'.
	 * @see mobilityResources.Stop_time#getArrival_time()
	 * @see #getStop_time()
	 * @generated
	 */
	EAttribute getStop_time_Arrival_time();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Stop_time#getDeparture_time <em>Departure time</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Departure time</em>'.
	 * @see mobilityResources.Stop_time#getDeparture_time()
	 * @see #getStop_time()
	 * @generated
	 */
	EAttribute getStop_time_Departure_time();

	/**
	 * Returns the meta object for the reference '{@link mobilityResources.Stop_time#getStop <em>Stop</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Stop</em>'.
	 * @see mobilityResources.Stop_time#getStop()
	 * @see #getStop_time()
	 * @generated
	 */
	EReference getStop_time_Stop();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Stop_time#getStop_sequence <em>Stop sequence</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Stop sequence</em>'.
	 * @see mobilityResources.Stop_time#getStop_sequence()
	 * @see #getStop_time()
	 * @generated
	 */
	EAttribute getStop_time_Stop_sequence();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Stop_time#getStop_headsign <em>Stop headsign</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Stop headsign</em>'.
	 * @see mobilityResources.Stop_time#getStop_headsign()
	 * @see #getStop_time()
	 * @generated
	 */
	EAttribute getStop_time_Stop_headsign();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Stop_time#getPickup_type <em>Pickup type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Pickup type</em>'.
	 * @see mobilityResources.Stop_time#getPickup_type()
	 * @see #getStop_time()
	 * @generated
	 */
	EAttribute getStop_time_Pickup_type();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Stop_time#getDrop_off_type <em>Drop off type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Drop off type</em>'.
	 * @see mobilityResources.Stop_time#getDrop_off_type()
	 * @see #getStop_time()
	 * @generated
	 */
	EAttribute getStop_time_Drop_off_type();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Stop_time#getShape_dist_traveled <em>Shape dist traveled</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Shape dist traveled</em>'.
	 * @see mobilityResources.Stop_time#getShape_dist_traveled()
	 * @see #getStop_time()
	 * @generated
	 */
	EAttribute getStop_time_Shape_dist_traveled();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Stop_time#getTimepoint <em>Timepoint</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Timepoint</em>'.
	 * @see mobilityResources.Stop_time#getTimepoint()
	 * @see #getStop_time()
	 * @generated
	 */
	EAttribute getStop_time_Timepoint();

	/**
	 * Returns the meta object for class '{@link mobilityResources.Calendar_date <em>Calendar date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Calendar date</em>'.
	 * @see mobilityResources.Calendar_date
	 * @generated
	 */
	EClass getCalendar_date();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Calendar_date#getService_id <em>Service id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Service id</em>'.
	 * @see mobilityResources.Calendar_date#getService_id()
	 * @see #getCalendar_date()
	 * @generated
	 */
	EAttribute getCalendar_date_Service_id();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Calendar_date#getDate <em>Date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Date</em>'.
	 * @see mobilityResources.Calendar_date#getDate()
	 * @see #getCalendar_date()
	 * @generated
	 */
	EAttribute getCalendar_date_Date();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Calendar_date#getException_type <em>Exception type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Exception type</em>'.
	 * @see mobilityResources.Calendar_date#getException_type()
	 * @see #getCalendar_date()
	 * @generated
	 */
	EAttribute getCalendar_date_Exception_type();

	/**
	 * Returns the meta object for class '{@link mobilityResources.Fare_attribute <em>Fare attribute</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Fare attribute</em>'.
	 * @see mobilityResources.Fare_attribute
	 * @generated
	 */
	EClass getFare_attribute();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Fare_attribute#getFare_id <em>Fare id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Fare id</em>'.
	 * @see mobilityResources.Fare_attribute#getFare_id()
	 * @see #getFare_attribute()
	 * @generated
	 */
	EAttribute getFare_attribute_Fare_id();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Fare_attribute#getPrice <em>Price</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Price</em>'.
	 * @see mobilityResources.Fare_attribute#getPrice()
	 * @see #getFare_attribute()
	 * @generated
	 */
	EAttribute getFare_attribute_Price();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Fare_attribute#getCurrency_type <em>Currency type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Currency type</em>'.
	 * @see mobilityResources.Fare_attribute#getCurrency_type()
	 * @see #getFare_attribute()
	 * @generated
	 */
	EAttribute getFare_attribute_Currency_type();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Fare_attribute#getPayment_method <em>Payment method</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Payment method</em>'.
	 * @see mobilityResources.Fare_attribute#getPayment_method()
	 * @see #getFare_attribute()
	 * @generated
	 */
	EAttribute getFare_attribute_Payment_method();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Fare_attribute#getTransfers <em>Transfers</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Transfers</em>'.
	 * @see mobilityResources.Fare_attribute#getTransfers()
	 * @see #getFare_attribute()
	 * @generated
	 */
	EAttribute getFare_attribute_Transfers();

	/**
	 * Returns the meta object for the attribute '{@link mobilityResources.Fare_attribute#getTransfer_duration <em>Transfer duration</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Transfer duration</em>'.
	 * @see mobilityResources.Fare_attribute#getTransfer_duration()
	 * @see #getFare_attribute()
	 * @generated
	 */
	EAttribute getFare_attribute_Transfer_duration();

	/**
	 * Returns the meta object for the reference '{@link mobilityResources.Fare_attribute#getAgency_id <em>Agency id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Agency id</em>'.
	 * @see mobilityResources.Fare_attribute#getAgency_id()
	 * @see #getFare_attribute()
	 * @generated
	 */
	EReference getFare_attribute_Agency_id();

	/**
	 * Returns the meta object for the reference list '{@link mobilityResources.Fare_attribute#getFare_rules <em>Fare rules</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Fare rules</em>'.
	 * @see mobilityResources.Fare_attribute#getFare_rules()
	 * @see #getFare_attribute()
	 * @generated
	 */
	EReference getFare_attribute_Fare_rules();

	/**
	 * Returns the meta object for class '{@link mobilityResources.Fare_rule <em>Fare rule</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Fare rule</em>'.
	 * @see mobilityResources.Fare_rule
	 * @generated
	 */
	EClass getFare_rule();

	/**
	 * Returns the meta object for the reference '{@link mobilityResources.Fare_rule#getFare <em>Fare</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Fare</em>'.
	 * @see mobilityResources.Fare_rule#getFare()
	 * @see #getFare_rule()
	 * @generated
	 */
	EReference getFare_rule_Fare();

	/**
	 * Returns the meta object for the reference '{@link mobilityResources.Fare_rule#getRoute <em>Route</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Route</em>'.
	 * @see mobilityResources.Fare_rule#getRoute()
	 * @see #getFare_rule()
	 * @generated
	 */
	EReference getFare_rule_Route();

	/**
	 * Returns the meta object for the reference '{@link mobilityResources.Fare_rule#getOrigin <em>Origin</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Origin</em>'.
	 * @see mobilityResources.Fare_rule#getOrigin()
	 * @see #getFare_rule()
	 * @generated
	 */
	EReference getFare_rule_Origin();

	/**
	 * Returns the meta object for the reference '{@link mobilityResources.Fare_rule#getDestination <em>Destination</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Destination</em>'.
	 * @see mobilityResources.Fare_rule#getDestination()
	 * @see #getFare_rule()
	 * @generated
	 */
	EReference getFare_rule_Destination();

	/**
	 * Returns the meta object for the reference '{@link mobilityResources.Fare_rule#getContains <em>Contains</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Contains</em>'.
	 * @see mobilityResources.Fare_rule#getContains()
	 * @see #getFare_rule()
	 * @generated
	 */
	EReference getFare_rule_Contains();

	/**
	 * Returns the meta object for class '{@link mobilityResources.Zone <em>Zone</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Zone</em>'.
	 * @see mobilityResources.Zone
	 * @generated
	 */
	EClass getZone();

	/**
	 * Returns the meta object for the reference list '{@link mobilityResources.Zone#getStops <em>Stops</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Stops</em>'.
	 * @see mobilityResources.Zone#getStops()
	 * @see #getZone()
	 * @generated
	 */
	EReference getZone_Stops();

	/**
	 * Returns the meta object for the reference list '{@link mobilityResources.Zone#getOrigin_fare_rules <em>Origin fare rules</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Origin fare rules</em>'.
	 * @see mobilityResources.Zone#getOrigin_fare_rules()
	 * @see #getZone()
	 * @generated
	 */
	EReference getZone_Origin_fare_rules();

	/**
	 * Returns the meta object for the reference list '{@link mobilityResources.Zone#getDestination_fare_rules <em>Destination fare rules</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Destination fare rules</em>'.
	 * @see mobilityResources.Zone#getDestination_fare_rules()
	 * @see #getZone()
	 * @generated
	 */
	EReference getZone_Destination_fare_rules();

	/**
	 * Returns the meta object for the reference '{@link mobilityResources.Zone#getContains_fare_rules <em>Contains fare rules</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Contains fare rules</em>'.
	 * @see mobilityResources.Zone#getContains_fare_rules()
	 * @see #getZone()
	 * @generated
	 */
	EReference getZone_Contains_fare_rules();

	/**
	 * Returns the meta object for enum '{@link mobilityResources.Location_Type <em>Location Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Location Type</em>'.
	 * @see mobilityResources.Location_Type
	 * @generated
	 */
	EEnum getLocation_Type();

	/**
	 * Returns the meta object for enum '{@link mobilityResources.Accessibility <em>Accessibility</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Accessibility</em>'.
	 * @see mobilityResources.Accessibility
	 * @generated
	 */
	EEnum getAccessibility();

	/**
	 * Returns the meta object for enum '{@link mobilityResources.TravelDirection <em>Travel Direction</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Travel Direction</em>'.
	 * @see mobilityResources.TravelDirection
	 * @generated
	 */
	EEnum getTravelDirection();

	/**
	 * Returns the meta object for enum '{@link mobilityResources.Pickup_Drop_off_Type <em>Pickup Drop off Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Pickup Drop off Type</em>'.
	 * @see mobilityResources.Pickup_Drop_off_Type
	 * @generated
	 */
	EEnum getPickup_Drop_off_Type();

	/**
	 * Returns the meta object for enum '{@link mobilityResources.TimeAdherence <em>Time Adherence</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Time Adherence</em>'.
	 * @see mobilityResources.TimeAdherence
	 * @generated
	 */
	EEnum getTimeAdherence();

	/**
	 * Returns the meta object for enum '{@link mobilityResources.Availability <em>Availability</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Availability</em>'.
	 * @see mobilityResources.Availability
	 * @generated
	 */
	EEnum getAvailability();

	/**
	 * Returns the meta object for enum '{@link mobilityResources.Exception_type <em>Exception type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Exception type</em>'.
	 * @see mobilityResources.Exception_type
	 * @generated
	 */
	EEnum getException_type();

	/**
	 * Returns the meta object for enum '{@link mobilityResources.Payment_method <em>Payment method</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Payment method</em>'.
	 * @see mobilityResources.Payment_method
	 * @generated
	 */
	EEnum getPayment_method();

	/**
	 * Returns the meta object for enum '{@link mobilityResources.Allowed_transfers <em>Allowed transfers</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Allowed transfers</em>'.
	 * @see mobilityResources.Allowed_transfers
	 * @generated
	 */
	EEnum getAllowed_transfers();

	/**
	 * Returns the meta object for enum '{@link mobilityResources.TransitType <em>Transit Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Transit Type</em>'.
	 * @see mobilityResources.TransitType
	 * @generated
	 */
	EEnum getTransitType();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	MobilityResourcesFactory getMobilityResourcesFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link mobilityResources.impl.MobilitySupportImpl <em>Mobility Support</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mobilityResources.impl.MobilitySupportImpl
		 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getMobilitySupport()
		 * @generated
		 */
		EClass MOBILITY_SUPPORT = eINSTANCE.getMobilitySupport();

		/**
		 * The meta object literal for the '<em><b>City</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MOBILITY_SUPPORT__CITY = eINSTANCE.getMobilitySupport_City();

		/**
		 * The meta object literal for the '<em><b>Mobilityresources</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MOBILITY_SUPPORT__MOBILITYRESOURCES = eINSTANCE.getMobilitySupport_Mobilityresources();

		/**
		 * The meta object literal for the '<em><b>Geographic Locations</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MOBILITY_SUPPORT__GEOGRAPHIC_LOCATIONS = eINSTANCE.getMobilitySupport_GeographicLocations();

		/**
		 * The meta object literal for the '<em><b>Agency</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MOBILITY_SUPPORT__AGENCY = eINSTANCE.getMobilitySupport_Agency();

		/**
		 * The meta object literal for the '<em><b>Stop times</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MOBILITY_SUPPORT__STOP_TIMES = eINSTANCE.getMobilitySupport_Stop_times();

		/**
		 * The meta object literal for the '<em><b>Calendar</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MOBILITY_SUPPORT__CALENDAR = eINSTANCE.getMobilitySupport_Calendar();

		/**
		 * The meta object literal for the '<em><b>Calendar dates</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MOBILITY_SUPPORT__CALENDAR_DATES = eINSTANCE.getMobilitySupport_Calendar_dates();

		/**
		 * The meta object literal for the '<em><b>Fares</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MOBILITY_SUPPORT__FARES = eINSTANCE.getMobilitySupport_Fares();

		/**
		 * The meta object literal for the '<em><b>Fare zones</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MOBILITY_SUPPORT__FARE_ZONES = eINSTANCE.getMobilitySupport_Fare_zones();

		/**
		 * The meta object literal for the '{@link mobilityResources.impl.MobilityResourceImpl <em>Mobility Resource</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mobilityResources.impl.MobilityResourceImpl
		 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getMobilityResource()
		 * @generated
		 */
		EClass MOBILITY_RESOURCE = eINSTANCE.getMobilityResource();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MOBILITY_RESOURCE__NAME = eINSTANCE.getMobilityResource_Name();

		/**
		 * The meta object literal for the '<em><b>Last Update</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MOBILITY_RESOURCE__LAST_UPDATE = eINSTANCE.getMobilityResource_LastUpdate();

		/**
		 * The meta object literal for the '<em><b>Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MOBILITY_RESOURCE__ID = eINSTANCE.getMobilityResource_Id();

		/**
		 * The meta object literal for the '{@link mobilityResources.impl.ParkingImpl <em>Parking</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mobilityResources.impl.ParkingImpl
		 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getParking()
		 * @generated
		 */
		EClass PARKING = eINSTANCE.getParking();

		/**
		 * The meta object literal for the '<em><b>Address</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PARKING__ADDRESS = eINSTANCE.getParking_Address();

		/**
		 * The meta object literal for the '<em><b>Slots</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PARKING__SLOTS = eINSTANCE.getParking_Slots();

		/**
		 * The meta object literal for the '<em><b>Total Slots</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PARKING__TOTAL_SLOTS = eINSTANCE.getParking_TotalSlots();

		/**
		 * The meta object literal for the '<em><b>Position</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference PARKING__POSITION = eINSTANCE.getParking_Position();

		/**
		 * The meta object literal for the '{@link mobilityResources.impl.BikeSharingImpl <em>Bike Sharing</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mobilityResources.impl.BikeSharingImpl
		 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getBikeSharing()
		 * @generated
		 */
		EClass BIKE_SHARING = eINSTANCE.getBikeSharing();

		/**
		 * The meta object literal for the '<em><b>Address</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BIKE_SHARING__ADDRESS = eINSTANCE.getBikeSharing_Address();

		/**
		 * The meta object literal for the '<em><b>Bikes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BIKE_SHARING__BIKES = eINSTANCE.getBikeSharing_Bikes();

		/**
		 * The meta object literal for the '<em><b>Slots</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BIKE_SHARING__SLOTS = eINSTANCE.getBikeSharing_Slots();

		/**
		 * The meta object literal for the '<em><b>Total Slots</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BIKE_SHARING__TOTAL_SLOTS = eINSTANCE.getBikeSharing_TotalSlots();

		/**
		 * The meta object literal for the '<em><b>Position</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BIKE_SHARING__POSITION = eINSTANCE.getBikeSharing_Position();

		/**
		 * The meta object literal for the '{@link mobilityResources.impl.GeographicLocationImpl <em>Geographic Location</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mobilityResources.impl.GeographicLocationImpl
		 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getGeographicLocation()
		 * @generated
		 */
		EClass GEOGRAPHIC_LOCATION = eINSTANCE.getGeographicLocation();

		/**
		 * The meta object literal for the '<em><b>Lon</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GEOGRAPHIC_LOCATION__LON = eINSTANCE.getGeographicLocation_Lon();

		/**
		 * The meta object literal for the '<em><b>Lat</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute GEOGRAPHIC_LOCATION__LAT = eINSTANCE.getGeographicLocation_Lat();

		/**
		 * The meta object literal for the '<em><b>Bikesharing</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GEOGRAPHIC_LOCATION__BIKESHARING = eINSTANCE.getGeographicLocation_Bikesharing();

		/**
		 * The meta object literal for the '<em><b>Parking</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GEOGRAPHIC_LOCATION__PARKING = eINSTANCE.getGeographicLocation_Parking();

		/**
		 * The meta object literal for the '<em><b>Stop</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference GEOGRAPHIC_LOCATION__STOP = eINSTANCE.getGeographicLocation_Stop();

		/**
		 * The meta object literal for the '{@link mobilityResources.impl.AgencyImpl <em>Agency</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mobilityResources.impl.AgencyImpl
		 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getAgency()
		 * @generated
		 */
		EClass AGENCY = eINSTANCE.getAgency();

		/**
		 * The meta object literal for the '<em><b>Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AGENCY__ID = eINSTANCE.getAgency_Id();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AGENCY__NAME = eINSTANCE.getAgency_Name();

		/**
		 * The meta object literal for the '<em><b>Url</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AGENCY__URL = eINSTANCE.getAgency_Url();

		/**
		 * The meta object literal for the '<em><b>Timezone</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute AGENCY__TIMEZONE = eINSTANCE.getAgency_Timezone();

		/**
		 * The meta object literal for the '<em><b>Routes</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference AGENCY__ROUTES = eINSTANCE.getAgency_Routes();

		/**
		 * The meta object literal for the '<em><b>Fare attributes</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference AGENCY__FARE_ATTRIBUTES = eINSTANCE.getAgency_Fare_attributes();

		/**
		 * The meta object literal for the '{@link mobilityResources.impl.TransitImpl <em>Transit</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mobilityResources.impl.TransitImpl
		 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getTransit()
		 * @generated
		 */
		EClass TRANSIT = eINSTANCE.getTransit();

		/**
		 * The meta object literal for the '<em><b>Route</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRANSIT__ROUTE = eINSTANCE.getTransit_Route();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSIT__TYPE = eINSTANCE.getTransit_Type();

		/**
		 * The meta object literal for the '{@link mobilityResources.impl.StopImpl <em>Stop</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mobilityResources.impl.StopImpl
		 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getStop()
		 * @generated
		 */
		EClass STOP = eINSTANCE.getStop();

		/**
		 * The meta object literal for the '<em><b>Code</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STOP__CODE = eINSTANCE.getStop_Code();

		/**
		 * The meta object literal for the '<em><b>Desc</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STOP__DESC = eINSTANCE.getStop_Desc();

		/**
		 * The meta object literal for the '<em><b>Stop location</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STOP__STOP_LOCATION = eINSTANCE.getStop_Stop_location();

		/**
		 * The meta object literal for the '<em><b>Url</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STOP__URL = eINSTANCE.getStop_Url();

		/**
		 * The meta object literal for the '<em><b>Location type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STOP__LOCATION_TYPE = eINSTANCE.getStop_Location_type();

		/**
		 * The meta object literal for the '<em><b>Parent station</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STOP__PARENT_STATION = eINSTANCE.getStop_Parent_station();

		/**
		 * The meta object literal for the '<em><b>Wheelchair boarding</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STOP__WHEELCHAIR_BOARDING = eINSTANCE.getStop_Wheelchair_boarding();

		/**
		 * The meta object literal for the '<em><b>Zone</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STOP__ZONE = eINSTANCE.getStop_Zone();

		/**
		 * The meta object literal for the '{@link mobilityResources.impl.RouteImpl <em>Route</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mobilityResources.impl.RouteImpl
		 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getRoute()
		 * @generated
		 */
		EClass ROUTE = eINSTANCE.getRoute();

		/**
		 * The meta object literal for the '<em><b>Long name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ROUTE__LONG_NAME = eINSTANCE.getRoute_Long_name();

		/**
		 * The meta object literal for the '<em><b>Agency</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROUTE__AGENCY = eINSTANCE.getRoute_Agency();

		/**
		 * The meta object literal for the '<em><b>Desc</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ROUTE__DESC = eINSTANCE.getRoute_Desc();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROUTE__TYPE = eINSTANCE.getRoute_Type();

		/**
		 * The meta object literal for the '<em><b>Url</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ROUTE__URL = eINSTANCE.getRoute_Url();

		/**
		 * The meta object literal for the '<em><b>Trips</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROUTE__TRIPS = eINSTANCE.getRoute_Trips();

		/**
		 * The meta object literal for the '<em><b>Fare rules</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ROUTE__FARE_RULES = eINSTANCE.getRoute_Fare_rules();

		/**
		 * The meta object literal for the '{@link mobilityResources.impl.TripImpl <em>Trip</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mobilityResources.impl.TripImpl
		 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getTrip()
		 * @generated
		 */
		EClass TRIP = eINSTANCE.getTrip();

		/**
		 * The meta object literal for the '<em><b>Route</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRIP__ROUTE = eINSTANCE.getTrip_Route();

		/**
		 * The meta object literal for the '<em><b>Service</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRIP__SERVICE = eINSTANCE.getTrip_Service();

		/**
		 * The meta object literal for the '<em><b>Headsign</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRIP__HEADSIGN = eINSTANCE.getTrip_Headsign();

		/**
		 * The meta object literal for the '<em><b>Direction id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRIP__DIRECTION_ID = eINSTANCE.getTrip_Direction_id();

		/**
		 * The meta object literal for the '<em><b>Block</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRIP__BLOCK = eINSTANCE.getTrip_Block();

		/**
		 * The meta object literal for the '<em><b>Wheelchair accessible</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRIP__WHEELCHAIR_ACCESSIBLE = eINSTANCE.getTrip_Wheelchair_accessible();

		/**
		 * The meta object literal for the '<em><b>Bikes allowed</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRIP__BIKES_ALLOWED = eINSTANCE.getTrip_Bikes_allowed();

		/**
		 * The meta object literal for the '<em><b>Service dates</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRIP__SERVICE_DATES = eINSTANCE.getTrip_Service_dates();

		/**
		 * The meta object literal for the '{@link mobilityResources.impl.CalendarImpl <em>Calendar</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mobilityResources.impl.CalendarImpl
		 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getCalendar()
		 * @generated
		 */
		EClass CALENDAR = eINSTANCE.getCalendar();

		/**
		 * The meta object literal for the '<em><b>Service id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CALENDAR__SERVICE_ID = eINSTANCE.getCalendar_Service_id();

		/**
		 * The meta object literal for the '<em><b>Monday</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CALENDAR__MONDAY = eINSTANCE.getCalendar_Monday();

		/**
		 * The meta object literal for the '<em><b>Tuesday</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CALENDAR__TUESDAY = eINSTANCE.getCalendar_Tuesday();

		/**
		 * The meta object literal for the '<em><b>Wednesday</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CALENDAR__WEDNESDAY = eINSTANCE.getCalendar_Wednesday();

		/**
		 * The meta object literal for the '<em><b>Thursday</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CALENDAR__THURSDAY = eINSTANCE.getCalendar_Thursday();

		/**
		 * The meta object literal for the '<em><b>Friday</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CALENDAR__FRIDAY = eINSTANCE.getCalendar_Friday();

		/**
		 * The meta object literal for the '<em><b>Saturday</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CALENDAR__SATURDAY = eINSTANCE.getCalendar_Saturday();

		/**
		 * The meta object literal for the '<em><b>Sunday</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CALENDAR__SUNDAY = eINSTANCE.getCalendar_Sunday();

		/**
		 * The meta object literal for the '<em><b>Start date</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CALENDAR__START_DATE = eINSTANCE.getCalendar_Start_date();

		/**
		 * The meta object literal for the '<em><b>End date</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CALENDAR__END_DATE = eINSTANCE.getCalendar_End_date();

		/**
		 * The meta object literal for the '{@link mobilityResources.impl.BlockImpl <em>Block</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mobilityResources.impl.BlockImpl
		 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getBlock()
		 * @generated
		 */
		EClass BLOCK = eINSTANCE.getBlock();

		/**
		 * The meta object literal for the '<em><b>Trips</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference BLOCK__TRIPS = eINSTANCE.getBlock_Trips();

		/**
		 * The meta object literal for the '{@link mobilityResources.impl.Stop_timeImpl <em>Stop time</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mobilityResources.impl.Stop_timeImpl
		 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getStop_time()
		 * @generated
		 */
		EClass STOP_TIME = eINSTANCE.getStop_time();

		/**
		 * The meta object literal for the '<em><b>Arrival time</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STOP_TIME__ARRIVAL_TIME = eINSTANCE.getStop_time_Arrival_time();

		/**
		 * The meta object literal for the '<em><b>Departure time</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STOP_TIME__DEPARTURE_TIME = eINSTANCE.getStop_time_Departure_time();

		/**
		 * The meta object literal for the '<em><b>Stop</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference STOP_TIME__STOP = eINSTANCE.getStop_time_Stop();

		/**
		 * The meta object literal for the '<em><b>Stop sequence</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STOP_TIME__STOP_SEQUENCE = eINSTANCE.getStop_time_Stop_sequence();

		/**
		 * The meta object literal for the '<em><b>Stop headsign</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STOP_TIME__STOP_HEADSIGN = eINSTANCE.getStop_time_Stop_headsign();

		/**
		 * The meta object literal for the '<em><b>Pickup type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STOP_TIME__PICKUP_TYPE = eINSTANCE.getStop_time_Pickup_type();

		/**
		 * The meta object literal for the '<em><b>Drop off type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STOP_TIME__DROP_OFF_TYPE = eINSTANCE.getStop_time_Drop_off_type();

		/**
		 * The meta object literal for the '<em><b>Shape dist traveled</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STOP_TIME__SHAPE_DIST_TRAVELED = eINSTANCE.getStop_time_Shape_dist_traveled();

		/**
		 * The meta object literal for the '<em><b>Timepoint</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute STOP_TIME__TIMEPOINT = eINSTANCE.getStop_time_Timepoint();

		/**
		 * The meta object literal for the '{@link mobilityResources.impl.Calendar_dateImpl <em>Calendar date</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mobilityResources.impl.Calendar_dateImpl
		 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getCalendar_date()
		 * @generated
		 */
		EClass CALENDAR_DATE = eINSTANCE.getCalendar_date();

		/**
		 * The meta object literal for the '<em><b>Service id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CALENDAR_DATE__SERVICE_ID = eINSTANCE.getCalendar_date_Service_id();

		/**
		 * The meta object literal for the '<em><b>Date</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CALENDAR_DATE__DATE = eINSTANCE.getCalendar_date_Date();

		/**
		 * The meta object literal for the '<em><b>Exception type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CALENDAR_DATE__EXCEPTION_TYPE = eINSTANCE.getCalendar_date_Exception_type();

		/**
		 * The meta object literal for the '{@link mobilityResources.impl.Fare_attributeImpl <em>Fare attribute</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mobilityResources.impl.Fare_attributeImpl
		 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getFare_attribute()
		 * @generated
		 */
		EClass FARE_ATTRIBUTE = eINSTANCE.getFare_attribute();

		/**
		 * The meta object literal for the '<em><b>Fare id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FARE_ATTRIBUTE__FARE_ID = eINSTANCE.getFare_attribute_Fare_id();

		/**
		 * The meta object literal for the '<em><b>Price</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FARE_ATTRIBUTE__PRICE = eINSTANCE.getFare_attribute_Price();

		/**
		 * The meta object literal for the '<em><b>Currency type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FARE_ATTRIBUTE__CURRENCY_TYPE = eINSTANCE.getFare_attribute_Currency_type();

		/**
		 * The meta object literal for the '<em><b>Payment method</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FARE_ATTRIBUTE__PAYMENT_METHOD = eINSTANCE.getFare_attribute_Payment_method();

		/**
		 * The meta object literal for the '<em><b>Transfers</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FARE_ATTRIBUTE__TRANSFERS = eINSTANCE.getFare_attribute_Transfers();

		/**
		 * The meta object literal for the '<em><b>Transfer duration</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute FARE_ATTRIBUTE__TRANSFER_DURATION = eINSTANCE.getFare_attribute_Transfer_duration();

		/**
		 * The meta object literal for the '<em><b>Agency id</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FARE_ATTRIBUTE__AGENCY_ID = eINSTANCE.getFare_attribute_Agency_id();

		/**
		 * The meta object literal for the '<em><b>Fare rules</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FARE_ATTRIBUTE__FARE_RULES = eINSTANCE.getFare_attribute_Fare_rules();

		/**
		 * The meta object literal for the '{@link mobilityResources.impl.Fare_ruleImpl <em>Fare rule</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mobilityResources.impl.Fare_ruleImpl
		 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getFare_rule()
		 * @generated
		 */
		EClass FARE_RULE = eINSTANCE.getFare_rule();

		/**
		 * The meta object literal for the '<em><b>Fare</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FARE_RULE__FARE = eINSTANCE.getFare_rule_Fare();

		/**
		 * The meta object literal for the '<em><b>Route</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FARE_RULE__ROUTE = eINSTANCE.getFare_rule_Route();

		/**
		 * The meta object literal for the '<em><b>Origin</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FARE_RULE__ORIGIN = eINSTANCE.getFare_rule_Origin();

		/**
		 * The meta object literal for the '<em><b>Destination</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FARE_RULE__DESTINATION = eINSTANCE.getFare_rule_Destination();

		/**
		 * The meta object literal for the '<em><b>Contains</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference FARE_RULE__CONTAINS = eINSTANCE.getFare_rule_Contains();

		/**
		 * The meta object literal for the '{@link mobilityResources.impl.ZoneImpl <em>Zone</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mobilityResources.impl.ZoneImpl
		 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getZone()
		 * @generated
		 */
		EClass ZONE = eINSTANCE.getZone();

		/**
		 * The meta object literal for the '<em><b>Stops</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ZONE__STOPS = eINSTANCE.getZone_Stops();

		/**
		 * The meta object literal for the '<em><b>Origin fare rules</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ZONE__ORIGIN_FARE_RULES = eINSTANCE.getZone_Origin_fare_rules();

		/**
		 * The meta object literal for the '<em><b>Destination fare rules</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ZONE__DESTINATION_FARE_RULES = eINSTANCE.getZone_Destination_fare_rules();

		/**
		 * The meta object literal for the '<em><b>Contains fare rules</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference ZONE__CONTAINS_FARE_RULES = eINSTANCE.getZone_Contains_fare_rules();

		/**
		 * The meta object literal for the '{@link mobilityResources.Location_Type <em>Location Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mobilityResources.Location_Type
		 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getLocation_Type()
		 * @generated
		 */
		EEnum LOCATION_TYPE = eINSTANCE.getLocation_Type();

		/**
		 * The meta object literal for the '{@link mobilityResources.Accessibility <em>Accessibility</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mobilityResources.Accessibility
		 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getAccessibility()
		 * @generated
		 */
		EEnum ACCESSIBILITY = eINSTANCE.getAccessibility();

		/**
		 * The meta object literal for the '{@link mobilityResources.TravelDirection <em>Travel Direction</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mobilityResources.TravelDirection
		 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getTravelDirection()
		 * @generated
		 */
		EEnum TRAVEL_DIRECTION = eINSTANCE.getTravelDirection();

		/**
		 * The meta object literal for the '{@link mobilityResources.Pickup_Drop_off_Type <em>Pickup Drop off Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mobilityResources.Pickup_Drop_off_Type
		 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getPickup_Drop_off_Type()
		 * @generated
		 */
		EEnum PICKUP_DROP_OFF_TYPE = eINSTANCE.getPickup_Drop_off_Type();

		/**
		 * The meta object literal for the '{@link mobilityResources.TimeAdherence <em>Time Adherence</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mobilityResources.TimeAdherence
		 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getTimeAdherence()
		 * @generated
		 */
		EEnum TIME_ADHERENCE = eINSTANCE.getTimeAdherence();

		/**
		 * The meta object literal for the '{@link mobilityResources.Availability <em>Availability</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mobilityResources.Availability
		 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getAvailability()
		 * @generated
		 */
		EEnum AVAILABILITY = eINSTANCE.getAvailability();

		/**
		 * The meta object literal for the '{@link mobilityResources.Exception_type <em>Exception type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mobilityResources.Exception_type
		 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getException_type()
		 * @generated
		 */
		EEnum EXCEPTION_TYPE = eINSTANCE.getException_type();

		/**
		 * The meta object literal for the '{@link mobilityResources.Payment_method <em>Payment method</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mobilityResources.Payment_method
		 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getPayment_method()
		 * @generated
		 */
		EEnum PAYMENT_METHOD = eINSTANCE.getPayment_method();

		/**
		 * The meta object literal for the '{@link mobilityResources.Allowed_transfers <em>Allowed transfers</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mobilityResources.Allowed_transfers
		 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getAllowed_transfers()
		 * @generated
		 */
		EEnum ALLOWED_TRANSFERS = eINSTANCE.getAllowed_transfers();

		/**
		 * The meta object literal for the '{@link mobilityResources.TransitType <em>Transit Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see mobilityResources.TransitType
		 * @see mobilityResources.impl.MobilityResourcesPackageImpl#getTransitType()
		 * @generated
		 */
		EEnum TRANSIT_TYPE = eINSTANCE.getTransitType();

	}

} //MobilityResourcesPackage
