/**
 */
package mobilityResources.impl;

import mobilityResources.Calendar_date;
import mobilityResources.Exception_type;
import mobilityResources.MobilityResourcesPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Calendar date</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mobilityResources.impl.Calendar_dateImpl#getService_id <em>Service id</em>}</li>
 *   <li>{@link mobilityResources.impl.Calendar_dateImpl#getDate <em>Date</em>}</li>
 *   <li>{@link mobilityResources.impl.Calendar_dateImpl#getException_type <em>Exception type</em>}</li>
 * </ul>
 *
 * @generated
 */
public class Calendar_dateImpl extends MinimalEObjectImpl.Container implements Calendar_date {
	/**
	 * The default value of the '{@link #getService_id() <em>Service id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getService_id()
	 * @generated
	 * @ordered
	 */
	protected static final String SERVICE_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getService_id() <em>Service id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getService_id()
	 * @generated
	 * @ordered
	 */
	protected String service_id = SERVICE_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getDate() <em>Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDate()
	 * @generated
	 * @ordered
	 */
	protected static final String DATE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDate() <em>Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDate()
	 * @generated
	 * @ordered
	 */
	protected String date = DATE_EDEFAULT;

	/**
	 * The default value of the '{@link #getException_type() <em>Exception type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getException_type()
	 * @generated
	 * @ordered
	 */
	protected static final Exception_type EXCEPTION_TYPE_EDEFAULT = Exception_type.SERVICE_ADDED;

	/**
	 * The cached value of the '{@link #getException_type() <em>Exception type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getException_type()
	 * @generated
	 * @ordered
	 */
	protected Exception_type exception_type = EXCEPTION_TYPE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Calendar_dateImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MobilityResourcesPackage.Literals.CALENDAR_DATE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getService_id() {
		return service_id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setService_id(String newService_id) {
		String oldService_id = service_id;
		service_id = newService_id;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.CALENDAR_DATE__SERVICE_ID,
					oldService_id, service_id));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getDate() {
		return date;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDate(String newDate) {
		String oldDate = date;
		date = newDate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.CALENDAR_DATE__DATE, oldDate,
					date));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Exception_type getException_type() {
		return exception_type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setException_type(Exception_type newException_type) {
		Exception_type oldException_type = exception_type;
		exception_type = newException_type == null ? EXCEPTION_TYPE_EDEFAULT : newException_type;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					MobilityResourcesPackage.CALENDAR_DATE__EXCEPTION_TYPE, oldException_type, exception_type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case MobilityResourcesPackage.CALENDAR_DATE__SERVICE_ID:
			return getService_id();
		case MobilityResourcesPackage.CALENDAR_DATE__DATE:
			return getDate();
		case MobilityResourcesPackage.CALENDAR_DATE__EXCEPTION_TYPE:
			return getException_type();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case MobilityResourcesPackage.CALENDAR_DATE__SERVICE_ID:
			setService_id((String) newValue);
			return;
		case MobilityResourcesPackage.CALENDAR_DATE__DATE:
			setDate((String) newValue);
			return;
		case MobilityResourcesPackage.CALENDAR_DATE__EXCEPTION_TYPE:
			setException_type((Exception_type) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case MobilityResourcesPackage.CALENDAR_DATE__SERVICE_ID:
			setService_id(SERVICE_ID_EDEFAULT);
			return;
		case MobilityResourcesPackage.CALENDAR_DATE__DATE:
			setDate(DATE_EDEFAULT);
			return;
		case MobilityResourcesPackage.CALENDAR_DATE__EXCEPTION_TYPE:
			setException_type(EXCEPTION_TYPE_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case MobilityResourcesPackage.CALENDAR_DATE__SERVICE_ID:
			return SERVICE_ID_EDEFAULT == null ? service_id != null : !SERVICE_ID_EDEFAULT.equals(service_id);
		case MobilityResourcesPackage.CALENDAR_DATE__DATE:
			return DATE_EDEFAULT == null ? date != null : !DATE_EDEFAULT.equals(date);
		case MobilityResourcesPackage.CALENDAR_DATE__EXCEPTION_TYPE:
			return exception_type != EXCEPTION_TYPE_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (service_id: ");
		result.append(service_id);
		result.append(", date: ");
		result.append(date);
		result.append(", exception_type: ");
		result.append(exception_type);
		result.append(')');
		return result.toString();
	}

} //Calendar_dateImpl
