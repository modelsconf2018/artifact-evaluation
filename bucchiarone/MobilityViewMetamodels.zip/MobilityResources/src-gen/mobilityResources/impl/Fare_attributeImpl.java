/**
 */
package mobilityResources.impl;

import java.util.Collection;

import mobilityResources.Agency;
import mobilityResources.Allowed_transfers;
import mobilityResources.Fare_attribute;
import mobilityResources.Fare_rule;
import mobilityResources.MobilityResourcesPackage;
import mobilityResources.Payment_method;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Fare attribute</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mobilityResources.impl.Fare_attributeImpl#getFare_id <em>Fare id</em>}</li>
 *   <li>{@link mobilityResources.impl.Fare_attributeImpl#getPrice <em>Price</em>}</li>
 *   <li>{@link mobilityResources.impl.Fare_attributeImpl#getCurrency_type <em>Currency type</em>}</li>
 *   <li>{@link mobilityResources.impl.Fare_attributeImpl#getPayment_method <em>Payment method</em>}</li>
 *   <li>{@link mobilityResources.impl.Fare_attributeImpl#getTransfers <em>Transfers</em>}</li>
 *   <li>{@link mobilityResources.impl.Fare_attributeImpl#getTransfer_duration <em>Transfer duration</em>}</li>
 *   <li>{@link mobilityResources.impl.Fare_attributeImpl#getAgency_id <em>Agency id</em>}</li>
 *   <li>{@link mobilityResources.impl.Fare_attributeImpl#getFare_rules <em>Fare rules</em>}</li>
 * </ul>
 *
 * @generated
 */
public class Fare_attributeImpl extends MinimalEObjectImpl.Container implements Fare_attribute {
	/**
	 * The default value of the '{@link #getFare_id() <em>Fare id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFare_id()
	 * @generated
	 * @ordered
	 */
	protected static final String FARE_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getFare_id() <em>Fare id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFare_id()
	 * @generated
	 * @ordered
	 */
	protected String fare_id = FARE_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getPrice() <em>Price</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrice()
	 * @generated
	 * @ordered
	 */
	protected static final double PRICE_EDEFAULT = 0.0;

	/**
	 * The cached value of the '{@link #getPrice() <em>Price</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrice()
	 * @generated
	 * @ordered
	 */
	protected double price = PRICE_EDEFAULT;

	/**
	 * The default value of the '{@link #getCurrency_type() <em>Currency type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCurrency_type()
	 * @generated
	 * @ordered
	 */
	protected static final String CURRENCY_TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getCurrency_type() <em>Currency type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCurrency_type()
	 * @generated
	 * @ordered
	 */
	protected String currency_type = CURRENCY_TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getPayment_method() <em>Payment method</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPayment_method()
	 * @generated
	 * @ordered
	 */
	protected static final Payment_method PAYMENT_METHOD_EDEFAULT = Payment_method.ON_BOARD;

	/**
	 * The cached value of the '{@link #getPayment_method() <em>Payment method</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPayment_method()
	 * @generated
	 * @ordered
	 */
	protected Payment_method payment_method = PAYMENT_METHOD_EDEFAULT;

	/**
	 * The default value of the '{@link #getTransfers() <em>Transfers</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTransfers()
	 * @generated
	 * @ordered
	 */
	protected static final Allowed_transfers TRANSFERS_EDEFAULT = Allowed_transfers.NO_TRANSFERS;

	/**
	 * The cached value of the '{@link #getTransfers() <em>Transfers</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTransfers()
	 * @generated
	 * @ordered
	 */
	protected Allowed_transfers transfers = TRANSFERS_EDEFAULT;

	/**
	 * The default value of the '{@link #getTransfer_duration() <em>Transfer duration</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTransfer_duration()
	 * @generated
	 * @ordered
	 */
	protected static final int TRANSFER_DURATION_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getTransfer_duration() <em>Transfer duration</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTransfer_duration()
	 * @generated
	 * @ordered
	 */
	protected int transfer_duration = TRANSFER_DURATION_EDEFAULT;

	/**
	 * The cached value of the '{@link #getAgency_id() <em>Agency id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAgency_id()
	 * @generated
	 * @ordered
	 */
	protected Agency agency_id;

	/**
	 * The cached value of the '{@link #getFare_rules() <em>Fare rules</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFare_rules()
	 * @generated
	 * @ordered
	 */
	protected EList<Fare_rule> fare_rules;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Fare_attributeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MobilityResourcesPackage.Literals.FARE_ATTRIBUTE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getFare_id() {
		return fare_id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setFare_id(String newFare_id) {
		String oldFare_id = fare_id;
		fare_id = newFare_id;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.FARE_ATTRIBUTE__FARE_ID,
					oldFare_id, fare_id));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public double getPrice() {
		return price;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPrice(double newPrice) {
		double oldPrice = price;
		price = newPrice;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.FARE_ATTRIBUTE__PRICE,
					oldPrice, price));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getCurrency_type() {
		return currency_type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCurrency_type(String newCurrency_type) {
		String oldCurrency_type = currency_type;
		currency_type = newCurrency_type;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					MobilityResourcesPackage.FARE_ATTRIBUTE__CURRENCY_TYPE, oldCurrency_type, currency_type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Payment_method getPayment_method() {
		return payment_method;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPayment_method(Payment_method newPayment_method) {
		Payment_method oldPayment_method = payment_method;
		payment_method = newPayment_method == null ? PAYMENT_METHOD_EDEFAULT : newPayment_method;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					MobilityResourcesPackage.FARE_ATTRIBUTE__PAYMENT_METHOD, oldPayment_method, payment_method));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Allowed_transfers getTransfers() {
		return transfers;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTransfers(Allowed_transfers newTransfers) {
		Allowed_transfers oldTransfers = transfers;
		transfers = newTransfers == null ? TRANSFERS_EDEFAULT : newTransfers;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.FARE_ATTRIBUTE__TRANSFERS,
					oldTransfers, transfers));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getTransfer_duration() {
		return transfer_duration;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTransfer_duration(int newTransfer_duration) {
		int oldTransfer_duration = transfer_duration;
		transfer_duration = newTransfer_duration;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					MobilityResourcesPackage.FARE_ATTRIBUTE__TRANSFER_DURATION, oldTransfer_duration,
					transfer_duration));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Agency getAgency_id() {
		if (agency_id != null && agency_id.eIsProxy()) {
			InternalEObject oldAgency_id = (InternalEObject) agency_id;
			agency_id = (Agency) eResolveProxy(oldAgency_id);
			if (agency_id != oldAgency_id) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							MobilityResourcesPackage.FARE_ATTRIBUTE__AGENCY_ID, oldAgency_id, agency_id));
			}
		}
		return agency_id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Agency basicGetAgency_id() {
		return agency_id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetAgency_id(Agency newAgency_id, NotificationChain msgs) {
		Agency oldAgency_id = agency_id;
		agency_id = newAgency_id;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					MobilityResourcesPackage.FARE_ATTRIBUTE__AGENCY_ID, oldAgency_id, newAgency_id);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAgency_id(Agency newAgency_id) {
		if (newAgency_id != agency_id) {
			NotificationChain msgs = null;
			if (agency_id != null)
				msgs = ((InternalEObject) agency_id).eInverseRemove(this,
						MobilityResourcesPackage.AGENCY__FARE_ATTRIBUTES, Agency.class, msgs);
			if (newAgency_id != null)
				msgs = ((InternalEObject) newAgency_id).eInverseAdd(this,
						MobilityResourcesPackage.AGENCY__FARE_ATTRIBUTES, Agency.class, msgs);
			msgs = basicSetAgency_id(newAgency_id, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.FARE_ATTRIBUTE__AGENCY_ID,
					newAgency_id, newAgency_id));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Fare_rule> getFare_rules() {
		if (fare_rules == null) {
			fare_rules = new EObjectWithInverseResolvingEList<Fare_rule>(Fare_rule.class, this,
					MobilityResourcesPackage.FARE_ATTRIBUTE__FARE_RULES, MobilityResourcesPackage.FARE_RULE__FARE);
		}
		return fare_rules;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case MobilityResourcesPackage.FARE_ATTRIBUTE__AGENCY_ID:
			if (agency_id != null)
				msgs = ((InternalEObject) agency_id).eInverseRemove(this,
						MobilityResourcesPackage.AGENCY__FARE_ATTRIBUTES, Agency.class, msgs);
			return basicSetAgency_id((Agency) otherEnd, msgs);
		case MobilityResourcesPackage.FARE_ATTRIBUTE__FARE_RULES:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getFare_rules()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case MobilityResourcesPackage.FARE_ATTRIBUTE__AGENCY_ID:
			return basicSetAgency_id(null, msgs);
		case MobilityResourcesPackage.FARE_ATTRIBUTE__FARE_RULES:
			return ((InternalEList<?>) getFare_rules()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case MobilityResourcesPackage.FARE_ATTRIBUTE__FARE_ID:
			return getFare_id();
		case MobilityResourcesPackage.FARE_ATTRIBUTE__PRICE:
			return getPrice();
		case MobilityResourcesPackage.FARE_ATTRIBUTE__CURRENCY_TYPE:
			return getCurrency_type();
		case MobilityResourcesPackage.FARE_ATTRIBUTE__PAYMENT_METHOD:
			return getPayment_method();
		case MobilityResourcesPackage.FARE_ATTRIBUTE__TRANSFERS:
			return getTransfers();
		case MobilityResourcesPackage.FARE_ATTRIBUTE__TRANSFER_DURATION:
			return getTransfer_duration();
		case MobilityResourcesPackage.FARE_ATTRIBUTE__AGENCY_ID:
			if (resolve)
				return getAgency_id();
			return basicGetAgency_id();
		case MobilityResourcesPackage.FARE_ATTRIBUTE__FARE_RULES:
			return getFare_rules();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case MobilityResourcesPackage.FARE_ATTRIBUTE__FARE_ID:
			setFare_id((String) newValue);
			return;
		case MobilityResourcesPackage.FARE_ATTRIBUTE__PRICE:
			setPrice((Double) newValue);
			return;
		case MobilityResourcesPackage.FARE_ATTRIBUTE__CURRENCY_TYPE:
			setCurrency_type((String) newValue);
			return;
		case MobilityResourcesPackage.FARE_ATTRIBUTE__PAYMENT_METHOD:
			setPayment_method((Payment_method) newValue);
			return;
		case MobilityResourcesPackage.FARE_ATTRIBUTE__TRANSFERS:
			setTransfers((Allowed_transfers) newValue);
			return;
		case MobilityResourcesPackage.FARE_ATTRIBUTE__TRANSFER_DURATION:
			setTransfer_duration((Integer) newValue);
			return;
		case MobilityResourcesPackage.FARE_ATTRIBUTE__AGENCY_ID:
			setAgency_id((Agency) newValue);
			return;
		case MobilityResourcesPackage.FARE_ATTRIBUTE__FARE_RULES:
			getFare_rules().clear();
			getFare_rules().addAll((Collection<? extends Fare_rule>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case MobilityResourcesPackage.FARE_ATTRIBUTE__FARE_ID:
			setFare_id(FARE_ID_EDEFAULT);
			return;
		case MobilityResourcesPackage.FARE_ATTRIBUTE__PRICE:
			setPrice(PRICE_EDEFAULT);
			return;
		case MobilityResourcesPackage.FARE_ATTRIBUTE__CURRENCY_TYPE:
			setCurrency_type(CURRENCY_TYPE_EDEFAULT);
			return;
		case MobilityResourcesPackage.FARE_ATTRIBUTE__PAYMENT_METHOD:
			setPayment_method(PAYMENT_METHOD_EDEFAULT);
			return;
		case MobilityResourcesPackage.FARE_ATTRIBUTE__TRANSFERS:
			setTransfers(TRANSFERS_EDEFAULT);
			return;
		case MobilityResourcesPackage.FARE_ATTRIBUTE__TRANSFER_DURATION:
			setTransfer_duration(TRANSFER_DURATION_EDEFAULT);
			return;
		case MobilityResourcesPackage.FARE_ATTRIBUTE__AGENCY_ID:
			setAgency_id((Agency) null);
			return;
		case MobilityResourcesPackage.FARE_ATTRIBUTE__FARE_RULES:
			getFare_rules().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case MobilityResourcesPackage.FARE_ATTRIBUTE__FARE_ID:
			return FARE_ID_EDEFAULT == null ? fare_id != null : !FARE_ID_EDEFAULT.equals(fare_id);
		case MobilityResourcesPackage.FARE_ATTRIBUTE__PRICE:
			return price != PRICE_EDEFAULT;
		case MobilityResourcesPackage.FARE_ATTRIBUTE__CURRENCY_TYPE:
			return CURRENCY_TYPE_EDEFAULT == null ? currency_type != null
					: !CURRENCY_TYPE_EDEFAULT.equals(currency_type);
		case MobilityResourcesPackage.FARE_ATTRIBUTE__PAYMENT_METHOD:
			return payment_method != PAYMENT_METHOD_EDEFAULT;
		case MobilityResourcesPackage.FARE_ATTRIBUTE__TRANSFERS:
			return transfers != TRANSFERS_EDEFAULT;
		case MobilityResourcesPackage.FARE_ATTRIBUTE__TRANSFER_DURATION:
			return transfer_duration != TRANSFER_DURATION_EDEFAULT;
		case MobilityResourcesPackage.FARE_ATTRIBUTE__AGENCY_ID:
			return agency_id != null;
		case MobilityResourcesPackage.FARE_ATTRIBUTE__FARE_RULES:
			return fare_rules != null && !fare_rules.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (fare_id: ");
		result.append(fare_id);
		result.append(", price: ");
		result.append(price);
		result.append(", currency_type: ");
		result.append(currency_type);
		result.append(", payment_method: ");
		result.append(payment_method);
		result.append(", transfers: ");
		result.append(transfers);
		result.append(", transfer_duration: ");
		result.append(transfer_duration);
		result.append(')');
		return result.toString();
	}

} //Fare_attributeImpl
