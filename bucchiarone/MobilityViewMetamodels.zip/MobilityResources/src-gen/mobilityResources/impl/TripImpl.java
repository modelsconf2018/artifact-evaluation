/**
 */
package mobilityResources.impl;

import mobilityResources.Accessibility;
import mobilityResources.Block;
import mobilityResources.Calendar;
import mobilityResources.Calendar_date;
import mobilityResources.MobilityResourcesPackage;
import mobilityResources.Route;
import mobilityResources.TravelDirection;
import mobilityResources.Trip;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Trip</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mobilityResources.impl.TripImpl#getRoute <em>Route</em>}</li>
 *   <li>{@link mobilityResources.impl.TripImpl#getService <em>Service</em>}</li>
 *   <li>{@link mobilityResources.impl.TripImpl#getHeadsign <em>Headsign</em>}</li>
 *   <li>{@link mobilityResources.impl.TripImpl#getDirection_id <em>Direction id</em>}</li>
 *   <li>{@link mobilityResources.impl.TripImpl#getBlock <em>Block</em>}</li>
 *   <li>{@link mobilityResources.impl.TripImpl#getWheelchair_accessible <em>Wheelchair accessible</em>}</li>
 *   <li>{@link mobilityResources.impl.TripImpl#getBikes_allowed <em>Bikes allowed</em>}</li>
 *   <li>{@link mobilityResources.impl.TripImpl#getService_dates <em>Service dates</em>}</li>
 * </ul>
 *
 * @generated
 */
public class TripImpl extends MobilityResourceImpl implements Trip {
	/**
	 * The cached value of the '{@link #getRoute() <em>Route</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRoute()
	 * @generated
	 * @ordered
	 */
	protected Route route;

	/**
	 * The cached value of the '{@link #getService() <em>Service</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getService()
	 * @generated
	 * @ordered
	 */
	protected Calendar service;

	/**
	 * The default value of the '{@link #getHeadsign() <em>Headsign</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHeadsign()
	 * @generated
	 * @ordered
	 */
	protected static final String HEADSIGN_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getHeadsign() <em>Headsign</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHeadsign()
	 * @generated
	 * @ordered
	 */
	protected String headsign = HEADSIGN_EDEFAULT;

	/**
	 * The default value of the '{@link #getDirection_id() <em>Direction id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDirection_id()
	 * @generated
	 * @ordered
	 */
	protected static final TravelDirection DIRECTION_ID_EDEFAULT = TravelDirection.OUTBOUND;

	/**
	 * The cached value of the '{@link #getDirection_id() <em>Direction id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDirection_id()
	 * @generated
	 * @ordered
	 */
	protected TravelDirection direction_id = DIRECTION_ID_EDEFAULT;

	/**
	 * The cached value of the '{@link #getBlock() <em>Block</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBlock()
	 * @generated
	 * @ordered
	 */
	protected Block block;

	/**
	 * The default value of the '{@link #getWheelchair_accessible() <em>Wheelchair accessible</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWheelchair_accessible()
	 * @generated
	 * @ordered
	 */
	protected static final Accessibility WHEELCHAIR_ACCESSIBLE_EDEFAULT = Accessibility.UNKNOWN;

	/**
	 * The cached value of the '{@link #getWheelchair_accessible() <em>Wheelchair accessible</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWheelchair_accessible()
	 * @generated
	 * @ordered
	 */
	protected Accessibility wheelchair_accessible = WHEELCHAIR_ACCESSIBLE_EDEFAULT;

	/**
	 * The default value of the '{@link #getBikes_allowed() <em>Bikes allowed</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBikes_allowed()
	 * @generated
	 * @ordered
	 */
	protected static final Accessibility BIKES_ALLOWED_EDEFAULT = Accessibility.UNKNOWN;

	/**
	 * The cached value of the '{@link #getBikes_allowed() <em>Bikes allowed</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBikes_allowed()
	 * @generated
	 * @ordered
	 */
	protected Accessibility bikes_allowed = BIKES_ALLOWED_EDEFAULT;

	/**
	 * The cached value of the '{@link #getService_dates() <em>Service dates</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getService_dates()
	 * @generated
	 * @ordered
	 */
	protected Calendar_date service_dates;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TripImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MobilityResourcesPackage.Literals.TRIP;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Route getRoute() {
		if (route != null && route.eIsProxy()) {
			InternalEObject oldRoute = (InternalEObject) route;
			route = (Route) eResolveProxy(oldRoute);
			if (route != oldRoute) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, MobilityResourcesPackage.TRIP__ROUTE,
							oldRoute, route));
			}
		}
		return route;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Route basicGetRoute() {
		return route;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetRoute(Route newRoute, NotificationChain msgs) {
		Route oldRoute = route;
		route = newRoute;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					MobilityResourcesPackage.TRIP__ROUTE, oldRoute, newRoute);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRoute(Route newRoute) {
		if (newRoute != route) {
			NotificationChain msgs = null;
			if (route != null)
				msgs = ((InternalEObject) route).eInverseRemove(this, MobilityResourcesPackage.ROUTE__TRIPS,
						Route.class, msgs);
			if (newRoute != null)
				msgs = ((InternalEObject) newRoute).eInverseAdd(this, MobilityResourcesPackage.ROUTE__TRIPS,
						Route.class, msgs);
			msgs = basicSetRoute(newRoute, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.TRIP__ROUTE, newRoute,
					newRoute));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Calendar getService() {
		if (service != null && service.eIsProxy()) {
			InternalEObject oldService = (InternalEObject) service;
			service = (Calendar) eResolveProxy(oldService);
			if (service != oldService) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, MobilityResourcesPackage.TRIP__SERVICE,
							oldService, service));
			}
		}
		return service;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Calendar basicGetService() {
		return service;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setService(Calendar newService) {
		Calendar oldService = service;
		service = newService;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.TRIP__SERVICE, oldService,
					service));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getHeadsign() {
		return headsign;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setHeadsign(String newHeadsign) {
		String oldHeadsign = headsign;
		headsign = newHeadsign;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.TRIP__HEADSIGN, oldHeadsign,
					headsign));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TravelDirection getDirection_id() {
		return direction_id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDirection_id(TravelDirection newDirection_id) {
		TravelDirection oldDirection_id = direction_id;
		direction_id = newDirection_id == null ? DIRECTION_ID_EDEFAULT : newDirection_id;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.TRIP__DIRECTION_ID,
					oldDirection_id, direction_id));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Block getBlock() {
		if (block != null && block.eIsProxy()) {
			InternalEObject oldBlock = (InternalEObject) block;
			block = (Block) eResolveProxy(oldBlock);
			if (block != oldBlock) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, MobilityResourcesPackage.TRIP__BLOCK,
							oldBlock, block));
			}
		}
		return block;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Block basicGetBlock() {
		return block;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetBlock(Block newBlock, NotificationChain msgs) {
		Block oldBlock = block;
		block = newBlock;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					MobilityResourcesPackage.TRIP__BLOCK, oldBlock, newBlock);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBlock(Block newBlock) {
		if (newBlock != block) {
			NotificationChain msgs = null;
			if (block != null)
				msgs = ((InternalEObject) block).eInverseRemove(this, MobilityResourcesPackage.BLOCK__TRIPS,
						Block.class, msgs);
			if (newBlock != null)
				msgs = ((InternalEObject) newBlock).eInverseAdd(this, MobilityResourcesPackage.BLOCK__TRIPS,
						Block.class, msgs);
			msgs = basicSetBlock(newBlock, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.TRIP__BLOCK, newBlock,
					newBlock));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Accessibility getWheelchair_accessible() {
		return wheelchair_accessible;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setWheelchair_accessible(Accessibility newWheelchair_accessible) {
		Accessibility oldWheelchair_accessible = wheelchair_accessible;
		wheelchair_accessible = newWheelchair_accessible == null ? WHEELCHAIR_ACCESSIBLE_EDEFAULT
				: newWheelchair_accessible;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.TRIP__WHEELCHAIR_ACCESSIBLE,
					oldWheelchair_accessible, wheelchair_accessible));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Accessibility getBikes_allowed() {
		return bikes_allowed;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBikes_allowed(Accessibility newBikes_allowed) {
		Accessibility oldBikes_allowed = bikes_allowed;
		bikes_allowed = newBikes_allowed == null ? BIKES_ALLOWED_EDEFAULT : newBikes_allowed;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.TRIP__BIKES_ALLOWED,
					oldBikes_allowed, bikes_allowed));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Calendar_date getService_dates() {
		if (service_dates != null && service_dates.eIsProxy()) {
			InternalEObject oldService_dates = (InternalEObject) service_dates;
			service_dates = (Calendar_date) eResolveProxy(oldService_dates);
			if (service_dates != oldService_dates) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							MobilityResourcesPackage.TRIP__SERVICE_DATES, oldService_dates, service_dates));
			}
		}
		return service_dates;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Calendar_date basicGetService_dates() {
		return service_dates;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setService_dates(Calendar_date newService_dates) {
		Calendar_date oldService_dates = service_dates;
		service_dates = newService_dates;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.TRIP__SERVICE_DATES,
					oldService_dates, service_dates));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case MobilityResourcesPackage.TRIP__ROUTE:
			if (route != null)
				msgs = ((InternalEObject) route).eInverseRemove(this, MobilityResourcesPackage.ROUTE__TRIPS,
						Route.class, msgs);
			return basicSetRoute((Route) otherEnd, msgs);
		case MobilityResourcesPackage.TRIP__BLOCK:
			if (block != null)
				msgs = ((InternalEObject) block).eInverseRemove(this, MobilityResourcesPackage.BLOCK__TRIPS,
						Block.class, msgs);
			return basicSetBlock((Block) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case MobilityResourcesPackage.TRIP__ROUTE:
			return basicSetRoute(null, msgs);
		case MobilityResourcesPackage.TRIP__BLOCK:
			return basicSetBlock(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case MobilityResourcesPackage.TRIP__ROUTE:
			if (resolve)
				return getRoute();
			return basicGetRoute();
		case MobilityResourcesPackage.TRIP__SERVICE:
			if (resolve)
				return getService();
			return basicGetService();
		case MobilityResourcesPackage.TRIP__HEADSIGN:
			return getHeadsign();
		case MobilityResourcesPackage.TRIP__DIRECTION_ID:
			return getDirection_id();
		case MobilityResourcesPackage.TRIP__BLOCK:
			if (resolve)
				return getBlock();
			return basicGetBlock();
		case MobilityResourcesPackage.TRIP__WHEELCHAIR_ACCESSIBLE:
			return getWheelchair_accessible();
		case MobilityResourcesPackage.TRIP__BIKES_ALLOWED:
			return getBikes_allowed();
		case MobilityResourcesPackage.TRIP__SERVICE_DATES:
			if (resolve)
				return getService_dates();
			return basicGetService_dates();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case MobilityResourcesPackage.TRIP__ROUTE:
			setRoute((Route) newValue);
			return;
		case MobilityResourcesPackage.TRIP__SERVICE:
			setService((Calendar) newValue);
			return;
		case MobilityResourcesPackage.TRIP__HEADSIGN:
			setHeadsign((String) newValue);
			return;
		case MobilityResourcesPackage.TRIP__DIRECTION_ID:
			setDirection_id((TravelDirection) newValue);
			return;
		case MobilityResourcesPackage.TRIP__BLOCK:
			setBlock((Block) newValue);
			return;
		case MobilityResourcesPackage.TRIP__WHEELCHAIR_ACCESSIBLE:
			setWheelchair_accessible((Accessibility) newValue);
			return;
		case MobilityResourcesPackage.TRIP__BIKES_ALLOWED:
			setBikes_allowed((Accessibility) newValue);
			return;
		case MobilityResourcesPackage.TRIP__SERVICE_DATES:
			setService_dates((Calendar_date) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case MobilityResourcesPackage.TRIP__ROUTE:
			setRoute((Route) null);
			return;
		case MobilityResourcesPackage.TRIP__SERVICE:
			setService((Calendar) null);
			return;
		case MobilityResourcesPackage.TRIP__HEADSIGN:
			setHeadsign(HEADSIGN_EDEFAULT);
			return;
		case MobilityResourcesPackage.TRIP__DIRECTION_ID:
			setDirection_id(DIRECTION_ID_EDEFAULT);
			return;
		case MobilityResourcesPackage.TRIP__BLOCK:
			setBlock((Block) null);
			return;
		case MobilityResourcesPackage.TRIP__WHEELCHAIR_ACCESSIBLE:
			setWheelchair_accessible(WHEELCHAIR_ACCESSIBLE_EDEFAULT);
			return;
		case MobilityResourcesPackage.TRIP__BIKES_ALLOWED:
			setBikes_allowed(BIKES_ALLOWED_EDEFAULT);
			return;
		case MobilityResourcesPackage.TRIP__SERVICE_DATES:
			setService_dates((Calendar_date) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case MobilityResourcesPackage.TRIP__ROUTE:
			return route != null;
		case MobilityResourcesPackage.TRIP__SERVICE:
			return service != null;
		case MobilityResourcesPackage.TRIP__HEADSIGN:
			return HEADSIGN_EDEFAULT == null ? headsign != null : !HEADSIGN_EDEFAULT.equals(headsign);
		case MobilityResourcesPackage.TRIP__DIRECTION_ID:
			return direction_id != DIRECTION_ID_EDEFAULT;
		case MobilityResourcesPackage.TRIP__BLOCK:
			return block != null;
		case MobilityResourcesPackage.TRIP__WHEELCHAIR_ACCESSIBLE:
			return wheelchair_accessible != WHEELCHAIR_ACCESSIBLE_EDEFAULT;
		case MobilityResourcesPackage.TRIP__BIKES_ALLOWED:
			return bikes_allowed != BIKES_ALLOWED_EDEFAULT;
		case MobilityResourcesPackage.TRIP__SERVICE_DATES:
			return service_dates != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (headsign: ");
		result.append(headsign);
		result.append(", direction_id: ");
		result.append(direction_id);
		result.append(", wheelchair_accessible: ");
		result.append(wheelchair_accessible);
		result.append(", bikes_allowed: ");
		result.append(bikes_allowed);
		result.append(')');
		return result.toString();
	}

} //TripImpl
