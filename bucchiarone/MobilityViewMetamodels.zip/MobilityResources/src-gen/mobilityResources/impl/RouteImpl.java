/**
 */
package mobilityResources.impl;

import java.util.Collection;

import mobilityResources.Agency;
import mobilityResources.Fare_rule;
import mobilityResources.MobilityResourcesPackage;
import mobilityResources.Route;
import mobilityResources.Transit;
import mobilityResources.Trip;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Route</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mobilityResources.impl.RouteImpl#getLong_name <em>Long name</em>}</li>
 *   <li>{@link mobilityResources.impl.RouteImpl#getAgency <em>Agency</em>}</li>
 *   <li>{@link mobilityResources.impl.RouteImpl#getDesc <em>Desc</em>}</li>
 *   <li>{@link mobilityResources.impl.RouteImpl#getType <em>Type</em>}</li>
 *   <li>{@link mobilityResources.impl.RouteImpl#getUrl <em>Url</em>}</li>
 *   <li>{@link mobilityResources.impl.RouteImpl#getTrips <em>Trips</em>}</li>
 *   <li>{@link mobilityResources.impl.RouteImpl#getFare_rules <em>Fare rules</em>}</li>
 * </ul>
 *
 * @generated
 */
public class RouteImpl extends MobilityResourceImpl implements Route {
	/**
	 * The default value of the '{@link #getLong_name() <em>Long name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLong_name()
	 * @generated
	 * @ordered
	 */
	protected static final String LONG_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getLong_name() <em>Long name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLong_name()
	 * @generated
	 * @ordered
	 */
	protected String long_name = LONG_NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getAgency() <em>Agency</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAgency()
	 * @generated
	 * @ordered
	 */
	protected EList<Agency> agency;

	/**
	 * The default value of the '{@link #getDesc() <em>Desc</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDesc()
	 * @generated
	 * @ordered
	 */
	protected static final String DESC_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDesc() <em>Desc</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDesc()
	 * @generated
	 * @ordered
	 */
	protected String desc = DESC_EDEFAULT;

	/**
	 * The cached value of the '{@link #getType() <em>Type</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getType()
	 * @generated
	 * @ordered
	 */
	protected Transit type;

	/**
	 * The default value of the '{@link #getUrl() <em>Url</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUrl()
	 * @generated
	 * @ordered
	 */
	protected static final String URL_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getUrl() <em>Url</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUrl()
	 * @generated
	 * @ordered
	 */
	protected String url = URL_EDEFAULT;

	/**
	 * The cached value of the '{@link #getTrips() <em>Trips</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTrips()
	 * @generated
	 * @ordered
	 */
	protected EList<Trip> trips;

	/**
	 * The cached value of the '{@link #getFare_rules() <em>Fare rules</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFare_rules()
	 * @generated
	 * @ordered
	 */
	protected EList<Fare_rule> fare_rules;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RouteImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MobilityResourcesPackage.Literals.ROUTE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLong_name() {
		return long_name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLong_name(String newLong_name) {
		String oldLong_name = long_name;
		long_name = newLong_name;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.ROUTE__LONG_NAME,
					oldLong_name, long_name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Agency> getAgency() {
		if (agency == null) {
			agency = new EObjectWithInverseResolvingEList.ManyInverse<Agency>(Agency.class, this,
					MobilityResourcesPackage.ROUTE__AGENCY, MobilityResourcesPackage.AGENCY__ROUTES);
		}
		return agency;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getDesc() {
		return desc;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDesc(String newDesc) {
		String oldDesc = desc;
		desc = newDesc;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.ROUTE__DESC, oldDesc, desc));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Transit getType() {
		if (type != null && type.eIsProxy()) {
			InternalEObject oldType = (InternalEObject) type;
			type = (Transit) eResolveProxy(oldType);
			if (type != oldType) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, MobilityResourcesPackage.ROUTE__TYPE,
							oldType, type));
			}
		}
		return type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Transit basicGetType() {
		return type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetType(Transit newType, NotificationChain msgs) {
		Transit oldType = type;
		type = newType;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					MobilityResourcesPackage.ROUTE__TYPE, oldType, newType);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setType(Transit newType) {
		if (newType != type) {
			NotificationChain msgs = null;
			if (type != null)
				msgs = ((InternalEObject) type).eInverseRemove(this, MobilityResourcesPackage.TRANSIT__ROUTE,
						Transit.class, msgs);
			if (newType != null)
				msgs = ((InternalEObject) newType).eInverseAdd(this, MobilityResourcesPackage.TRANSIT__ROUTE,
						Transit.class, msgs);
			msgs = basicSetType(newType, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.ROUTE__TYPE, newType,
					newType));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setUrl(String newUrl) {
		String oldUrl = url;
		url = newUrl;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MobilityResourcesPackage.ROUTE__URL, oldUrl, url));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Trip> getTrips() {
		if (trips == null) {
			trips = new EObjectWithInverseResolvingEList<Trip>(Trip.class, this, MobilityResourcesPackage.ROUTE__TRIPS,
					MobilityResourcesPackage.TRIP__ROUTE);
		}
		return trips;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Fare_rule> getFare_rules() {
		if (fare_rules == null) {
			fare_rules = new EObjectWithInverseResolvingEList<Fare_rule>(Fare_rule.class, this,
					MobilityResourcesPackage.ROUTE__FARE_RULES, MobilityResourcesPackage.FARE_RULE__ROUTE);
		}
		return fare_rules;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case MobilityResourcesPackage.ROUTE__AGENCY:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getAgency()).basicAdd(otherEnd, msgs);
		case MobilityResourcesPackage.ROUTE__TYPE:
			if (type != null)
				msgs = ((InternalEObject) type).eInverseRemove(this, MobilityResourcesPackage.TRANSIT__ROUTE,
						Transit.class, msgs);
			return basicSetType((Transit) otherEnd, msgs);
		case MobilityResourcesPackage.ROUTE__TRIPS:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getTrips()).basicAdd(otherEnd, msgs);
		case MobilityResourcesPackage.ROUTE__FARE_RULES:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getFare_rules()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case MobilityResourcesPackage.ROUTE__AGENCY:
			return ((InternalEList<?>) getAgency()).basicRemove(otherEnd, msgs);
		case MobilityResourcesPackage.ROUTE__TYPE:
			return basicSetType(null, msgs);
		case MobilityResourcesPackage.ROUTE__TRIPS:
			return ((InternalEList<?>) getTrips()).basicRemove(otherEnd, msgs);
		case MobilityResourcesPackage.ROUTE__FARE_RULES:
			return ((InternalEList<?>) getFare_rules()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case MobilityResourcesPackage.ROUTE__LONG_NAME:
			return getLong_name();
		case MobilityResourcesPackage.ROUTE__AGENCY:
			return getAgency();
		case MobilityResourcesPackage.ROUTE__DESC:
			return getDesc();
		case MobilityResourcesPackage.ROUTE__TYPE:
			if (resolve)
				return getType();
			return basicGetType();
		case MobilityResourcesPackage.ROUTE__URL:
			return getUrl();
		case MobilityResourcesPackage.ROUTE__TRIPS:
			return getTrips();
		case MobilityResourcesPackage.ROUTE__FARE_RULES:
			return getFare_rules();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case MobilityResourcesPackage.ROUTE__LONG_NAME:
			setLong_name((String) newValue);
			return;
		case MobilityResourcesPackage.ROUTE__AGENCY:
			getAgency().clear();
			getAgency().addAll((Collection<? extends Agency>) newValue);
			return;
		case MobilityResourcesPackage.ROUTE__DESC:
			setDesc((String) newValue);
			return;
		case MobilityResourcesPackage.ROUTE__TYPE:
			setType((Transit) newValue);
			return;
		case MobilityResourcesPackage.ROUTE__URL:
			setUrl((String) newValue);
			return;
		case MobilityResourcesPackage.ROUTE__TRIPS:
			getTrips().clear();
			getTrips().addAll((Collection<? extends Trip>) newValue);
			return;
		case MobilityResourcesPackage.ROUTE__FARE_RULES:
			getFare_rules().clear();
			getFare_rules().addAll((Collection<? extends Fare_rule>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case MobilityResourcesPackage.ROUTE__LONG_NAME:
			setLong_name(LONG_NAME_EDEFAULT);
			return;
		case MobilityResourcesPackage.ROUTE__AGENCY:
			getAgency().clear();
			return;
		case MobilityResourcesPackage.ROUTE__DESC:
			setDesc(DESC_EDEFAULT);
			return;
		case MobilityResourcesPackage.ROUTE__TYPE:
			setType((Transit) null);
			return;
		case MobilityResourcesPackage.ROUTE__URL:
			setUrl(URL_EDEFAULT);
			return;
		case MobilityResourcesPackage.ROUTE__TRIPS:
			getTrips().clear();
			return;
		case MobilityResourcesPackage.ROUTE__FARE_RULES:
			getFare_rules().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case MobilityResourcesPackage.ROUTE__LONG_NAME:
			return LONG_NAME_EDEFAULT == null ? long_name != null : !LONG_NAME_EDEFAULT.equals(long_name);
		case MobilityResourcesPackage.ROUTE__AGENCY:
			return agency != null && !agency.isEmpty();
		case MobilityResourcesPackage.ROUTE__DESC:
			return DESC_EDEFAULT == null ? desc != null : !DESC_EDEFAULT.equals(desc);
		case MobilityResourcesPackage.ROUTE__TYPE:
			return type != null;
		case MobilityResourcesPackage.ROUTE__URL:
			return URL_EDEFAULT == null ? url != null : !URL_EDEFAULT.equals(url);
		case MobilityResourcesPackage.ROUTE__TRIPS:
			return trips != null && !trips.isEmpty();
		case MobilityResourcesPackage.ROUTE__FARE_RULES:
			return fare_rules != null && !fare_rules.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (long_name: ");
		result.append(long_name);
		result.append(", desc: ");
		result.append(desc);
		result.append(", url: ");
		result.append(url);
		result.append(')');
		return result.toString();
	}

} //RouteImpl
