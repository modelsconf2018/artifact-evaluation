/**
 */
package mobilityResources.impl;

import mobilityResources.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class MobilityResourcesFactoryImpl extends EFactoryImpl implements MobilityResourcesFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static MobilityResourcesFactory init() {
		try {
			MobilityResourcesFactory theMobilityResourcesFactory = (MobilityResourcesFactory) EPackage.Registry.INSTANCE
					.getEFactory(MobilityResourcesPackage.eNS_URI);
			if (theMobilityResourcesFactory != null) {
				return theMobilityResourcesFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new MobilityResourcesFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MobilityResourcesFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case MobilityResourcesPackage.MOBILITY_SUPPORT:
			return createMobilitySupport();
		case MobilityResourcesPackage.PARKING:
			return createParking();
		case MobilityResourcesPackage.BIKE_SHARING:
			return createBikeSharing();
		case MobilityResourcesPackage.GEOGRAPHIC_LOCATION:
			return createGeographicLocation();
		case MobilityResourcesPackage.AGENCY:
			return createAgency();
		case MobilityResourcesPackage.TRANSIT:
			return createTransit();
		case MobilityResourcesPackage.STOP:
			return createStop();
		case MobilityResourcesPackage.ROUTE:
			return createRoute();
		case MobilityResourcesPackage.TRIP:
			return createTrip();
		case MobilityResourcesPackage.CALENDAR:
			return createCalendar();
		case MobilityResourcesPackage.BLOCK:
			return createBlock();
		case MobilityResourcesPackage.STOP_TIME:
			return createStop_time();
		case MobilityResourcesPackage.CALENDAR_DATE:
			return createCalendar_date();
		case MobilityResourcesPackage.FARE_ATTRIBUTE:
			return createFare_attribute();
		case MobilityResourcesPackage.FARE_RULE:
			return createFare_rule();
		case MobilityResourcesPackage.ZONE:
			return createZone();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
		case MobilityResourcesPackage.LOCATION_TYPE:
			return createLocation_TypeFromString(eDataType, initialValue);
		case MobilityResourcesPackage.ACCESSIBILITY:
			return createAccessibilityFromString(eDataType, initialValue);
		case MobilityResourcesPackage.TRAVEL_DIRECTION:
			return createTravelDirectionFromString(eDataType, initialValue);
		case MobilityResourcesPackage.PICKUP_DROP_OFF_TYPE:
			return createPickup_Drop_off_TypeFromString(eDataType, initialValue);
		case MobilityResourcesPackage.TIME_ADHERENCE:
			return createTimeAdherenceFromString(eDataType, initialValue);
		case MobilityResourcesPackage.AVAILABILITY:
			return createAvailabilityFromString(eDataType, initialValue);
		case MobilityResourcesPackage.EXCEPTION_TYPE:
			return createException_typeFromString(eDataType, initialValue);
		case MobilityResourcesPackage.PAYMENT_METHOD:
			return createPayment_methodFromString(eDataType, initialValue);
		case MobilityResourcesPackage.ALLOWED_TRANSFERS:
			return createAllowed_transfersFromString(eDataType, initialValue);
		case MobilityResourcesPackage.TRANSIT_TYPE:
			return createTransitTypeFromString(eDataType, initialValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
		case MobilityResourcesPackage.LOCATION_TYPE:
			return convertLocation_TypeToString(eDataType, instanceValue);
		case MobilityResourcesPackage.ACCESSIBILITY:
			return convertAccessibilityToString(eDataType, instanceValue);
		case MobilityResourcesPackage.TRAVEL_DIRECTION:
			return convertTravelDirectionToString(eDataType, instanceValue);
		case MobilityResourcesPackage.PICKUP_DROP_OFF_TYPE:
			return convertPickup_Drop_off_TypeToString(eDataType, instanceValue);
		case MobilityResourcesPackage.TIME_ADHERENCE:
			return convertTimeAdherenceToString(eDataType, instanceValue);
		case MobilityResourcesPackage.AVAILABILITY:
			return convertAvailabilityToString(eDataType, instanceValue);
		case MobilityResourcesPackage.EXCEPTION_TYPE:
			return convertException_typeToString(eDataType, instanceValue);
		case MobilityResourcesPackage.PAYMENT_METHOD:
			return convertPayment_methodToString(eDataType, instanceValue);
		case MobilityResourcesPackage.ALLOWED_TRANSFERS:
			return convertAllowed_transfersToString(eDataType, instanceValue);
		case MobilityResourcesPackage.TRANSIT_TYPE:
			return convertTransitTypeToString(eDataType, instanceValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MobilitySupport createMobilitySupport() {
		MobilitySupportImpl mobilitySupport = new MobilitySupportImpl();
		return mobilitySupport;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Parking createParking() {
		ParkingImpl parking = new ParkingImpl();
		return parking;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BikeSharing createBikeSharing() {
		BikeSharingImpl bikeSharing = new BikeSharingImpl();
		return bikeSharing;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public GeographicLocation createGeographicLocation() {
		GeographicLocationImpl geographicLocation = new GeographicLocationImpl();
		return geographicLocation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Agency createAgency() {
		AgencyImpl agency = new AgencyImpl();
		return agency;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Transit createTransit() {
		TransitImpl transit = new TransitImpl();
		return transit;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Stop createStop() {
		StopImpl stop = new StopImpl();
		return stop;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Route createRoute() {
		RouteImpl route = new RouteImpl();
		return route;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Trip createTrip() {
		TripImpl trip = new TripImpl();
		return trip;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Calendar createCalendar() {
		CalendarImpl calendar = new CalendarImpl();
		return calendar;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Block createBlock() {
		BlockImpl block = new BlockImpl();
		return block;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Stop_time createStop_time() {
		Stop_timeImpl stop_time = new Stop_timeImpl();
		return stop_time;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Calendar_date createCalendar_date() {
		Calendar_dateImpl calendar_date = new Calendar_dateImpl();
		return calendar_date;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Fare_attribute createFare_attribute() {
		Fare_attributeImpl fare_attribute = new Fare_attributeImpl();
		return fare_attribute;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Fare_rule createFare_rule() {
		Fare_ruleImpl fare_rule = new Fare_ruleImpl();
		return fare_rule;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Zone createZone() {
		ZoneImpl zone = new ZoneImpl();
		return zone;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Location_Type createLocation_TypeFromString(EDataType eDataType, String initialValue) {
		Location_Type result = Location_Type.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertLocation_TypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Accessibility createAccessibilityFromString(EDataType eDataType, String initialValue) {
		Accessibility result = Accessibility.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertAccessibilityToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TravelDirection createTravelDirectionFromString(EDataType eDataType, String initialValue) {
		TravelDirection result = TravelDirection.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertTravelDirectionToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Pickup_Drop_off_Type createPickup_Drop_off_TypeFromString(EDataType eDataType, String initialValue) {
		Pickup_Drop_off_Type result = Pickup_Drop_off_Type.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertPickup_Drop_off_TypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TimeAdherence createTimeAdherenceFromString(EDataType eDataType, String initialValue) {
		TimeAdherence result = TimeAdherence.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertTimeAdherenceToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Availability createAvailabilityFromString(EDataType eDataType, String initialValue) {
		Availability result = Availability.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertAvailabilityToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Exception_type createException_typeFromString(EDataType eDataType, String initialValue) {
		Exception_type result = Exception_type.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertException_typeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Payment_method createPayment_methodFromString(EDataType eDataType, String initialValue) {
		Payment_method result = Payment_method.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertPayment_methodToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Allowed_transfers createAllowed_transfersFromString(EDataType eDataType, String initialValue) {
		Allowed_transfers result = Allowed_transfers.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertAllowed_transfersToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TransitType createTransitTypeFromString(EDataType eDataType, String initialValue) {
		TransitType result = TransitType.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertTransitTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MobilityResourcesPackage getMobilityResourcesPackage() {
		return (MobilityResourcesPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static MobilityResourcesPackage getPackage() {
		return MobilityResourcesPackage.eINSTANCE;
	}

} //MobilityResourcesFactoryImpl
