/**
 */
package mobilityResources;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Stop time</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mobilityResources.Stop_time#getArrival_time <em>Arrival time</em>}</li>
 *   <li>{@link mobilityResources.Stop_time#getDeparture_time <em>Departure time</em>}</li>
 *   <li>{@link mobilityResources.Stop_time#getStop <em>Stop</em>}</li>
 *   <li>{@link mobilityResources.Stop_time#getStop_sequence <em>Stop sequence</em>}</li>
 *   <li>{@link mobilityResources.Stop_time#getStop_headsign <em>Stop headsign</em>}</li>
 *   <li>{@link mobilityResources.Stop_time#getPickup_type <em>Pickup type</em>}</li>
 *   <li>{@link mobilityResources.Stop_time#getDrop_off_type <em>Drop off type</em>}</li>
 *   <li>{@link mobilityResources.Stop_time#getShape_dist_traveled <em>Shape dist traveled</em>}</li>
 *   <li>{@link mobilityResources.Stop_time#getTimepoint <em>Timepoint</em>}</li>
 * </ul>
 *
 * @see mobilityResources.MobilityResourcesPackage#getStop_time()
 * @model
 * @generated
 */
public interface Stop_time extends EObject {
	/**
	 * Returns the value of the '<em><b>Arrival time</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Arrival time</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Arrival time</em>' attribute.
	 * @see #setArrival_time(String)
	 * @see mobilityResources.MobilityResourcesPackage#getStop_time_Arrival_time()
	 * @model
	 * @generated
	 */
	String getArrival_time();

	/**
	 * Sets the value of the '{@link mobilityResources.Stop_time#getArrival_time <em>Arrival time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Arrival time</em>' attribute.
	 * @see #getArrival_time()
	 * @generated
	 */
	void setArrival_time(String value);

	/**
	 * Returns the value of the '<em><b>Departure time</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Departure time</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Departure time</em>' attribute.
	 * @see #setDeparture_time(String)
	 * @see mobilityResources.MobilityResourcesPackage#getStop_time_Departure_time()
	 * @model
	 * @generated
	 */
	String getDeparture_time();

	/**
	 * Sets the value of the '{@link mobilityResources.Stop_time#getDeparture_time <em>Departure time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Departure time</em>' attribute.
	 * @see #getDeparture_time()
	 * @generated
	 */
	void setDeparture_time(String value);

	/**
	 * Returns the value of the '<em><b>Stop</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Stop</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Stop</em>' reference.
	 * @see #setStop(Stop)
	 * @see mobilityResources.MobilityResourcesPackage#getStop_time_Stop()
	 * @model
	 * @generated
	 */
	Stop getStop();

	/**
	 * Sets the value of the '{@link mobilityResources.Stop_time#getStop <em>Stop</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Stop</em>' reference.
	 * @see #getStop()
	 * @generated
	 */
	void setStop(Stop value);

	/**
	 * Returns the value of the '<em><b>Stop sequence</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Stop sequence</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Stop sequence</em>' attribute.
	 * @see #setStop_sequence(int)
	 * @see mobilityResources.MobilityResourcesPackage#getStop_time_Stop_sequence()
	 * @model
	 * @generated
	 */
	int getStop_sequence();

	/**
	 * Sets the value of the '{@link mobilityResources.Stop_time#getStop_sequence <em>Stop sequence</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Stop sequence</em>' attribute.
	 * @see #getStop_sequence()
	 * @generated
	 */
	void setStop_sequence(int value);

	/**
	 * Returns the value of the '<em><b>Stop headsign</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Stop headsign</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Stop headsign</em>' attribute.
	 * @see #setStop_headsign(String)
	 * @see mobilityResources.MobilityResourcesPackage#getStop_time_Stop_headsign()
	 * @model
	 * @generated
	 */
	String getStop_headsign();

	/**
	 * Sets the value of the '{@link mobilityResources.Stop_time#getStop_headsign <em>Stop headsign</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Stop headsign</em>' attribute.
	 * @see #getStop_headsign()
	 * @generated
	 */
	void setStop_headsign(String value);

	/**
	 * Returns the value of the '<em><b>Pickup type</b></em>' attribute.
	 * The literals are from the enumeration {@link mobilityResources.Pickup_Drop_off_Type}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Pickup type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pickup type</em>' attribute.
	 * @see mobilityResources.Pickup_Drop_off_Type
	 * @see #setPickup_type(Pickup_Drop_off_Type)
	 * @see mobilityResources.MobilityResourcesPackage#getStop_time_Pickup_type()
	 * @model
	 * @generated
	 */
	Pickup_Drop_off_Type getPickup_type();

	/**
	 * Sets the value of the '{@link mobilityResources.Stop_time#getPickup_type <em>Pickup type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Pickup type</em>' attribute.
	 * @see mobilityResources.Pickup_Drop_off_Type
	 * @see #getPickup_type()
	 * @generated
	 */
	void setPickup_type(Pickup_Drop_off_Type value);

	/**
	 * Returns the value of the '<em><b>Drop off type</b></em>' attribute.
	 * The literals are from the enumeration {@link mobilityResources.Pickup_Drop_off_Type}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Drop off type</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Drop off type</em>' attribute.
	 * @see mobilityResources.Pickup_Drop_off_Type
	 * @see #setDrop_off_type(Pickup_Drop_off_Type)
	 * @see mobilityResources.MobilityResourcesPackage#getStop_time_Drop_off_type()
	 * @model
	 * @generated
	 */
	Pickup_Drop_off_Type getDrop_off_type();

	/**
	 * Sets the value of the '{@link mobilityResources.Stop_time#getDrop_off_type <em>Drop off type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Drop off type</em>' attribute.
	 * @see mobilityResources.Pickup_Drop_off_Type
	 * @see #getDrop_off_type()
	 * @generated
	 */
	void setDrop_off_type(Pickup_Drop_off_Type value);

	/**
	 * Returns the value of the '<em><b>Shape dist traveled</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Shape dist traveled</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Shape dist traveled</em>' attribute.
	 * @see #setShape_dist_traveled(String)
	 * @see mobilityResources.MobilityResourcesPackage#getStop_time_Shape_dist_traveled()
	 * @model
	 * @generated
	 */
	String getShape_dist_traveled();

	/**
	 * Sets the value of the '{@link mobilityResources.Stop_time#getShape_dist_traveled <em>Shape dist traveled</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Shape dist traveled</em>' attribute.
	 * @see #getShape_dist_traveled()
	 * @generated
	 */
	void setShape_dist_traveled(String value);

	/**
	 * Returns the value of the '<em><b>Timepoint</b></em>' attribute.
	 * The literals are from the enumeration {@link mobilityResources.TimeAdherence}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Timepoint</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Timepoint</em>' attribute.
	 * @see mobilityResources.TimeAdherence
	 * @see #setTimepoint(TimeAdherence)
	 * @see mobilityResources.MobilityResourcesPackage#getStop_time_Timepoint()
	 * @model
	 * @generated
	 */
	TimeAdherence getTimepoint();

	/**
	 * Sets the value of the '{@link mobilityResources.Stop_time#getTimepoint <em>Timepoint</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Timepoint</em>' attribute.
	 * @see mobilityResources.TimeAdherence
	 * @see #getTimepoint()
	 * @generated
	 */
	void setTimepoint(TimeAdherence value);

} // Stop_time
