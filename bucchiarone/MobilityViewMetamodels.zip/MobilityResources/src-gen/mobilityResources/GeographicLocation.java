/**
 */
package mobilityResources;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Geographic Location</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mobilityResources.GeographicLocation#getLon <em>Lon</em>}</li>
 *   <li>{@link mobilityResources.GeographicLocation#getLat <em>Lat</em>}</li>
 *   <li>{@link mobilityResources.GeographicLocation#getBikesharing <em>Bikesharing</em>}</li>
 *   <li>{@link mobilityResources.GeographicLocation#getParking <em>Parking</em>}</li>
 *   <li>{@link mobilityResources.GeographicLocation#getStop <em>Stop</em>}</li>
 * </ul>
 *
 * @see mobilityResources.MobilityResourcesPackage#getGeographicLocation()
 * @model
 * @generated
 */
public interface GeographicLocation extends EObject {
	/**
	 * Returns the value of the '<em><b>Lon</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Lon</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Lon</em>' attribute.
	 * @see #setLon(String)
	 * @see mobilityResources.MobilityResourcesPackage#getGeographicLocation_Lon()
	 * @model
	 * @generated
	 */
	String getLon();

	/**
	 * Sets the value of the '{@link mobilityResources.GeographicLocation#getLon <em>Lon</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Lon</em>' attribute.
	 * @see #getLon()
	 * @generated
	 */
	void setLon(String value);

	/**
	 * Returns the value of the '<em><b>Lat</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Lat</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Lat</em>' attribute.
	 * @see #setLat(String)
	 * @see mobilityResources.MobilityResourcesPackage#getGeographicLocation_Lat()
	 * @model
	 * @generated
	 */
	String getLat();

	/**
	 * Sets the value of the '{@link mobilityResources.GeographicLocation#getLat <em>Lat</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Lat</em>' attribute.
	 * @see #getLat()
	 * @generated
	 */
	void setLat(String value);

	/**
	 * Returns the value of the '<em><b>Bikesharing</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link mobilityResources.BikeSharing#getPosition <em>Position</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Bikesharing</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Bikesharing</em>' reference.
	 * @see #setBikesharing(BikeSharing)
	 * @see mobilityResources.MobilityResourcesPackage#getGeographicLocation_Bikesharing()
	 * @see mobilityResources.BikeSharing#getPosition
	 * @model opposite="position"
	 * @generated
	 */
	BikeSharing getBikesharing();

	/**
	 * Sets the value of the '{@link mobilityResources.GeographicLocation#getBikesharing <em>Bikesharing</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Bikesharing</em>' reference.
	 * @see #getBikesharing()
	 * @generated
	 */
	void setBikesharing(BikeSharing value);

	/**
	 * Returns the value of the '<em><b>Parking</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link mobilityResources.Parking#getPosition <em>Position</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Parking</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Parking</em>' reference.
	 * @see #setParking(Parking)
	 * @see mobilityResources.MobilityResourcesPackage#getGeographicLocation_Parking()
	 * @see mobilityResources.Parking#getPosition
	 * @model opposite="position"
	 * @generated
	 */
	Parking getParking();

	/**
	 * Sets the value of the '{@link mobilityResources.GeographicLocation#getParking <em>Parking</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Parking</em>' reference.
	 * @see #getParking()
	 * @generated
	 */
	void setParking(Parking value);

	/**
	 * Returns the value of the '<em><b>Stop</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link mobilityResources.Stop#getStop_location <em>Stop location</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Stop</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Stop</em>' reference.
	 * @see #setStop(Stop)
	 * @see mobilityResources.MobilityResourcesPackage#getGeographicLocation_Stop()
	 * @see mobilityResources.Stop#getStop_location
	 * @model opposite="stop_location"
	 * @generated
	 */
	Stop getStop();

	/**
	 * Sets the value of the '{@link mobilityResources.GeographicLocation#getStop <em>Stop</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Stop</em>' reference.
	 * @see #getStop()
	 * @generated
	 */
	void setStop(Stop value);

} // GeographicLocation
