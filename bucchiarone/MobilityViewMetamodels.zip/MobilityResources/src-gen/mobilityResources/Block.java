/**
 */
package mobilityResources;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Block</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mobilityResources.Block#getTrips <em>Trips</em>}</li>
 * </ul>
 *
 * @see mobilityResources.MobilityResourcesPackage#getBlock()
 * @model
 * @generated
 */
public interface Block extends MobilityResource {
	/**
	 * Returns the value of the '<em><b>Trips</b></em>' reference list.
	 * The list contents are of type {@link mobilityResources.Trip}.
	 * It is bidirectional and its opposite is '{@link mobilityResources.Trip#getBlock <em>Block</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Trips</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Trips</em>' reference list.
	 * @see mobilityResources.MobilityResourcesPackage#getBlock_Trips()
	 * @see mobilityResources.Trip#getBlock
	 * @model opposite="block"
	 * @generated
	 */
	EList<Trip> getTrips();

} // Block
