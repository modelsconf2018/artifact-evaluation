/**
 */
package mapNotes.tests;

import junit.framework.TestCase;

import junit.textui.TestRunner;

import mapNotes.MapNotesFactory;
import mapNotes.VehicleDescriptor;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Vehicle Descriptor</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class VehicleDescriptorTest extends TestCase {

	/**
	 * The fixture for this Vehicle Descriptor test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected VehicleDescriptor fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(VehicleDescriptorTest.class);
	}

	/**
	 * Constructs a new Vehicle Descriptor test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VehicleDescriptorTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Vehicle Descriptor test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(VehicleDescriptor fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Vehicle Descriptor test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected VehicleDescriptor getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(MapNotesFactory.eINSTANCE.createVehicleDescriptor());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //VehicleDescriptorTest
