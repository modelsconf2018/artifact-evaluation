/**
 */
package mapNotes.tests;

import junit.framework.TestCase;

import junit.textui.TestRunner;

import mapNotes.MapNotesFactory;
import mapNotes.StopTimeEvent;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Stop Time Event</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class StopTimeEventTest extends TestCase {

	/**
	 * The fixture for this Stop Time Event test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected StopTimeEvent fixture = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(StopTimeEventTest.class);
	}

	/**
	 * Constructs a new Stop Time Event test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public StopTimeEventTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Stop Time Event test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(StopTimeEvent fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Stop Time Event test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected StopTimeEvent getFixture() {
		return fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(MapNotesFactory.eINSTANCE.createStopTimeEvent());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //StopTimeEventTest
