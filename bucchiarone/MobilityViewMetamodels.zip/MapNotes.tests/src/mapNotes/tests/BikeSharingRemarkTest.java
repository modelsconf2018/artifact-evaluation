/**
 */
package mapNotes.tests;

import junit.textui.TestRunner;

import mapNotes.BikeSharingRemark;
import mapNotes.MapNotesFactory;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Bike Sharing Remark</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class BikeSharingRemarkTest extends StatusRemarkTest {

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(BikeSharingRemarkTest.class);
	}

	/**
	 * Constructs a new Bike Sharing Remark test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BikeSharingRemarkTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Bike Sharing Remark test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected BikeSharingRemark getFixture() {
		return (BikeSharingRemark)fixture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#setUp()
	 * @generated
	 */
	@Override
	protected void setUp() throws Exception {
		setFixture(MapNotesFactory.eINSTANCE.createBikeSharingRemark());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see junit.framework.TestCase#tearDown()
	 * @generated
	 */
	@Override
	protected void tearDown() throws Exception {
		setFixture(null);
	}

} //BikeSharingRemarkTest
