/**
 */
package newTravelPlanner.util;

import newTravelPlanner.*;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see newTravelPlanner.NewTravelPlannerPackage
 * @generated
 */
public class NewTravelPlannerSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static NewTravelPlannerPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NewTravelPlannerSwitch() {
		if (modelPackage == null) {
			modelPackage = NewTravelPlannerPackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
		case NewTravelPlannerPackage.TRAVEL_PLANNER: {
			TravelPlanner travelPlanner = (TravelPlanner) theEObject;
			T result = caseTravelPlanner(travelPlanner);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case NewTravelPlannerPackage.PRE_CALL_POLICY: {
			PreCallPolicy preCallPolicy = (PreCallPolicy) theEObject;
			T result = casePreCallPolicy(preCallPolicy);
			if (result == null)
				result = casePolicy(preCallPolicy);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case NewTravelPlannerPackage.POLICY: {
			Policy policy = (Policy) theEObject;
			T result = casePolicy(policy);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case NewTravelPlannerPackage.TRANSPORT_TYPE: {
			TransportType transportType = (TransportType) theEObject;
			T result = caseTransportType(transportType);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case NewTravelPlannerPackage.SMART_PLANNER_PARAMETERS: {
			SmartPlannerParameters smartPlannerParameters = (SmartPlannerParameters) theEObject;
			T result = caseSmartPlannerParameters(smartPlannerParameters);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case NewTravelPlannerPackage.TTYPE_POLICY: {
			TTypePolicy tTypePolicy = (TTypePolicy) theEObject;
			T result = caseTTypePolicy(tTypePolicy);
			if (result == null)
				result = casePolicy(tTypePolicy);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case NewTravelPlannerPackage.RTYPE_POLICY: {
			RTypePolicy rTypePolicy = (RTypePolicy) theEObject;
			T result = caseRTypePolicy(rTypePolicy);
			if (result == null)
				result = casePolicy(rTypePolicy);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case NewTravelPlannerPackage.ROUTE_TYPE: {
			RouteType routeType = (RouteType) theEObject;
			T result = caseRouteType(routeType);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case NewTravelPlannerPackage.POST_CALL_POLICY: {
			PostCallPolicy postCallPolicy = (PostCallPolicy) theEObject;
			T result = casePostCallPolicy(postCallPolicy);
			if (result == null)
				result = casePolicy(postCallPolicy);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		default:
			return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Travel Planner</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Travel Planner</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTravelPlanner(TravelPlanner object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Pre Call Policy</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Pre Call Policy</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePreCallPolicy(PreCallPolicy object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Policy</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Policy</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePolicy(Policy object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Transport Type</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Transport Type</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTransportType(TransportType object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Smart Planner Parameters</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Smart Planner Parameters</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSmartPlannerParameters(SmartPlannerParameters object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>TType Policy</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>TType Policy</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTTypePolicy(TTypePolicy object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>RType Policy</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>RType Policy</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseRTypePolicy(RTypePolicy object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Route Type</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Route Type</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseRouteType(RouteType object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Post Call Policy</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Post Call Policy</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePostCallPolicy(PostCallPolicy object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //NewTravelPlannerSwitch
