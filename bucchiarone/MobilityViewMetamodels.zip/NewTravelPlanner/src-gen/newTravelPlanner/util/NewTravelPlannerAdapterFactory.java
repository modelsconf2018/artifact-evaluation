/**
 */
package newTravelPlanner.util;

import newTravelPlanner.*;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see newTravelPlanner.NewTravelPlannerPackage
 * @generated
 */
public class NewTravelPlannerAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static NewTravelPlannerPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NewTravelPlannerAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = NewTravelPlannerPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject) object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected NewTravelPlannerSwitch<Adapter> modelSwitch = new NewTravelPlannerSwitch<Adapter>() {
		@Override
		public Adapter caseTravelPlanner(TravelPlanner object) {
			return createTravelPlannerAdapter();
		}

		@Override
		public Adapter casePreCallPolicy(PreCallPolicy object) {
			return createPreCallPolicyAdapter();
		}

		@Override
		public Adapter casePolicy(Policy object) {
			return createPolicyAdapter();
		}

		@Override
		public Adapter caseTransportType(TransportType object) {
			return createTransportTypeAdapter();
		}

		@Override
		public Adapter caseSmartPlannerParameters(SmartPlannerParameters object) {
			return createSmartPlannerParametersAdapter();
		}

		@Override
		public Adapter caseTTypePolicy(TTypePolicy object) {
			return createTTypePolicyAdapter();
		}

		@Override
		public Adapter caseRTypePolicy(RTypePolicy object) {
			return createRTypePolicyAdapter();
		}

		@Override
		public Adapter caseRouteType(RouteType object) {
			return createRouteTypeAdapter();
		}

		@Override
		public Adapter casePostCallPolicy(PostCallPolicy object) {
			return createPostCallPolicyAdapter();
		}

		@Override
		public Adapter defaultCase(EObject object) {
			return createEObjectAdapter();
		}
	};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject) target);
	}

	/**
	 * Creates a new adapter for an object of class '{@link newTravelPlanner.TravelPlanner <em>Travel Planner</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see newTravelPlanner.TravelPlanner
	 * @generated
	 */
	public Adapter createTravelPlannerAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link newTravelPlanner.PreCallPolicy <em>Pre Call Policy</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see newTravelPlanner.PreCallPolicy
	 * @generated
	 */
	public Adapter createPreCallPolicyAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link newTravelPlanner.Policy <em>Policy</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see newTravelPlanner.Policy
	 * @generated
	 */
	public Adapter createPolicyAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link newTravelPlanner.TransportType <em>Transport Type</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see newTravelPlanner.TransportType
	 * @generated
	 */
	public Adapter createTransportTypeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link newTravelPlanner.SmartPlannerParameters <em>Smart Planner Parameters</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see newTravelPlanner.SmartPlannerParameters
	 * @generated
	 */
	public Adapter createSmartPlannerParametersAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link newTravelPlanner.TTypePolicy <em>TType Policy</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see newTravelPlanner.TTypePolicy
	 * @generated
	 */
	public Adapter createTTypePolicyAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link newTravelPlanner.RTypePolicy <em>RType Policy</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see newTravelPlanner.RTypePolicy
	 * @generated
	 */
	public Adapter createRTypePolicyAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link newTravelPlanner.RouteType <em>Route Type</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see newTravelPlanner.RouteType
	 * @generated
	 */
	public Adapter createRouteTypeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link newTravelPlanner.PostCallPolicy <em>Post Call Policy</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see newTravelPlanner.PostCallPolicy
	 * @generated
	 */
	public Adapter createPostCallPolicyAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //NewTravelPlannerAdapterFactory
