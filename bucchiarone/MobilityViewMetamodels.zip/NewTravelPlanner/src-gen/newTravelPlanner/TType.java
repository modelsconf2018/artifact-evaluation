/**
 */
package newTravelPlanner;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>TType</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see newTravelPlanner.NewTravelPlannerPackage#getTType()
 * @model
 * @generated
 */
public enum TType implements Enumerator {
	/**
	 * The '<em><b>CAR</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CAR_VALUE
	 * @generated
	 * @ordered
	 */
	CAR(0, "CAR", "CAR"),

	/**
	 * The '<em><b>CARWITHPARKING</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CARWITHPARKING_VALUE
	 * @generated
	 * @ordered
	 */
	CARWITHPARKING(1, "CARWITHPARKING", "CARWITHPARKING"),

	/**
	 * The '<em><b>PARK AND RIDE</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #PARK_AND_RIDE_VALUE
	 * @generated
	 * @ordered
	 */
	PARK_AND_RIDE(2, "PARK_AND_RIDE", "PARK_AND_RIDE"),

	/**
	 * The '<em><b>TRANSIT</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #TRANSIT_VALUE
	 * @generated
	 * @ordered
	 */
	TRANSIT(3, "TRANSIT", "TRANSIT"),

	/**
	 * The '<em><b>TRAIN</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #TRAIN_VALUE
	 * @generated
	 * @ordered
	 */
	TRAIN(4, "TRAIN", "TRAIN"),

	/**
	 * The '<em><b>BUS</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #BUS_VALUE
	 * @generated
	 * @ordered
	 */
	BUS(5, "BUS", "BUS"),

	/**
	 * The '<em><b>WALK</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #WALK_VALUE
	 * @generated
	 * @ordered
	 */
	WALK(6, "WALK", "WALK"),

	/**
	 * The '<em><b>SHAREDBIKE</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SHAREDBIKE_VALUE
	 * @generated
	 * @ordered
	 */
	SHAREDBIKE(7, "SHAREDBIKE", "SHAREDBIKE"),

	/**
	 * The '<em><b>SHAREDCAR</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SHAREDCAR_VALUE
	 * @generated
	 * @ordered
	 */
	SHAREDCAR(8, "SHAREDCAR", "SHAREDCAR"),

	/**
	 * The '<em><b>BICYCLE</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #BICYCLE_VALUE
	 * @generated
	 * @ordered
	 */
	BICYCLE(9, "BICYCLE", "BICYCLE"),

	/**
	 * The '<em><b>SHAREDBIKE WITHOUT STATION</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SHAREDBIKE_WITHOUT_STATION_VALUE
	 * @generated
	 * @ordered
	 */
	SHAREDBIKE_WITHOUT_STATION(10, "SHAREDBIKE_WITHOUT_STATION", "SHAREDBIKE_WITHOUT_STATION");

	/**
	 * The '<em><b>CAR</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>CAR</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #CAR
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int CAR_VALUE = 0;

	/**
	 * The '<em><b>CARWITHPARKING</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>CARWITHPARKING</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #CARWITHPARKING
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int CARWITHPARKING_VALUE = 1;

	/**
	 * The '<em><b>PARK AND RIDE</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>PARK AND RIDE</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #PARK_AND_RIDE
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int PARK_AND_RIDE_VALUE = 2;

	/**
	 * The '<em><b>TRANSIT</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>TRANSIT</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #TRANSIT
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int TRANSIT_VALUE = 3;

	/**
	 * The '<em><b>TRAIN</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>TRAIN</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #TRAIN
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int TRAIN_VALUE = 4;

	/**
	 * The '<em><b>BUS</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>BUS</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #BUS
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int BUS_VALUE = 5;

	/**
	 * The '<em><b>WALK</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>WALK</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #WALK
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int WALK_VALUE = 6;

	/**
	 * The '<em><b>SHAREDBIKE</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>SHAREDBIKE</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #SHAREDBIKE
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int SHAREDBIKE_VALUE = 7;

	/**
	 * The '<em><b>SHAREDCAR</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>SHAREDCAR</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #SHAREDCAR
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int SHAREDCAR_VALUE = 8;

	/**
	 * The '<em><b>BICYCLE</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>BICYCLE</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #BICYCLE
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int BICYCLE_VALUE = 9;

	/**
	 * The '<em><b>SHAREDBIKE WITHOUT STATION</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>SHAREDBIKE WITHOUT STATION</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #SHAREDBIKE_WITHOUT_STATION
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int SHAREDBIKE_WITHOUT_STATION_VALUE = 10;

	/**
	 * An array of all the '<em><b>TType</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final TType[] VALUES_ARRAY = new TType[] { CAR, CARWITHPARKING, PARK_AND_RIDE, TRANSIT, TRAIN, BUS,
			WALK, SHAREDBIKE, SHAREDCAR, BICYCLE, SHAREDBIKE_WITHOUT_STATION, };

	/**
	 * A public read-only list of all the '<em><b>TType</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<TType> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>TType</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param literal the literal.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static TType get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			TType result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>TType</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param name the name.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static TType getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			TType result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>TType</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the integer value.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static TType get(int value) {
		switch (value) {
		case CAR_VALUE:
			return CAR;
		case CARWITHPARKING_VALUE:
			return CARWITHPARKING;
		case PARK_AND_RIDE_VALUE:
			return PARK_AND_RIDE;
		case TRANSIT_VALUE:
			return TRANSIT;
		case TRAIN_VALUE:
			return TRAIN;
		case BUS_VALUE:
			return BUS;
		case WALK_VALUE:
			return WALK;
		case SHAREDBIKE_VALUE:
			return SHAREDBIKE;
		case SHAREDCAR_VALUE:
			return SHAREDCAR;
		case BICYCLE_VALUE:
			return BICYCLE;
		case SHAREDBIKE_WITHOUT_STATION_VALUE:
			return SHAREDBIKE_WITHOUT_STATION;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private TType(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getValue() {
		return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLiteral() {
		return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}

} //TType
