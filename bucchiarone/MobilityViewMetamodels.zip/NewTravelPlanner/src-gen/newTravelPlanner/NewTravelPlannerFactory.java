/**
 */
package newTravelPlanner;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see newTravelPlanner.NewTravelPlannerPackage
 * @generated
 */
public interface NewTravelPlannerFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	NewTravelPlannerFactory eINSTANCE = newTravelPlanner.impl.NewTravelPlannerFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Travel Planner</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Travel Planner</em>'.
	 * @generated
	 */
	TravelPlanner createTravelPlanner();

	/**
	 * Returns a new object of class '<em>Pre Call Policy</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Pre Call Policy</em>'.
	 * @generated
	 */
	PreCallPolicy createPreCallPolicy();

	/**
	 * Returns a new object of class '<em>Transport Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Transport Type</em>'.
	 * @generated
	 */
	TransportType createTransportType();

	/**
	 * Returns a new object of class '<em>Smart Planner Parameters</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Smart Planner Parameters</em>'.
	 * @generated
	 */
	SmartPlannerParameters createSmartPlannerParameters();

	/**
	 * Returns a new object of class '<em>TType Policy</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>TType Policy</em>'.
	 * @generated
	 */
	TTypePolicy createTTypePolicy();

	/**
	 * Returns a new object of class '<em>RType Policy</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>RType Policy</em>'.
	 * @generated
	 */
	RTypePolicy createRTypePolicy();

	/**
	 * Returns a new object of class '<em>Route Type</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Route Type</em>'.
	 * @generated
	 */
	RouteType createRouteType();

	/**
	 * Returns a new object of class '<em>Post Call Policy</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Post Call Policy</em>'.
	 * @generated
	 */
	PostCallPolicy createPostCallPolicy();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	NewTravelPlannerPackage getNewTravelPlannerPackage();

} //NewTravelPlannerFactory
