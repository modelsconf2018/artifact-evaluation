/**
 */
package newTravelPlanner;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see newTravelPlanner.NewTravelPlannerFactory
 * @model kind="package"
 * @generated
 */
public interface NewTravelPlannerPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "newTravelPlanner";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/newTravelPlanner";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "newTravelPlanner";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	NewTravelPlannerPackage eINSTANCE = newTravelPlanner.impl.NewTravelPlannerPackageImpl.init();

	/**
	 * The meta object id for the '{@link newTravelPlanner.impl.TravelPlannerImpl <em>Travel Planner</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see newTravelPlanner.impl.TravelPlannerImpl
	 * @see newTravelPlanner.impl.NewTravelPlannerPackageImpl#getTravelPlanner()
	 * @generated
	 */
	int TRAVEL_PLANNER = 0;

	/**
	 * The feature id for the '<em><b>Place</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAVEL_PLANNER__PLACE = 0;

	/**
	 * The feature id for the '<em><b>TTypes</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAVEL_PLANNER__TTYPES = 1;

	/**
	 * The feature id for the '<em><b>Smartplannerparameters</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAVEL_PLANNER__SMARTPLANNERPARAMETERS = 2;

	/**
	 * The feature id for the '<em><b>RTypes</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAVEL_PLANNER__RTYPES = 3;

	/**
	 * The feature id for the '<em><b>Policies</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAVEL_PLANNER__POLICIES = 4;

	/**
	 * The feature id for the '<em><b>Pre TType Policies</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAVEL_PLANNER__PRE_TTYPE_POLICIES = 5;

	/**
	 * The feature id for the '<em><b>Pre RType Policies</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAVEL_PLANNER__PRE_RTYPE_POLICIES = 6;

	/**
	 * The feature id for the '<em><b>Post RType Policies</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAVEL_PLANNER__POST_RTYPE_POLICIES = 7;

	/**
	 * The feature id for the '<em><b>Post TType Policies</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAVEL_PLANNER__POST_TTYPE_POLICIES = 8;

	/**
	 * The number of structural features of the '<em>Travel Planner</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAVEL_PLANNER_FEATURE_COUNT = 9;

	/**
	 * The number of operations of the '<em>Travel Planner</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAVEL_PLANNER_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link newTravelPlanner.impl.PolicyImpl <em>Policy</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see newTravelPlanner.impl.PolicyImpl
	 * @see newTravelPlanner.impl.NewTravelPlannerPackageImpl#getPolicy()
	 * @generated
	 */
	int POLICY = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POLICY__NAME = 0;

	/**
	 * The feature id for the '<em><b>From Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POLICY__FROM_DATE = 1;

	/**
	 * The feature id for the '<em><b>To Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POLICY__TO_DATE = 2;

	/**
	 * The number of structural features of the '<em>Policy</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POLICY_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>Policy</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POLICY_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link newTravelPlanner.impl.TransportTypeImpl <em>Transport Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see newTravelPlanner.impl.TransportTypeImpl
	 * @see newTravelPlanner.impl.NewTravelPlannerPackageImpl#getTransportType()
	 * @generated
	 */
	int TRANSPORT_TYPE = 2;

	/**
	 * The feature id for the '<em><b>Type Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSPORT_TYPE__TYPE_NAME = 0;

	/**
	 * The number of structural features of the '<em>Transport Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSPORT_TYPE_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Transport Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRANSPORT_TYPE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link newTravelPlanner.impl.SmartPlannerParametersImpl <em>Smart Planner Parameters</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see newTravelPlanner.impl.SmartPlannerParametersImpl
	 * @see newTravelPlanner.impl.NewTravelPlannerPackageImpl#getSmartPlannerParameters()
	 * @generated
	 */
	int SMART_PLANNER_PARAMETERS = 3;

	/**
	 * The feature id for the '<em><b>Spp Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMART_PLANNER_PARAMETERS__SPP_NAME = 0;

	/**
	 * The feature id for the '<em><b>Max Walk Distance</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMART_PLANNER_PARAMETERS__MAX_WALK_DISTANCE = 1;

	/**
	 * The feature id for the '<em><b>Max Total Walk Distance</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMART_PLANNER_PARAMETERS__MAX_TOTAL_WALK_DISTANCE = 2;

	/**
	 * The feature id for the '<em><b>Extra Transport</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMART_PLANNER_PARAMETERS__EXTRA_TRANSPORT = 3;

	/**
	 * The feature id for the '<em><b>Max Changes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMART_PLANNER_PARAMETERS__MAX_CHANGES = 4;

	/**
	 * The number of structural features of the '<em>Smart Planner Parameters</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMART_PLANNER_PARAMETERS_FEATURE_COUNT = 5;

	/**
	 * The number of operations of the '<em>Smart Planner Parameters</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SMART_PLANNER_PARAMETERS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link newTravelPlanner.impl.TTypePolicyImpl <em>TType Policy</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see newTravelPlanner.impl.TTypePolicyImpl
	 * @see newTravelPlanner.impl.NewTravelPlannerPackageImpl#getTTypePolicy()
	 * @generated
	 */
	int TTYPE_POLICY = 4;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TTYPE_POLICY__NAME = POLICY__NAME;

	/**
	 * The feature id for the '<em><b>From Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TTYPE_POLICY__FROM_DATE = POLICY__FROM_DATE;

	/**
	 * The feature id for the '<em><b>To Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TTYPE_POLICY__TO_DATE = POLICY__TO_DATE;

	/**
	 * The feature id for the '<em><b>Included TTypes</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TTYPE_POLICY__INCLUDED_TTYPES = POLICY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Excluded TTypes</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TTYPE_POLICY__EXCLUDED_TTYPES = POLICY_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Smartplannerparameters</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TTYPE_POLICY__SMARTPLANNERPARAMETERS = POLICY_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Included RT Policies</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TTYPE_POLICY__INCLUDED_RT_POLICIES = POLICY_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>TType Policy</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TTYPE_POLICY_FEATURE_COUNT = POLICY_FEATURE_COUNT + 4;

	/**
	 * The number of operations of the '<em>TType Policy</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TTYPE_POLICY_OPERATION_COUNT = POLICY_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link newTravelPlanner.impl.RTypePolicyImpl <em>RType Policy</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see newTravelPlanner.impl.RTypePolicyImpl
	 * @see newTravelPlanner.impl.NewTravelPlannerPackageImpl#getRTypePolicy()
	 * @generated
	 */
	int RTYPE_POLICY = 5;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RTYPE_POLICY__NAME = POLICY__NAME;

	/**
	 * The feature id for the '<em><b>From Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RTYPE_POLICY__FROM_DATE = POLICY__FROM_DATE;

	/**
	 * The feature id for the '<em><b>To Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RTYPE_POLICY__TO_DATE = POLICY__TO_DATE;

	/**
	 * The feature id for the '<em><b>Included RTypes</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RTYPE_POLICY__INCLUDED_RTYPES = POLICY_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Excluded RTypes</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RTYPE_POLICY__EXCLUDED_RTYPES = POLICY_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Smartplannerparameters</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RTYPE_POLICY__SMARTPLANNERPARAMETERS = POLICY_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>RType Policy</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RTYPE_POLICY_FEATURE_COUNT = POLICY_FEATURE_COUNT + 3;

	/**
	 * The number of operations of the '<em>RType Policy</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RTYPE_POLICY_OPERATION_COUNT = POLICY_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link newTravelPlanner.impl.RouteTypeImpl <em>Route Type</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see newTravelPlanner.impl.RouteTypeImpl
	 * @see newTravelPlanner.impl.NewTravelPlannerPackageImpl#getRouteType()
	 * @generated
	 */
	int ROUTE_TYPE = 6;

	/**
	 * The feature id for the '<em><b>Type Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROUTE_TYPE__TYPE_NAME = 0;

	/**
	 * The number of structural features of the '<em>Route Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROUTE_TYPE_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Route Type</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ROUTE_TYPE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link newTravelPlanner.TType <em>TType</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see newTravelPlanner.TType
	 * @see newTravelPlanner.impl.NewTravelPlannerPackageImpl#getTType()
	 * @generated
	 */
	int TTYPE = 7;

	/**
	 * The meta object id for the '{@link newTravelPlanner.RType <em>RType</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see newTravelPlanner.RType
	 * @see newTravelPlanner.impl.NewTravelPlannerPackageImpl#getRType()
	 * @generated
	 */
	int RTYPE = 8;

	/**
	 * Returns the meta object for class '{@link newTravelPlanner.TravelPlanner <em>Travel Planner</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Travel Planner</em>'.
	 * @see newTravelPlanner.TravelPlanner
	 * @generated
	 */
	EClass getTravelPlanner();

	/**
	 * Returns the meta object for the attribute '{@link newTravelPlanner.TravelPlanner#getPlace <em>Place</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Place</em>'.
	 * @see newTravelPlanner.TravelPlanner#getPlace()
	 * @see #getTravelPlanner()
	 * @generated
	 */
	EAttribute getTravelPlanner_Place();

	/**
	 * Returns the meta object for the containment reference list '{@link newTravelPlanner.TravelPlanner#getTTypes <em>TTypes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>TTypes</em>'.
	 * @see newTravelPlanner.TravelPlanner#getTTypes()
	 * @see #getTravelPlanner()
	 * @generated
	 */
	EReference getTravelPlanner_TTypes();

	/**
	 * Returns the meta object for the containment reference list '{@link newTravelPlanner.TravelPlanner#getSmartplannerparameters <em>Smartplannerparameters</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Smartplannerparameters</em>'.
	 * @see newTravelPlanner.TravelPlanner#getSmartplannerparameters()
	 * @see #getTravelPlanner()
	 * @generated
	 */
	EReference getTravelPlanner_Smartplannerparameters();

	/**
	 * Returns the meta object for the containment reference list '{@link newTravelPlanner.TravelPlanner#getRTypes <em>RTypes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>RTypes</em>'.
	 * @see newTravelPlanner.TravelPlanner#getRTypes()
	 * @see #getTravelPlanner()
	 * @generated
	 */
	EReference getTravelPlanner_RTypes();

	/**
	 * Returns the meta object for the containment reference list '{@link newTravelPlanner.TravelPlanner#getPolicies <em>Policies</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Policies</em>'.
	 * @see newTravelPlanner.TravelPlanner#getPolicies()
	 * @see #getTravelPlanner()
	 * @generated
	 */
	EReference getTravelPlanner_Policies();

	/**
	 * Returns the meta object for the reference list '{@link newTravelPlanner.TravelPlanner#getPreTTypePolicies <em>Pre TType Policies</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Pre TType Policies</em>'.
	 * @see newTravelPlanner.TravelPlanner#getPreTTypePolicies()
	 * @see #getTravelPlanner()
	 * @generated
	 */
	EReference getTravelPlanner_PreTTypePolicies();

	/**
	 * Returns the meta object for the reference list '{@link newTravelPlanner.TravelPlanner#getPreRTypePolicies <em>Pre RType Policies</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Pre RType Policies</em>'.
	 * @see newTravelPlanner.TravelPlanner#getPreRTypePolicies()
	 * @see #getTravelPlanner()
	 * @generated
	 */
	EReference getTravelPlanner_PreRTypePolicies();

	/**
	 * Returns the meta object for the reference list '{@link newTravelPlanner.TravelPlanner#getPostRTypePolicies <em>Post RType Policies</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Post RType Policies</em>'.
	 * @see newTravelPlanner.TravelPlanner#getPostRTypePolicies()
	 * @see #getTravelPlanner()
	 * @generated
	 */
	EReference getTravelPlanner_PostRTypePolicies();

	/**
	 * Returns the meta object for the reference list '{@link newTravelPlanner.TravelPlanner#getPostTTypePolicies <em>Post TType Policies</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Post TType Policies</em>'.
	 * @see newTravelPlanner.TravelPlanner#getPostTTypePolicies()
	 * @see #getTravelPlanner()
	 * @generated
	 */
	EReference getTravelPlanner_PostTTypePolicies();

	/**
	 * Returns the meta object for class '{@link newTravelPlanner.Policy <em>Policy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Policy</em>'.
	 * @see newTravelPlanner.Policy
	 * @generated
	 */
	EClass getPolicy();

	/**
	 * Returns the meta object for the attribute '{@link newTravelPlanner.Policy#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see newTravelPlanner.Policy#getName()
	 * @see #getPolicy()
	 * @generated
	 */
	EAttribute getPolicy_Name();

	/**
	 * Returns the meta object for the attribute '{@link newTravelPlanner.Policy#getFromDate <em>From Date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>From Date</em>'.
	 * @see newTravelPlanner.Policy#getFromDate()
	 * @see #getPolicy()
	 * @generated
	 */
	EAttribute getPolicy_FromDate();

	/**
	 * Returns the meta object for the attribute '{@link newTravelPlanner.Policy#getToDate <em>To Date</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>To Date</em>'.
	 * @see newTravelPlanner.Policy#getToDate()
	 * @see #getPolicy()
	 * @generated
	 */
	EAttribute getPolicy_ToDate();

	/**
	 * Returns the meta object for class '{@link newTravelPlanner.TransportType <em>Transport Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Transport Type</em>'.
	 * @see newTravelPlanner.TransportType
	 * @generated
	 */
	EClass getTransportType();

	/**
	 * Returns the meta object for the attribute '{@link newTravelPlanner.TransportType#getTypeName <em>Type Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type Name</em>'.
	 * @see newTravelPlanner.TransportType#getTypeName()
	 * @see #getTransportType()
	 * @generated
	 */
	EAttribute getTransportType_TypeName();

	/**
	 * Returns the meta object for class '{@link newTravelPlanner.SmartPlannerParameters <em>Smart Planner Parameters</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Smart Planner Parameters</em>'.
	 * @see newTravelPlanner.SmartPlannerParameters
	 * @generated
	 */
	EClass getSmartPlannerParameters();

	/**
	 * Returns the meta object for the attribute '{@link newTravelPlanner.SmartPlannerParameters#getSppName <em>Spp Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Spp Name</em>'.
	 * @see newTravelPlanner.SmartPlannerParameters#getSppName()
	 * @see #getSmartPlannerParameters()
	 * @generated
	 */
	EAttribute getSmartPlannerParameters_SppName();

	/**
	 * Returns the meta object for the attribute '{@link newTravelPlanner.SmartPlannerParameters#getMaxWalkDistance <em>Max Walk Distance</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Max Walk Distance</em>'.
	 * @see newTravelPlanner.SmartPlannerParameters#getMaxWalkDistance()
	 * @see #getSmartPlannerParameters()
	 * @generated
	 */
	EAttribute getSmartPlannerParameters_MaxWalkDistance();

	/**
	 * Returns the meta object for the attribute '{@link newTravelPlanner.SmartPlannerParameters#getMaxTotalWalkDistance <em>Max Total Walk Distance</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Max Total Walk Distance</em>'.
	 * @see newTravelPlanner.SmartPlannerParameters#getMaxTotalWalkDistance()
	 * @see #getSmartPlannerParameters()
	 * @generated
	 */
	EAttribute getSmartPlannerParameters_MaxTotalWalkDistance();

	/**
	 * Returns the meta object for the attribute '{@link newTravelPlanner.SmartPlannerParameters#getExtraTransport <em>Extra Transport</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Extra Transport</em>'.
	 * @see newTravelPlanner.SmartPlannerParameters#getExtraTransport()
	 * @see #getSmartPlannerParameters()
	 * @generated
	 */
	EAttribute getSmartPlannerParameters_ExtraTransport();

	/**
	 * Returns the meta object for the attribute '{@link newTravelPlanner.SmartPlannerParameters#getMaxChanges <em>Max Changes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Max Changes</em>'.
	 * @see newTravelPlanner.SmartPlannerParameters#getMaxChanges()
	 * @see #getSmartPlannerParameters()
	 * @generated
	 */
	EAttribute getSmartPlannerParameters_MaxChanges();

	/**
	 * Returns the meta object for class '{@link newTravelPlanner.TTypePolicy <em>TType Policy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>TType Policy</em>'.
	 * @see newTravelPlanner.TTypePolicy
	 * @generated
	 */
	EClass getTTypePolicy();

	/**
	 * Returns the meta object for the reference list '{@link newTravelPlanner.TTypePolicy#getIncludedTTypes <em>Included TTypes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Included TTypes</em>'.
	 * @see newTravelPlanner.TTypePolicy#getIncludedTTypes()
	 * @see #getTTypePolicy()
	 * @generated
	 */
	EReference getTTypePolicy_IncludedTTypes();

	/**
	 * Returns the meta object for the reference list '{@link newTravelPlanner.TTypePolicy#getExcludedTTypes <em>Excluded TTypes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Excluded TTypes</em>'.
	 * @see newTravelPlanner.TTypePolicy#getExcludedTTypes()
	 * @see #getTTypePolicy()
	 * @generated
	 */
	EReference getTTypePolicy_ExcludedTTypes();

	/**
	 * Returns the meta object for the reference '{@link newTravelPlanner.TTypePolicy#getSmartplannerparameters <em>Smartplannerparameters</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Smartplannerparameters</em>'.
	 * @see newTravelPlanner.TTypePolicy#getSmartplannerparameters()
	 * @see #getTTypePolicy()
	 * @generated
	 */
	EReference getTTypePolicy_Smartplannerparameters();

	/**
	 * Returns the meta object for the reference list '{@link newTravelPlanner.TTypePolicy#getIncludedRTPolicies <em>Included RT Policies</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Included RT Policies</em>'.
	 * @see newTravelPlanner.TTypePolicy#getIncludedRTPolicies()
	 * @see #getTTypePolicy()
	 * @generated
	 */
	EReference getTTypePolicy_IncludedRTPolicies();

	/**
	 * Returns the meta object for class '{@link newTravelPlanner.RTypePolicy <em>RType Policy</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>RType Policy</em>'.
	 * @see newTravelPlanner.RTypePolicy
	 * @generated
	 */
	EClass getRTypePolicy();

	/**
	 * Returns the meta object for the reference list '{@link newTravelPlanner.RTypePolicy#getIncludedRTypes <em>Included RTypes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Included RTypes</em>'.
	 * @see newTravelPlanner.RTypePolicy#getIncludedRTypes()
	 * @see #getRTypePolicy()
	 * @generated
	 */
	EReference getRTypePolicy_IncludedRTypes();

	/**
	 * Returns the meta object for the reference list '{@link newTravelPlanner.RTypePolicy#getExcludedRTypes <em>Excluded RTypes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Excluded RTypes</em>'.
	 * @see newTravelPlanner.RTypePolicy#getExcludedRTypes()
	 * @see #getRTypePolicy()
	 * @generated
	 */
	EReference getRTypePolicy_ExcludedRTypes();

	/**
	 * Returns the meta object for the reference '{@link newTravelPlanner.RTypePolicy#getSmartplannerparameters <em>Smartplannerparameters</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Smartplannerparameters</em>'.
	 * @see newTravelPlanner.RTypePolicy#getSmartplannerparameters()
	 * @see #getRTypePolicy()
	 * @generated
	 */
	EReference getRTypePolicy_Smartplannerparameters();

	/**
	 * Returns the meta object for class '{@link newTravelPlanner.RouteType <em>Route Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Route Type</em>'.
	 * @see newTravelPlanner.RouteType
	 * @generated
	 */
	EClass getRouteType();

	/**
	 * Returns the meta object for the attribute '{@link newTravelPlanner.RouteType#getTypeName <em>Type Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type Name</em>'.
	 * @see newTravelPlanner.RouteType#getTypeName()
	 * @see #getRouteType()
	 * @generated
	 */
	EAttribute getRouteType_TypeName();

	/**
	 * Returns the meta object for enum '{@link newTravelPlanner.TType <em>TType</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>TType</em>'.
	 * @see newTravelPlanner.TType
	 * @generated
	 */
	EEnum getTType();

	/**
	 * Returns the meta object for enum '{@link newTravelPlanner.RType <em>RType</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>RType</em>'.
	 * @see newTravelPlanner.RType
	 * @generated
	 */
	EEnum getRType();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	NewTravelPlannerFactory getNewTravelPlannerFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link newTravelPlanner.impl.TravelPlannerImpl <em>Travel Planner</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see newTravelPlanner.impl.TravelPlannerImpl
		 * @see newTravelPlanner.impl.NewTravelPlannerPackageImpl#getTravelPlanner()
		 * @generated
		 */
		EClass TRAVEL_PLANNER = eINSTANCE.getTravelPlanner();

		/**
		 * The meta object literal for the '<em><b>Place</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRAVEL_PLANNER__PLACE = eINSTANCE.getTravelPlanner_Place();

		/**
		 * The meta object literal for the '<em><b>TTypes</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRAVEL_PLANNER__TTYPES = eINSTANCE.getTravelPlanner_TTypes();

		/**
		 * The meta object literal for the '<em><b>Smartplannerparameters</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRAVEL_PLANNER__SMARTPLANNERPARAMETERS = eINSTANCE.getTravelPlanner_Smartplannerparameters();

		/**
		 * The meta object literal for the '<em><b>RTypes</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRAVEL_PLANNER__RTYPES = eINSTANCE.getTravelPlanner_RTypes();

		/**
		 * The meta object literal for the '<em><b>Policies</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRAVEL_PLANNER__POLICIES = eINSTANCE.getTravelPlanner_Policies();

		/**
		 * The meta object literal for the '<em><b>Pre TType Policies</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRAVEL_PLANNER__PRE_TTYPE_POLICIES = eINSTANCE.getTravelPlanner_PreTTypePolicies();

		/**
		 * The meta object literal for the '<em><b>Pre RType Policies</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRAVEL_PLANNER__PRE_RTYPE_POLICIES = eINSTANCE.getTravelPlanner_PreRTypePolicies();

		/**
		 * The meta object literal for the '<em><b>Post RType Policies</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRAVEL_PLANNER__POST_RTYPE_POLICIES = eINSTANCE.getTravelPlanner_PostRTypePolicies();

		/**
		 * The meta object literal for the '<em><b>Post TType Policies</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TRAVEL_PLANNER__POST_TTYPE_POLICIES = eINSTANCE.getTravelPlanner_PostTTypePolicies();

		/**
		 * The meta object literal for the '{@link newTravelPlanner.impl.PolicyImpl <em>Policy</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see newTravelPlanner.impl.PolicyImpl
		 * @see newTravelPlanner.impl.NewTravelPlannerPackageImpl#getPolicy()
		 * @generated
		 */
		EClass POLICY = eINSTANCE.getPolicy();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute POLICY__NAME = eINSTANCE.getPolicy_Name();

		/**
		 * The meta object literal for the '<em><b>From Date</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute POLICY__FROM_DATE = eINSTANCE.getPolicy_FromDate();

		/**
		 * The meta object literal for the '<em><b>To Date</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute POLICY__TO_DATE = eINSTANCE.getPolicy_ToDate();

		/**
		 * The meta object literal for the '{@link newTravelPlanner.impl.TransportTypeImpl <em>Transport Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see newTravelPlanner.impl.TransportTypeImpl
		 * @see newTravelPlanner.impl.NewTravelPlannerPackageImpl#getTransportType()
		 * @generated
		 */
		EClass TRANSPORT_TYPE = eINSTANCE.getTransportType();

		/**
		 * The meta object literal for the '<em><b>Type Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRANSPORT_TYPE__TYPE_NAME = eINSTANCE.getTransportType_TypeName();

		/**
		 * The meta object literal for the '{@link newTravelPlanner.impl.SmartPlannerParametersImpl <em>Smart Planner Parameters</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see newTravelPlanner.impl.SmartPlannerParametersImpl
		 * @see newTravelPlanner.impl.NewTravelPlannerPackageImpl#getSmartPlannerParameters()
		 * @generated
		 */
		EClass SMART_PLANNER_PARAMETERS = eINSTANCE.getSmartPlannerParameters();

		/**
		 * The meta object literal for the '<em><b>Spp Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SMART_PLANNER_PARAMETERS__SPP_NAME = eINSTANCE.getSmartPlannerParameters_SppName();

		/**
		 * The meta object literal for the '<em><b>Max Walk Distance</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SMART_PLANNER_PARAMETERS__MAX_WALK_DISTANCE = eINSTANCE.getSmartPlannerParameters_MaxWalkDistance();

		/**
		 * The meta object literal for the '<em><b>Max Total Walk Distance</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SMART_PLANNER_PARAMETERS__MAX_TOTAL_WALK_DISTANCE = eINSTANCE
				.getSmartPlannerParameters_MaxTotalWalkDistance();

		/**
		 * The meta object literal for the '<em><b>Extra Transport</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SMART_PLANNER_PARAMETERS__EXTRA_TRANSPORT = eINSTANCE.getSmartPlannerParameters_ExtraTransport();

		/**
		 * The meta object literal for the '<em><b>Max Changes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute SMART_PLANNER_PARAMETERS__MAX_CHANGES = eINSTANCE.getSmartPlannerParameters_MaxChanges();

		/**
		 * The meta object literal for the '{@link newTravelPlanner.impl.TTypePolicyImpl <em>TType Policy</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see newTravelPlanner.impl.TTypePolicyImpl
		 * @see newTravelPlanner.impl.NewTravelPlannerPackageImpl#getTTypePolicy()
		 * @generated
		 */
		EClass TTYPE_POLICY = eINSTANCE.getTTypePolicy();

		/**
		 * The meta object literal for the '<em><b>Included TTypes</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TTYPE_POLICY__INCLUDED_TTYPES = eINSTANCE.getTTypePolicy_IncludedTTypes();

		/**
		 * The meta object literal for the '<em><b>Excluded TTypes</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TTYPE_POLICY__EXCLUDED_TTYPES = eINSTANCE.getTTypePolicy_ExcludedTTypes();

		/**
		 * The meta object literal for the '<em><b>Smartplannerparameters</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TTYPE_POLICY__SMARTPLANNERPARAMETERS = eINSTANCE.getTTypePolicy_Smartplannerparameters();

		/**
		 * The meta object literal for the '<em><b>Included RT Policies</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference TTYPE_POLICY__INCLUDED_RT_POLICIES = eINSTANCE.getTTypePolicy_IncludedRTPolicies();

		/**
		 * The meta object literal for the '{@link newTravelPlanner.impl.RTypePolicyImpl <em>RType Policy</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see newTravelPlanner.impl.RTypePolicyImpl
		 * @see newTravelPlanner.impl.NewTravelPlannerPackageImpl#getRTypePolicy()
		 * @generated
		 */
		EClass RTYPE_POLICY = eINSTANCE.getRTypePolicy();

		/**
		 * The meta object literal for the '<em><b>Included RTypes</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RTYPE_POLICY__INCLUDED_RTYPES = eINSTANCE.getRTypePolicy_IncludedRTypes();

		/**
		 * The meta object literal for the '<em><b>Excluded RTypes</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RTYPE_POLICY__EXCLUDED_RTYPES = eINSTANCE.getRTypePolicy_ExcludedRTypes();

		/**
		 * The meta object literal for the '<em><b>Smartplannerparameters</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference RTYPE_POLICY__SMARTPLANNERPARAMETERS = eINSTANCE.getRTypePolicy_Smartplannerparameters();

		/**
		 * The meta object literal for the '{@link newTravelPlanner.impl.RouteTypeImpl <em>Route Type</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see newTravelPlanner.impl.RouteTypeImpl
		 * @see newTravelPlanner.impl.NewTravelPlannerPackageImpl#getRouteType()
		 * @generated
		 */
		EClass ROUTE_TYPE = eINSTANCE.getRouteType();

		/**
		 * The meta object literal for the '<em><b>Type Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute ROUTE_TYPE__TYPE_NAME = eINSTANCE.getRouteType_TypeName();

		/**
		 * The meta object literal for the '{@link newTravelPlanner.TType <em>TType</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see newTravelPlanner.TType
		 * @see newTravelPlanner.impl.NewTravelPlannerPackageImpl#getTType()
		 * @generated
		 */
		EEnum TTYPE = eINSTANCE.getTType();

		/**
		 * The meta object literal for the '{@link newTravelPlanner.RType <em>RType</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see newTravelPlanner.RType
		 * @see newTravelPlanner.impl.NewTravelPlannerPackageImpl#getRType()
		 * @generated
		 */
		EEnum RTYPE = eINSTANCE.getRType();

	}

} //NewTravelPlannerPackage
