/**
 */
package newTravelPlanner.impl;

import java.util.Collection;
import newTravelPlanner.NewTravelPlannerPackage;
import newTravelPlanner.PostCallPolicy;

import newTravelPlanner.RTypePolicy;
import newTravelPlanner.TTypePolicy;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Post Call Policy</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link newTravelPlanner.impl.PostCallPolicyImpl#getPostTTypePolicies <em>Post TType Policies</em>}</li>
 *   <li>{@link newTravelPlanner.impl.PostCallPolicyImpl#getPostRTypePolicies <em>Post RType Policies</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PostCallPolicyImpl extends PolicyImpl implements PostCallPolicy {
	/**
	 * The cached value of the '{@link #getPostTTypePolicies() <em>Post TType Policies</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPostTTypePolicies()
	 * @generated
	 * @ordered
	 */
	protected EList<TTypePolicy> postTTypePolicies;
	/**
	 * The cached value of the '{@link #getPostRTypePolicies() <em>Post RType Policies</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPostRTypePolicies()
	 * @generated
	 * @ordered
	 */
	protected EList<RTypePolicy> postRTypePolicies;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PostCallPolicyImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return NewTravelPlannerPackage.Literals.POST_CALL_POLICY;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<TTypePolicy> getPostTTypePolicies() {
		if (postTTypePolicies == null) {
			postTTypePolicies = new EObjectResolvingEList<TTypePolicy>(TTypePolicy.class, this,
					NewTravelPlannerPackage.POST_CALL_POLICY__POST_TTYPE_POLICIES);
		}
		return postTTypePolicies;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<RTypePolicy> getPostRTypePolicies() {
		if (postRTypePolicies == null) {
			postRTypePolicies = new EObjectResolvingEList<RTypePolicy>(RTypePolicy.class, this,
					NewTravelPlannerPackage.POST_CALL_POLICY__POST_RTYPE_POLICIES);
		}
		return postRTypePolicies;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case NewTravelPlannerPackage.POST_CALL_POLICY__POST_TTYPE_POLICIES:
			return getPostTTypePolicies();
		case NewTravelPlannerPackage.POST_CALL_POLICY__POST_RTYPE_POLICIES:
			return getPostRTypePolicies();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case NewTravelPlannerPackage.POST_CALL_POLICY__POST_TTYPE_POLICIES:
			getPostTTypePolicies().clear();
			getPostTTypePolicies().addAll((Collection<? extends TTypePolicy>) newValue);
			return;
		case NewTravelPlannerPackage.POST_CALL_POLICY__POST_RTYPE_POLICIES:
			getPostRTypePolicies().clear();
			getPostRTypePolicies().addAll((Collection<? extends RTypePolicy>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case NewTravelPlannerPackage.POST_CALL_POLICY__POST_TTYPE_POLICIES:
			getPostTTypePolicies().clear();
			return;
		case NewTravelPlannerPackage.POST_CALL_POLICY__POST_RTYPE_POLICIES:
			getPostRTypePolicies().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case NewTravelPlannerPackage.POST_CALL_POLICY__POST_TTYPE_POLICIES:
			return postTTypePolicies != null && !postTTypePolicies.isEmpty();
		case NewTravelPlannerPackage.POST_CALL_POLICY__POST_RTYPE_POLICIES:
			return postRTypePolicies != null && !postRTypePolicies.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //PostCallPolicyImpl
