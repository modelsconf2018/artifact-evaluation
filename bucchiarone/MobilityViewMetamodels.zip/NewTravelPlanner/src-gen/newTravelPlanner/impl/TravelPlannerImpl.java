/**
 */
package newTravelPlanner.impl;

import java.util.Collection;

import newTravelPlanner.NewTravelPlannerPackage;
import newTravelPlanner.Policy;
import newTravelPlanner.PostCallPolicy;
import newTravelPlanner.PreCallPolicy;
import newTravelPlanner.RouteType;
import newTravelPlanner.SmartPlannerParameters;
import newTravelPlanner.TransportType;
import newTravelPlanner.TravelPlanner;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Travel Planner</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link newTravelPlanner.impl.TravelPlannerImpl#getPlace <em>Place</em>}</li>
 *   <li>{@link newTravelPlanner.impl.TravelPlannerImpl#getPrecallpolicies <em>Precallpolicies</em>}</li>
 *   <li>{@link newTravelPlanner.impl.TravelPlannerImpl#getTTypes <em>TTypes</em>}</li>
 *   <li>{@link newTravelPlanner.impl.TravelPlannerImpl#getSmartplannerparameters <em>Smartplannerparameters</em>}</li>
 *   <li>{@link newTravelPlanner.impl.TravelPlannerImpl#getRTypes <em>RTypes</em>}</li>
 *   <li>{@link newTravelPlanner.impl.TravelPlannerImpl#getPostcallpolicies <em>Postcallpolicies</em>}</li>
 *   <li>{@link newTravelPlanner.impl.TravelPlannerImpl#getPolicies <em>Policies</em>}</li>
 * </ul>
 *
 * @generated
 */
public class TravelPlannerImpl extends MinimalEObjectImpl.Container implements TravelPlanner {
	/**
	 * The default value of the '{@link #getPlace() <em>Place</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPlace()
	 * @generated
	 * @ordered
	 */
	protected static final String PLACE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPlace() <em>Place</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPlace()
	 * @generated
	 * @ordered
	 */
	protected String place = PLACE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getPrecallpolicies() <em>Precallpolicies</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrecallpolicies()
	 * @generated
	 * @ordered
	 */
	protected PreCallPolicy precallpolicies;

	/**
	 * The cached value of the '{@link #getTTypes() <em>TTypes</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTTypes()
	 * @generated
	 * @ordered
	 */
	protected EList<TransportType> tTypes;

	/**
	 * The cached value of the '{@link #getSmartplannerparameters() <em>Smartplannerparameters</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSmartplannerparameters()
	 * @generated
	 * @ordered
	 */
	protected EList<SmartPlannerParameters> smartplannerparameters;

	/**
	 * The cached value of the '{@link #getRTypes() <em>RTypes</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRTypes()
	 * @generated
	 * @ordered
	 */
	protected EList<RouteType> rTypes;

	/**
	 * The cached value of the '{@link #getPostcallpolicies() <em>Postcallpolicies</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPostcallpolicies()
	 * @generated
	 * @ordered
	 */
	protected PostCallPolicy postcallpolicies;

	/**
	 * The cached value of the '{@link #getPolicies() <em>Policies</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPolicies()
	 * @generated
	 * @ordered
	 */
	protected EList<Policy> policies;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TravelPlannerImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return NewTravelPlannerPackage.Literals.TRAVEL_PLANNER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getPlace() {
		return place;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPlace(String newPlace) {
		String oldPlace = place;
		place = newPlace;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, NewTravelPlannerPackage.TRAVEL_PLANNER__PLACE,
					oldPlace, place));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PreCallPolicy getPrecallpolicies() {
		if (precallpolicies != null && precallpolicies.eIsProxy()) {
			InternalEObject oldPrecallpolicies = (InternalEObject) precallpolicies;
			precallpolicies = (PreCallPolicy) eResolveProxy(oldPrecallpolicies);
			if (precallpolicies != oldPrecallpolicies) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							NewTravelPlannerPackage.TRAVEL_PLANNER__PRECALLPOLICIES, oldPrecallpolicies,
							precallpolicies));
			}
		}
		return precallpolicies;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PreCallPolicy basicGetPrecallpolicies() {
		return precallpolicies;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPrecallpolicies(PreCallPolicy newPrecallpolicies) {
		PreCallPolicy oldPrecallpolicies = precallpolicies;
		precallpolicies = newPrecallpolicies;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					NewTravelPlannerPackage.TRAVEL_PLANNER__PRECALLPOLICIES, oldPrecallpolicies, precallpolicies));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<TransportType> getTTypes() {
		if (tTypes == null) {
			tTypes = new EObjectContainmentEList<TransportType>(TransportType.class, this,
					NewTravelPlannerPackage.TRAVEL_PLANNER__TTYPES);
		}
		return tTypes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<SmartPlannerParameters> getSmartplannerparameters() {
		if (smartplannerparameters == null) {
			smartplannerparameters = new EObjectContainmentEList<SmartPlannerParameters>(SmartPlannerParameters.class,
					this, NewTravelPlannerPackage.TRAVEL_PLANNER__SMARTPLANNERPARAMETERS);
		}
		return smartplannerparameters;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<RouteType> getRTypes() {
		if (rTypes == null) {
			rTypes = new EObjectContainmentEList<RouteType>(RouteType.class, this,
					NewTravelPlannerPackage.TRAVEL_PLANNER__RTYPES);
		}
		return rTypes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PostCallPolicy getPostcallpolicies() {
		if (postcallpolicies != null && postcallpolicies.eIsProxy()) {
			InternalEObject oldPostcallpolicies = (InternalEObject) postcallpolicies;
			postcallpolicies = (PostCallPolicy) eResolveProxy(oldPostcallpolicies);
			if (postcallpolicies != oldPostcallpolicies) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							NewTravelPlannerPackage.TRAVEL_PLANNER__POSTCALLPOLICIES, oldPostcallpolicies,
							postcallpolicies));
			}
		}
		return postcallpolicies;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PostCallPolicy basicGetPostcallpolicies() {
		return postcallpolicies;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPostcallpolicies(PostCallPolicy newPostcallpolicies) {
		PostCallPolicy oldPostcallpolicies = postcallpolicies;
		postcallpolicies = newPostcallpolicies;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					NewTravelPlannerPackage.TRAVEL_PLANNER__POSTCALLPOLICIES, oldPostcallpolicies, postcallpolicies));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Policy> getPolicies() {
		if (policies == null) {
			policies = new EObjectContainmentEList<Policy>(Policy.class, this,
					NewTravelPlannerPackage.TRAVEL_PLANNER__POLICIES);
		}
		return policies;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case NewTravelPlannerPackage.TRAVEL_PLANNER__TTYPES:
			return ((InternalEList<?>) getTTypes()).basicRemove(otherEnd, msgs);
		case NewTravelPlannerPackage.TRAVEL_PLANNER__SMARTPLANNERPARAMETERS:
			return ((InternalEList<?>) getSmartplannerparameters()).basicRemove(otherEnd, msgs);
		case NewTravelPlannerPackage.TRAVEL_PLANNER__RTYPES:
			return ((InternalEList<?>) getRTypes()).basicRemove(otherEnd, msgs);
		case NewTravelPlannerPackage.TRAVEL_PLANNER__POLICIES:
			return ((InternalEList<?>) getPolicies()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case NewTravelPlannerPackage.TRAVEL_PLANNER__PLACE:
			return getPlace();
		case NewTravelPlannerPackage.TRAVEL_PLANNER__PRECALLPOLICIES:
			if (resolve)
				return getPrecallpolicies();
			return basicGetPrecallpolicies();
		case NewTravelPlannerPackage.TRAVEL_PLANNER__TTYPES:
			return getTTypes();
		case NewTravelPlannerPackage.TRAVEL_PLANNER__SMARTPLANNERPARAMETERS:
			return getSmartplannerparameters();
		case NewTravelPlannerPackage.TRAVEL_PLANNER__RTYPES:
			return getRTypes();
		case NewTravelPlannerPackage.TRAVEL_PLANNER__POSTCALLPOLICIES:
			if (resolve)
				return getPostcallpolicies();
			return basicGetPostcallpolicies();
		case NewTravelPlannerPackage.TRAVEL_PLANNER__POLICIES:
			return getPolicies();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case NewTravelPlannerPackage.TRAVEL_PLANNER__PLACE:
			setPlace((String) newValue);
			return;
		case NewTravelPlannerPackage.TRAVEL_PLANNER__PRECALLPOLICIES:
			setPrecallpolicies((PreCallPolicy) newValue);
			return;
		case NewTravelPlannerPackage.TRAVEL_PLANNER__TTYPES:
			getTTypes().clear();
			getTTypes().addAll((Collection<? extends TransportType>) newValue);
			return;
		case NewTravelPlannerPackage.TRAVEL_PLANNER__SMARTPLANNERPARAMETERS:
			getSmartplannerparameters().clear();
			getSmartplannerparameters().addAll((Collection<? extends SmartPlannerParameters>) newValue);
			return;
		case NewTravelPlannerPackage.TRAVEL_PLANNER__RTYPES:
			getRTypes().clear();
			getRTypes().addAll((Collection<? extends RouteType>) newValue);
			return;
		case NewTravelPlannerPackage.TRAVEL_PLANNER__POSTCALLPOLICIES:
			setPostcallpolicies((PostCallPolicy) newValue);
			return;
		case NewTravelPlannerPackage.TRAVEL_PLANNER__POLICIES:
			getPolicies().clear();
			getPolicies().addAll((Collection<? extends Policy>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case NewTravelPlannerPackage.TRAVEL_PLANNER__PLACE:
			setPlace(PLACE_EDEFAULT);
			return;
		case NewTravelPlannerPackage.TRAVEL_PLANNER__PRECALLPOLICIES:
			setPrecallpolicies((PreCallPolicy) null);
			return;
		case NewTravelPlannerPackage.TRAVEL_PLANNER__TTYPES:
			getTTypes().clear();
			return;
		case NewTravelPlannerPackage.TRAVEL_PLANNER__SMARTPLANNERPARAMETERS:
			getSmartplannerparameters().clear();
			return;
		case NewTravelPlannerPackage.TRAVEL_PLANNER__RTYPES:
			getRTypes().clear();
			return;
		case NewTravelPlannerPackage.TRAVEL_PLANNER__POSTCALLPOLICIES:
			setPostcallpolicies((PostCallPolicy) null);
			return;
		case NewTravelPlannerPackage.TRAVEL_PLANNER__POLICIES:
			getPolicies().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case NewTravelPlannerPackage.TRAVEL_PLANNER__PLACE:
			return PLACE_EDEFAULT == null ? place != null : !PLACE_EDEFAULT.equals(place);
		case NewTravelPlannerPackage.TRAVEL_PLANNER__PRECALLPOLICIES:
			return precallpolicies != null;
		case NewTravelPlannerPackage.TRAVEL_PLANNER__TTYPES:
			return tTypes != null && !tTypes.isEmpty();
		case NewTravelPlannerPackage.TRAVEL_PLANNER__SMARTPLANNERPARAMETERS:
			return smartplannerparameters != null && !smartplannerparameters.isEmpty();
		case NewTravelPlannerPackage.TRAVEL_PLANNER__RTYPES:
			return rTypes != null && !rTypes.isEmpty();
		case NewTravelPlannerPackage.TRAVEL_PLANNER__POSTCALLPOLICIES:
			return postcallpolicies != null;
		case NewTravelPlannerPackage.TRAVEL_PLANNER__POLICIES:
			return policies != null && !policies.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (place: ");
		result.append(place);
		result.append(')');
		return result.toString();
	}

} //TravelPlannerImpl
