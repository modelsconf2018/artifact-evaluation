/**
 */
package newTravelPlanner.impl;

import java.util.Collection;
import newTravelPlanner.NewTravelPlannerPackage;
import newTravelPlanner.PreCallPolicy;

import newTravelPlanner.RTypePolicy;
import newTravelPlanner.TTypePolicy;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Pre Call Policy</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link newTravelPlanner.impl.PreCallPolicyImpl#getPreRTypePolicies <em>Pre RType Policies</em>}</li>
 *   <li>{@link newTravelPlanner.impl.PreCallPolicyImpl#getPreTTypePolicies <em>Pre TType Policies</em>}</li>
 * </ul>
 *
 * @generated
 */
public class PreCallPolicyImpl extends PolicyImpl implements PreCallPolicy {
	/**
	 * The cached value of the '{@link #getPreRTypePolicies() <em>Pre RType Policies</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPreRTypePolicies()
	 * @generated
	 * @ordered
	 */
	protected EList<RTypePolicy> preRTypePolicies;
	/**
	 * The cached value of the '{@link #getPreTTypePolicies() <em>Pre TType Policies</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPreTTypePolicies()
	 * @generated
	 * @ordered
	 */
	protected EList<TTypePolicy> preTTypePolicies;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PreCallPolicyImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return NewTravelPlannerPackage.Literals.PRE_CALL_POLICY;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<RTypePolicy> getPreRTypePolicies() {
		if (preRTypePolicies == null) {
			preRTypePolicies = new EObjectResolvingEList<RTypePolicy>(RTypePolicy.class, this,
					NewTravelPlannerPackage.PRE_CALL_POLICY__PRE_RTYPE_POLICIES);
		}
		return preRTypePolicies;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<TTypePolicy> getPreTTypePolicies() {
		if (preTTypePolicies == null) {
			preTTypePolicies = new EObjectResolvingEList<TTypePolicy>(TTypePolicy.class, this,
					NewTravelPlannerPackage.PRE_CALL_POLICY__PRE_TTYPE_POLICIES);
		}
		return preTTypePolicies;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case NewTravelPlannerPackage.PRE_CALL_POLICY__PRE_RTYPE_POLICIES:
			return getPreRTypePolicies();
		case NewTravelPlannerPackage.PRE_CALL_POLICY__PRE_TTYPE_POLICIES:
			return getPreTTypePolicies();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case NewTravelPlannerPackage.PRE_CALL_POLICY__PRE_RTYPE_POLICIES:
			getPreRTypePolicies().clear();
			getPreRTypePolicies().addAll((Collection<? extends RTypePolicy>) newValue);
			return;
		case NewTravelPlannerPackage.PRE_CALL_POLICY__PRE_TTYPE_POLICIES:
			getPreTTypePolicies().clear();
			getPreTTypePolicies().addAll((Collection<? extends TTypePolicy>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case NewTravelPlannerPackage.PRE_CALL_POLICY__PRE_RTYPE_POLICIES:
			getPreRTypePolicies().clear();
			return;
		case NewTravelPlannerPackage.PRE_CALL_POLICY__PRE_TTYPE_POLICIES:
			getPreTTypePolicies().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case NewTravelPlannerPackage.PRE_CALL_POLICY__PRE_RTYPE_POLICIES:
			return preRTypePolicies != null && !preRTypePolicies.isEmpty();
		case NewTravelPlannerPackage.PRE_CALL_POLICY__PRE_TTYPE_POLICIES:
			return preTTypePolicies != null && !preTTypePolicies.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //PreCallPolicyImpl
