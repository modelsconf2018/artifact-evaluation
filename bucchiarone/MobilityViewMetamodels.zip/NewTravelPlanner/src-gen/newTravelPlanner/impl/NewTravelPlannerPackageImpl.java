/**
 */
package newTravelPlanner.impl;

import newTravelPlanner.NewTravelPlannerFactory;
import newTravelPlanner.NewTravelPlannerPackage;
import newTravelPlanner.Policy;
import newTravelPlanner.PostCallPolicy;
import newTravelPlanner.PreCallPolicy;
import newTravelPlanner.RType;
import newTravelPlanner.RTypePolicy;
import newTravelPlanner.RouteType;
import newTravelPlanner.SmartPlannerParameters;
import newTravelPlanner.TType;
import newTravelPlanner.TTypePolicy;
import newTravelPlanner.TransportType;
import newTravelPlanner.TravelPlanner;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class NewTravelPlannerPackageImpl extends EPackageImpl implements NewTravelPlannerPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass travelPlannerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass preCallPolicyEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass policyEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass transportTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass smartPlannerParametersEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass tTypePolicyEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass rTypePolicyEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass routeTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass postCallPolicyEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum tTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum rTypeEEnum = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see newTravelPlanner.NewTravelPlannerPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private NewTravelPlannerPackageImpl() {
		super(eNS_URI, NewTravelPlannerFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 * 
	 * <p>This method is used to initialize {@link NewTravelPlannerPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static NewTravelPlannerPackage init() {
		if (isInited)
			return (NewTravelPlannerPackage) EPackage.Registry.INSTANCE.getEPackage(NewTravelPlannerPackage.eNS_URI);

		// Obtain or create and register package
		NewTravelPlannerPackageImpl theNewTravelPlannerPackage = (NewTravelPlannerPackageImpl) (EPackage.Registry.INSTANCE
				.get(eNS_URI) instanceof NewTravelPlannerPackageImpl ? EPackage.Registry.INSTANCE.get(eNS_URI)
						: new NewTravelPlannerPackageImpl());

		isInited = true;

		// Create package meta-data objects
		theNewTravelPlannerPackage.createPackageContents();

		// Initialize created meta-data
		theNewTravelPlannerPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theNewTravelPlannerPackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(NewTravelPlannerPackage.eNS_URI, theNewTravelPlannerPackage);
		return theNewTravelPlannerPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTravelPlanner() {
		return travelPlannerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTravelPlanner_Place() {
		return (EAttribute) travelPlannerEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTravelPlanner_Precallpolicies() {
		return (EReference) travelPlannerEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTravelPlanner_TTypes() {
		return (EReference) travelPlannerEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTravelPlanner_Smartplannerparameters() {
		return (EReference) travelPlannerEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTravelPlanner_RTypes() {
		return (EReference) travelPlannerEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTravelPlanner_Postcallpolicies() {
		return (EReference) travelPlannerEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTravelPlanner_Policies() {
		return (EReference) travelPlannerEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPreCallPolicy() {
		return preCallPolicyEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPreCallPolicy_PreRTypePolicies() {
		return (EReference) preCallPolicyEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPreCallPolicy_PreTTypePolicies() {
		return (EReference) preCallPolicyEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPolicy() {
		return policyEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPolicy_Name() {
		return (EAttribute) policyEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTransportType() {
		return transportTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTransportType_TypeName() {
		return (EAttribute) transportTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getSmartPlannerParameters() {
		return smartPlannerParametersEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSmartPlannerParameters_SppName() {
		return (EAttribute) smartPlannerParametersEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSmartPlannerParameters_MaxWalkDistance() {
		return (EAttribute) smartPlannerParametersEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSmartPlannerParameters_MaxTotalWalkDistance() {
		return (EAttribute) smartPlannerParametersEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSmartPlannerParameters_ExtraTransport() {
		return (EAttribute) smartPlannerParametersEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getSmartPlannerParameters_MaxChanges() {
		return (EAttribute) smartPlannerParametersEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTTypePolicy() {
		return tTypePolicyEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTTypePolicy_IncludedTTypes() {
		return (EReference) tTypePolicyEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTTypePolicy_ExcludedTTypes() {
		return (EReference) tTypePolicyEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTTypePolicy_Smartplannerparameters() {
		return (EReference) tTypePolicyEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTTypePolicy_IncludedRTPolicies() {
		return (EReference) tTypePolicyEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRTypePolicy() {
		return rTypePolicyEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRTypePolicy_IncludedRTypes() {
		return (EReference) rTypePolicyEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRTypePolicy_ExcludedRTypes() {
		return (EReference) rTypePolicyEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getRTypePolicy_Smartplannerparameters() {
		return (EReference) rTypePolicyEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getRouteType() {
		return routeTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getRouteType_TypeName() {
		return (EAttribute) routeTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPostCallPolicy() {
		return postCallPolicyEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPostCallPolicy_PostTTypePolicies() {
		return (EReference) postCallPolicyEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getPostCallPolicy_PostRTypePolicies() {
		return (EReference) postCallPolicyEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getTType() {
		return tTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getRType() {
		return rTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NewTravelPlannerFactory getNewTravelPlannerFactory() {
		return (NewTravelPlannerFactory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		travelPlannerEClass = createEClass(TRAVEL_PLANNER);
		createEAttribute(travelPlannerEClass, TRAVEL_PLANNER__PLACE);
		createEReference(travelPlannerEClass, TRAVEL_PLANNER__PRECALLPOLICIES);
		createEReference(travelPlannerEClass, TRAVEL_PLANNER__TTYPES);
		createEReference(travelPlannerEClass, TRAVEL_PLANNER__SMARTPLANNERPARAMETERS);
		createEReference(travelPlannerEClass, TRAVEL_PLANNER__RTYPES);
		createEReference(travelPlannerEClass, TRAVEL_PLANNER__POSTCALLPOLICIES);
		createEReference(travelPlannerEClass, TRAVEL_PLANNER__POLICIES);

		preCallPolicyEClass = createEClass(PRE_CALL_POLICY);
		createEReference(preCallPolicyEClass, PRE_CALL_POLICY__PRE_RTYPE_POLICIES);
		createEReference(preCallPolicyEClass, PRE_CALL_POLICY__PRE_TTYPE_POLICIES);

		policyEClass = createEClass(POLICY);
		createEAttribute(policyEClass, POLICY__NAME);

		transportTypeEClass = createEClass(TRANSPORT_TYPE);
		createEAttribute(transportTypeEClass, TRANSPORT_TYPE__TYPE_NAME);

		smartPlannerParametersEClass = createEClass(SMART_PLANNER_PARAMETERS);
		createEAttribute(smartPlannerParametersEClass, SMART_PLANNER_PARAMETERS__SPP_NAME);
		createEAttribute(smartPlannerParametersEClass, SMART_PLANNER_PARAMETERS__MAX_WALK_DISTANCE);
		createEAttribute(smartPlannerParametersEClass, SMART_PLANNER_PARAMETERS__MAX_TOTAL_WALK_DISTANCE);
		createEAttribute(smartPlannerParametersEClass, SMART_PLANNER_PARAMETERS__EXTRA_TRANSPORT);
		createEAttribute(smartPlannerParametersEClass, SMART_PLANNER_PARAMETERS__MAX_CHANGES);

		tTypePolicyEClass = createEClass(TTYPE_POLICY);
		createEReference(tTypePolicyEClass, TTYPE_POLICY__INCLUDED_TTYPES);
		createEReference(tTypePolicyEClass, TTYPE_POLICY__EXCLUDED_TTYPES);
		createEReference(tTypePolicyEClass, TTYPE_POLICY__SMARTPLANNERPARAMETERS);
		createEReference(tTypePolicyEClass, TTYPE_POLICY__INCLUDED_RT_POLICIES);

		rTypePolicyEClass = createEClass(RTYPE_POLICY);
		createEReference(rTypePolicyEClass, RTYPE_POLICY__INCLUDED_RTYPES);
		createEReference(rTypePolicyEClass, RTYPE_POLICY__EXCLUDED_RTYPES);
		createEReference(rTypePolicyEClass, RTYPE_POLICY__SMARTPLANNERPARAMETERS);

		routeTypeEClass = createEClass(ROUTE_TYPE);
		createEAttribute(routeTypeEClass, ROUTE_TYPE__TYPE_NAME);

		postCallPolicyEClass = createEClass(POST_CALL_POLICY);
		createEReference(postCallPolicyEClass, POST_CALL_POLICY__POST_TTYPE_POLICIES);
		createEReference(postCallPolicyEClass, POST_CALL_POLICY__POST_RTYPE_POLICIES);

		// Create enums
		tTypeEEnum = createEEnum(TTYPE);
		rTypeEEnum = createEEnum(RTYPE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		preCallPolicyEClass.getESuperTypes().add(this.getPolicy());
		tTypePolicyEClass.getESuperTypes().add(this.getPolicy());
		rTypePolicyEClass.getESuperTypes().add(this.getPolicy());
		postCallPolicyEClass.getESuperTypes().add(this.getPolicy());

		// Initialize classes, features, and operations; add parameters
		initEClass(travelPlannerEClass, TravelPlanner.class, "TravelPlanner", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getTravelPlanner_Place(), ecorePackage.getEString(), "place", null, 1, 1, TravelPlanner.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTravelPlanner_Precallpolicies(), this.getPreCallPolicy(), null, "precallpolicies", null, 0, 1,
				TravelPlanner.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTravelPlanner_TTypes(), this.getTransportType(), null, "tTypes", null, 0, -1,
				TravelPlanner.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTravelPlanner_Smartplannerparameters(), this.getSmartPlannerParameters(), null,
				"smartplannerparameters", null, 0, -1, TravelPlanner.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTravelPlanner_RTypes(), this.getRouteType(), null, "rTypes", null, 0, -1, TravelPlanner.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTravelPlanner_Postcallpolicies(), this.getPostCallPolicy(), null, "postcallpolicies", null, 0,
				1, TravelPlanner.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTravelPlanner_Policies(), this.getPolicy(), null, "policies", null, 0, -1,
				TravelPlanner.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(preCallPolicyEClass, PreCallPolicy.class, "PreCallPolicy", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getPreCallPolicy_PreRTypePolicies(), this.getRTypePolicy(), null, "preRTypePolicies", null, 0,
				-1, PreCallPolicy.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPreCallPolicy_PreTTypePolicies(), this.getTTypePolicy(), null, "preTTypePolicies", null, 0,
				-1, PreCallPolicy.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(policyEClass, Policy.class, "Policy", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPolicy_Name(), ecorePackage.getEString(), "name", null, 0, 1, Policy.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(transportTypeEClass, TransportType.class, "TransportType", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getTransportType_TypeName(), this.getTType(), "typeName", null, 0, 1, TransportType.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(smartPlannerParametersEClass, SmartPlannerParameters.class, "SmartPlannerParameters", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getSmartPlannerParameters_SppName(), ecorePackage.getEString(), "sppName", null, 0, 1,
				SmartPlannerParameters.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSmartPlannerParameters_MaxWalkDistance(), ecorePackage.getEDouble(), "maxWalkDistance", "-1",
				0, 1, SmartPlannerParameters.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSmartPlannerParameters_MaxTotalWalkDistance(), ecorePackage.getEDouble(),
				"maxTotalWalkDistance", "-1", 0, 1, SmartPlannerParameters.class, !IS_TRANSIENT, !IS_VOLATILE,
				IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSmartPlannerParameters_ExtraTransport(), ecorePackage.getEString(), "extraTransport", null, 0,
				1, SmartPlannerParameters.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getSmartPlannerParameters_MaxChanges(), ecorePackage.getEInt(), "maxChanges", "-1", 0, 1,
				SmartPlannerParameters.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(tTypePolicyEClass, TTypePolicy.class, "TTypePolicy", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getTTypePolicy_IncludedTTypes(), this.getTransportType(), null, "includedTTypes", null, 0, -1,
				TTypePolicy.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTTypePolicy_ExcludedTTypes(), this.getTransportType(), null, "excludedTTypes", null, 0, -1,
				TTypePolicy.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTTypePolicy_Smartplannerparameters(), this.getSmartPlannerParameters(), null,
				"smartplannerparameters", null, 0, 1, TTypePolicy.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTTypePolicy_IncludedRTPolicies(), this.getRTypePolicy(), null, "includedRTPolicies", null, 0,
				-1, TTypePolicy.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(rTypePolicyEClass, RTypePolicy.class, "RTypePolicy", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getRTypePolicy_IncludedRTypes(), this.getRouteType(), null, "includedRTypes", null, 0, -1,
				RTypePolicy.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRTypePolicy_ExcludedRTypes(), this.getRouteType(), null, "excludedRTypes", null, 0, -1,
				RTypePolicy.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getRTypePolicy_Smartplannerparameters(), this.getSmartPlannerParameters(), null,
				"smartplannerparameters", null, 0, 1, RTypePolicy.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(routeTypeEClass, RouteType.class, "RouteType", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getRouteType_TypeName(), this.getRType(), "typeName", null, 0, 1, RouteType.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(postCallPolicyEClass, PostCallPolicy.class, "PostCallPolicy", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getPostCallPolicy_PostTTypePolicies(), this.getTTypePolicy(), null, "postTTypePolicies", null, 0,
				-1, PostCallPolicy.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getPostCallPolicy_PostRTypePolicies(), this.getRTypePolicy(), null, "postRTypePolicies", null, 0,
				-1, PostCallPolicy.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Initialize enums and add enum literals
		initEEnum(tTypeEEnum, TType.class, "TType");
		addEEnumLiteral(tTypeEEnum, TType.CAR);
		addEEnumLiteral(tTypeEEnum, TType.CARWITHPARKING);
		addEEnumLiteral(tTypeEEnum, TType.PARK_AND_RIDE);
		addEEnumLiteral(tTypeEEnum, TType.TRANSIT);
		addEEnumLiteral(tTypeEEnum, TType.TRAIN);
		addEEnumLiteral(tTypeEEnum, TType.BUS);
		addEEnumLiteral(tTypeEEnum, TType.WALK);
		addEEnumLiteral(tTypeEEnum, TType.SHAREDBIKE);
		addEEnumLiteral(tTypeEEnum, TType.SHAREDCAR);
		addEEnumLiteral(tTypeEEnum, TType.BICYCLE);
		addEEnumLiteral(tTypeEEnum, TType.SHAREDBIKE_WITHOUT_STATION);

		initEEnum(rTypeEEnum, RType.class, "RType");
		addEEnumLiteral(rTypeEEnum, RType.FASTEST);
		addEEnumLiteral(rTypeEEnum, RType.GREENEST);
		addEEnumLiteral(rTypeEEnum, RType.HEALTHY);
		addEEnumLiteral(rTypeEEnum, RType.LEASTCHANGES);
		addEEnumLiteral(rTypeEEnum, RType.LEASTWALKING);
		addEEnumLiteral(rTypeEEnum, RType.SAFEST);

		// Create resource
		createResource(eNS_URI);
	}

} //NewTravelPlannerPackageImpl
