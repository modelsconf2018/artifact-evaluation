/**
 */
package newTravelPlanner.impl;

import newTravelPlanner.NewTravelPlannerPackage;
import newTravelPlanner.SmartPlannerParameters;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Smart Planner Parameters</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link newTravelPlanner.impl.SmartPlannerParametersImpl#getSppName <em>Spp Name</em>}</li>
 *   <li>{@link newTravelPlanner.impl.SmartPlannerParametersImpl#getMaxWalkDistance <em>Max Walk Distance</em>}</li>
 *   <li>{@link newTravelPlanner.impl.SmartPlannerParametersImpl#getMaxTotalWalkDistance <em>Max Total Walk Distance</em>}</li>
 *   <li>{@link newTravelPlanner.impl.SmartPlannerParametersImpl#getExtraTransport <em>Extra Transport</em>}</li>
 *   <li>{@link newTravelPlanner.impl.SmartPlannerParametersImpl#getMaxChanges <em>Max Changes</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SmartPlannerParametersImpl extends MinimalEObjectImpl.Container implements SmartPlannerParameters {
	/**
	 * The default value of the '{@link #getSppName() <em>Spp Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSppName()
	 * @generated
	 * @ordered
	 */
	protected static final String SPP_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getSppName() <em>Spp Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSppName()
	 * @generated
	 * @ordered
	 */
	protected String sppName = SPP_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getMaxWalkDistance() <em>Max Walk Distance</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMaxWalkDistance()
	 * @generated
	 * @ordered
	 */
	protected static final double MAX_WALK_DISTANCE_EDEFAULT = -1.0;

	/**
	 * The cached value of the '{@link #getMaxWalkDistance() <em>Max Walk Distance</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMaxWalkDistance()
	 * @generated
	 * @ordered
	 */
	protected double maxWalkDistance = MAX_WALK_DISTANCE_EDEFAULT;

	/**
	 * The default value of the '{@link #getMaxTotalWalkDistance() <em>Max Total Walk Distance</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMaxTotalWalkDistance()
	 * @generated
	 * @ordered
	 */
	protected static final double MAX_TOTAL_WALK_DISTANCE_EDEFAULT = -1.0;

	/**
	 * The cached value of the '{@link #getMaxTotalWalkDistance() <em>Max Total Walk Distance</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMaxTotalWalkDistance()
	 * @generated
	 * @ordered
	 */
	protected double maxTotalWalkDistance = MAX_TOTAL_WALK_DISTANCE_EDEFAULT;

	/**
	 * The default value of the '{@link #getExtraTransport() <em>Extra Transport</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExtraTransport()
	 * @generated
	 * @ordered
	 */
	protected static final String EXTRA_TRANSPORT_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getExtraTransport() <em>Extra Transport</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getExtraTransport()
	 * @generated
	 * @ordered
	 */
	protected String extraTransport = EXTRA_TRANSPORT_EDEFAULT;

	/**
	 * The default value of the '{@link #getMaxChanges() <em>Max Changes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMaxChanges()
	 * @generated
	 * @ordered
	 */
	protected static final int MAX_CHANGES_EDEFAULT = -1;

	/**
	 * The cached value of the '{@link #getMaxChanges() <em>Max Changes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMaxChanges()
	 * @generated
	 * @ordered
	 */
	protected int maxChanges = MAX_CHANGES_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SmartPlannerParametersImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return NewTravelPlannerPackage.Literals.SMART_PLANNER_PARAMETERS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getSppName() {
		return sppName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSppName(String newSppName) {
		String oldSppName = sppName;
		sppName = newSppName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					NewTravelPlannerPackage.SMART_PLANNER_PARAMETERS__SPP_NAME, oldSppName, sppName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public double getMaxWalkDistance() {
		return maxWalkDistance;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMaxWalkDistance(double newMaxWalkDistance) {
		double oldMaxWalkDistance = maxWalkDistance;
		maxWalkDistance = newMaxWalkDistance;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					NewTravelPlannerPackage.SMART_PLANNER_PARAMETERS__MAX_WALK_DISTANCE, oldMaxWalkDistance,
					maxWalkDistance));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public double getMaxTotalWalkDistance() {
		return maxTotalWalkDistance;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMaxTotalWalkDistance(double newMaxTotalWalkDistance) {
		double oldMaxTotalWalkDistance = maxTotalWalkDistance;
		maxTotalWalkDistance = newMaxTotalWalkDistance;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					NewTravelPlannerPackage.SMART_PLANNER_PARAMETERS__MAX_TOTAL_WALK_DISTANCE, oldMaxTotalWalkDistance,
					maxTotalWalkDistance));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getExtraTransport() {
		return extraTransport;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setExtraTransport(String newExtraTransport) {
		String oldExtraTransport = extraTransport;
		extraTransport = newExtraTransport;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					NewTravelPlannerPackage.SMART_PLANNER_PARAMETERS__EXTRA_TRANSPORT, oldExtraTransport,
					extraTransport));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getMaxChanges() {
		return maxChanges;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setMaxChanges(int newMaxChanges) {
		int oldMaxChanges = maxChanges;
		maxChanges = newMaxChanges;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET,
					NewTravelPlannerPackage.SMART_PLANNER_PARAMETERS__MAX_CHANGES, oldMaxChanges, maxChanges));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case NewTravelPlannerPackage.SMART_PLANNER_PARAMETERS__SPP_NAME:
			return getSppName();
		case NewTravelPlannerPackage.SMART_PLANNER_PARAMETERS__MAX_WALK_DISTANCE:
			return getMaxWalkDistance();
		case NewTravelPlannerPackage.SMART_PLANNER_PARAMETERS__MAX_TOTAL_WALK_DISTANCE:
			return getMaxTotalWalkDistance();
		case NewTravelPlannerPackage.SMART_PLANNER_PARAMETERS__EXTRA_TRANSPORT:
			return getExtraTransport();
		case NewTravelPlannerPackage.SMART_PLANNER_PARAMETERS__MAX_CHANGES:
			return getMaxChanges();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case NewTravelPlannerPackage.SMART_PLANNER_PARAMETERS__SPP_NAME:
			setSppName((String) newValue);
			return;
		case NewTravelPlannerPackage.SMART_PLANNER_PARAMETERS__MAX_WALK_DISTANCE:
			setMaxWalkDistance((Double) newValue);
			return;
		case NewTravelPlannerPackage.SMART_PLANNER_PARAMETERS__MAX_TOTAL_WALK_DISTANCE:
			setMaxTotalWalkDistance((Double) newValue);
			return;
		case NewTravelPlannerPackage.SMART_PLANNER_PARAMETERS__EXTRA_TRANSPORT:
			setExtraTransport((String) newValue);
			return;
		case NewTravelPlannerPackage.SMART_PLANNER_PARAMETERS__MAX_CHANGES:
			setMaxChanges((Integer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case NewTravelPlannerPackage.SMART_PLANNER_PARAMETERS__SPP_NAME:
			setSppName(SPP_NAME_EDEFAULT);
			return;
		case NewTravelPlannerPackage.SMART_PLANNER_PARAMETERS__MAX_WALK_DISTANCE:
			setMaxWalkDistance(MAX_WALK_DISTANCE_EDEFAULT);
			return;
		case NewTravelPlannerPackage.SMART_PLANNER_PARAMETERS__MAX_TOTAL_WALK_DISTANCE:
			setMaxTotalWalkDistance(MAX_TOTAL_WALK_DISTANCE_EDEFAULT);
			return;
		case NewTravelPlannerPackage.SMART_PLANNER_PARAMETERS__EXTRA_TRANSPORT:
			setExtraTransport(EXTRA_TRANSPORT_EDEFAULT);
			return;
		case NewTravelPlannerPackage.SMART_PLANNER_PARAMETERS__MAX_CHANGES:
			setMaxChanges(MAX_CHANGES_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case NewTravelPlannerPackage.SMART_PLANNER_PARAMETERS__SPP_NAME:
			return SPP_NAME_EDEFAULT == null ? sppName != null : !SPP_NAME_EDEFAULT.equals(sppName);
		case NewTravelPlannerPackage.SMART_PLANNER_PARAMETERS__MAX_WALK_DISTANCE:
			return maxWalkDistance != MAX_WALK_DISTANCE_EDEFAULT;
		case NewTravelPlannerPackage.SMART_PLANNER_PARAMETERS__MAX_TOTAL_WALK_DISTANCE:
			return maxTotalWalkDistance != MAX_TOTAL_WALK_DISTANCE_EDEFAULT;
		case NewTravelPlannerPackage.SMART_PLANNER_PARAMETERS__EXTRA_TRANSPORT:
			return EXTRA_TRANSPORT_EDEFAULT == null ? extraTransport != null
					: !EXTRA_TRANSPORT_EDEFAULT.equals(extraTransport);
		case NewTravelPlannerPackage.SMART_PLANNER_PARAMETERS__MAX_CHANGES:
			return maxChanges != MAX_CHANGES_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (sppName: ");
		result.append(sppName);
		result.append(", maxWalkDistance: ");
		result.append(maxWalkDistance);
		result.append(", maxTotalWalkDistance: ");
		result.append(maxTotalWalkDistance);
		result.append(", extraTransport: ");
		result.append(extraTransport);
		result.append(", maxChanges: ");
		result.append(maxChanges);
		result.append(')');
		return result.toString();
	}

} //SmartPlannerParametersImpl
