/**
 */
package newTravelPlanner;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>TType Policy</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link newTravelPlanner.TTypePolicy#getIncludedTTypes <em>Included TTypes</em>}</li>
 *   <li>{@link newTravelPlanner.TTypePolicy#getExcludedTTypes <em>Excluded TTypes</em>}</li>
 *   <li>{@link newTravelPlanner.TTypePolicy#getSmartplannerparameters <em>Smartplannerparameters</em>}</li>
 *   <li>{@link newTravelPlanner.TTypePolicy#getIncludedRTPolicies <em>Included RT Policies</em>}</li>
 * </ul>
 *
 * @see newTravelPlanner.NewTravelPlannerPackage#getTTypePolicy()
 * @model
 * @generated
 */
public interface TTypePolicy extends Policy {
	/**
	 * Returns the value of the '<em><b>Included TTypes</b></em>' reference list.
	 * The list contents are of type {@link newTravelPlanner.TransportType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Included TTypes</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Included TTypes</em>' reference list.
	 * @see newTravelPlanner.NewTravelPlannerPackage#getTTypePolicy_IncludedTTypes()
	 * @model
	 * @generated
	 */
	EList<TransportType> getIncludedTTypes();

	/**
	 * Returns the value of the '<em><b>Excluded TTypes</b></em>' reference list.
	 * The list contents are of type {@link newTravelPlanner.TransportType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Excluded TTypes</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Excluded TTypes</em>' reference list.
	 * @see newTravelPlanner.NewTravelPlannerPackage#getTTypePolicy_ExcludedTTypes()
	 * @model
	 * @generated
	 */
	EList<TransportType> getExcludedTTypes();

	/**
	 * Returns the value of the '<em><b>Smartplannerparameters</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Smartplannerparameters</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Smartplannerparameters</em>' reference.
	 * @see #setSmartplannerparameters(SmartPlannerParameters)
	 * @see newTravelPlanner.NewTravelPlannerPackage#getTTypePolicy_Smartplannerparameters()
	 * @model
	 * @generated
	 */
	SmartPlannerParameters getSmartplannerparameters();

	/**
	 * Sets the value of the '{@link newTravelPlanner.TTypePolicy#getSmartplannerparameters <em>Smartplannerparameters</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Smartplannerparameters</em>' reference.
	 * @see #getSmartplannerparameters()
	 * @generated
	 */
	void setSmartplannerparameters(SmartPlannerParameters value);

	/**
	 * Returns the value of the '<em><b>Included RT Policies</b></em>' reference list.
	 * The list contents are of type {@link newTravelPlanner.RTypePolicy}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Included RT Policies</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Included RT Policies</em>' reference list.
	 * @see newTravelPlanner.NewTravelPlannerPackage#getTTypePolicy_IncludedRTPolicies()
	 * @model
	 * @generated
	 */
	EList<RTypePolicy> getIncludedRTPolicies();

} // TTypePolicy
