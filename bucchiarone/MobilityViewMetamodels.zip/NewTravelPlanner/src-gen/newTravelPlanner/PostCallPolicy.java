/**
 */
package newTravelPlanner;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Post Call Policy</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link newTravelPlanner.PostCallPolicy#getPostTTypePolicies <em>Post TType Policies</em>}</li>
 *   <li>{@link newTravelPlanner.PostCallPolicy#getPostRTypePolicies <em>Post RType Policies</em>}</li>
 * </ul>
 *
 * @see newTravelPlanner.NewTravelPlannerPackage#getPostCallPolicy()
 * @model abstract="true"
 * @generated
 */
public interface PostCallPolicy extends Policy {

	/**
	 * Returns the value of the '<em><b>Post TType Policies</b></em>' reference list.
	 * The list contents are of type {@link newTravelPlanner.TTypePolicy}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Post TType Policies</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Post TType Policies</em>' reference list.
	 * @see newTravelPlanner.NewTravelPlannerPackage#getPostCallPolicy_PostTTypePolicies()
	 * @model
	 * @generated
	 */
	EList<TTypePolicy> getPostTTypePolicies();

	/**
	 * Returns the value of the '<em><b>Post RType Policies</b></em>' reference list.
	 * The list contents are of type {@link newTravelPlanner.RTypePolicy}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Post RType Policies</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Post RType Policies</em>' reference list.
	 * @see newTravelPlanner.NewTravelPlannerPackage#getPostCallPolicy_PostRTypePolicies()
	 * @model
	 * @generated
	 */
	EList<RTypePolicy> getPostRTypePolicies();
} // PostCallPolicy
