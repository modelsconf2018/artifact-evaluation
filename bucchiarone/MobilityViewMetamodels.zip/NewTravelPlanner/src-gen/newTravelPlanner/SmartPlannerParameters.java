/**
 */
package newTravelPlanner;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Smart Planner Parameters</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link newTravelPlanner.SmartPlannerParameters#getSppName <em>Spp Name</em>}</li>
 *   <li>{@link newTravelPlanner.SmartPlannerParameters#getMaxWalkDistance <em>Max Walk Distance</em>}</li>
 *   <li>{@link newTravelPlanner.SmartPlannerParameters#getMaxTotalWalkDistance <em>Max Total Walk Distance</em>}</li>
 *   <li>{@link newTravelPlanner.SmartPlannerParameters#getExtraTransport <em>Extra Transport</em>}</li>
 *   <li>{@link newTravelPlanner.SmartPlannerParameters#getMaxChanges <em>Max Changes</em>}</li>
 * </ul>
 *
 * @see newTravelPlanner.NewTravelPlannerPackage#getSmartPlannerParameters()
 * @model
 * @generated
 */
public interface SmartPlannerParameters extends EObject {
	/**
	 * Returns the value of the '<em><b>Spp Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Spp Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Spp Name</em>' attribute.
	 * @see #setSppName(String)
	 * @see newTravelPlanner.NewTravelPlannerPackage#getSmartPlannerParameters_SppName()
	 * @model
	 * @generated
	 */
	String getSppName();

	/**
	 * Sets the value of the '{@link newTravelPlanner.SmartPlannerParameters#getSppName <em>Spp Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Spp Name</em>' attribute.
	 * @see #getSppName()
	 * @generated
	 */
	void setSppName(String value);

	/**
	 * Returns the value of the '<em><b>Max Walk Distance</b></em>' attribute.
	 * The default value is <code>"-1"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Max Walk Distance</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Max Walk Distance</em>' attribute.
	 * @see #setMaxWalkDistance(double)
	 * @see newTravelPlanner.NewTravelPlannerPackage#getSmartPlannerParameters_MaxWalkDistance()
	 * @model default="-1"
	 * @generated
	 */
	double getMaxWalkDistance();

	/**
	 * Sets the value of the '{@link newTravelPlanner.SmartPlannerParameters#getMaxWalkDistance <em>Max Walk Distance</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Max Walk Distance</em>' attribute.
	 * @see #getMaxWalkDistance()
	 * @generated
	 */
	void setMaxWalkDistance(double value);

	/**
	 * Returns the value of the '<em><b>Max Total Walk Distance</b></em>' attribute.
	 * The default value is <code>"-1"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Max Total Walk Distance</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Max Total Walk Distance</em>' attribute.
	 * @see #setMaxTotalWalkDistance(double)
	 * @see newTravelPlanner.NewTravelPlannerPackage#getSmartPlannerParameters_MaxTotalWalkDistance()
	 * @model default="-1"
	 * @generated
	 */
	double getMaxTotalWalkDistance();

	/**
	 * Sets the value of the '{@link newTravelPlanner.SmartPlannerParameters#getMaxTotalWalkDistance <em>Max Total Walk Distance</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Max Total Walk Distance</em>' attribute.
	 * @see #getMaxTotalWalkDistance()
	 * @generated
	 */
	void setMaxTotalWalkDistance(double value);

	/**
	 * Returns the value of the '<em><b>Extra Transport</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Extra Transport</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Extra Transport</em>' attribute.
	 * @see #setExtraTransport(String)
	 * @see newTravelPlanner.NewTravelPlannerPackage#getSmartPlannerParameters_ExtraTransport()
	 * @model
	 * @generated
	 */
	String getExtraTransport();

	/**
	 * Sets the value of the '{@link newTravelPlanner.SmartPlannerParameters#getExtraTransport <em>Extra Transport</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Extra Transport</em>' attribute.
	 * @see #getExtraTransport()
	 * @generated
	 */
	void setExtraTransport(String value);

	/**
	 * Returns the value of the '<em><b>Max Changes</b></em>' attribute.
	 * The default value is <code>"-1"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Max Changes</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Max Changes</em>' attribute.
	 * @see #setMaxChanges(int)
	 * @see newTravelPlanner.NewTravelPlannerPackage#getSmartPlannerParameters_MaxChanges()
	 * @model default="-1"
	 * @generated
	 */
	int getMaxChanges();

	/**
	 * Sets the value of the '{@link newTravelPlanner.SmartPlannerParameters#getMaxChanges <em>Max Changes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Max Changes</em>' attribute.
	 * @see #getMaxChanges()
	 * @generated
	 */
	void setMaxChanges(int value);

} // SmartPlannerParameters
