/**
 */
package newTravelPlanner;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Pre Call Policy</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link newTravelPlanner.PreCallPolicy#getPreRTypePolicies <em>Pre RType Policies</em>}</li>
 *   <li>{@link newTravelPlanner.PreCallPolicy#getPreTTypePolicies <em>Pre TType Policies</em>}</li>
 * </ul>
 *
 * @see newTravelPlanner.NewTravelPlannerPackage#getPreCallPolicy()
 * @model abstract="true"
 * @generated
 */
public interface PreCallPolicy extends Policy {

	/**
	 * Returns the value of the '<em><b>Pre RType Policies</b></em>' reference list.
	 * The list contents are of type {@link newTravelPlanner.RTypePolicy}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Pre RType Policies</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pre RType Policies</em>' reference list.
	 * @see newTravelPlanner.NewTravelPlannerPackage#getPreCallPolicy_PreRTypePolicies()
	 * @model
	 * @generated
	 */
	EList<RTypePolicy> getPreRTypePolicies();

	/**
	 * Returns the value of the '<em><b>Pre TType Policies</b></em>' reference list.
	 * The list contents are of type {@link newTravelPlanner.TTypePolicy}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Pre TType Policies</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Pre TType Policies</em>' reference list.
	 * @see newTravelPlanner.NewTravelPlannerPackage#getPreCallPolicy_PreTTypePolicies()
	 * @model
	 * @generated
	 */
	EList<TTypePolicy> getPreTTypePolicies();
} // PreCallPolicy
