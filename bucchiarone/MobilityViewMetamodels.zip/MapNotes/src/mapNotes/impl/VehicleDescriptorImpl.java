/**
 */
package mapNotes.impl;

import mapNotes.MapNotesPackage;
import mapNotes.VehicleDescriptor;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Vehicle Descriptor</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mapNotes.impl.VehicleDescriptorImpl#getId <em>Id</em>}</li>
 *   <li>{@link mapNotes.impl.VehicleDescriptorImpl#getLabel <em>Label</em>}</li>
 *   <li>{@link mapNotes.impl.VehicleDescriptorImpl#getLicense_plate <em>License plate</em>}</li>
 * </ul>
 *
 * @generated
 */
public class VehicleDescriptorImpl extends MinimalEObjectImpl.Container implements VehicleDescriptor {
	/**
	 * The default value of the '{@link #getId() <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId()
	 * @generated
	 * @ordered
	 */
	protected static final String ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getId() <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId()
	 * @generated
	 * @ordered
	 */
	protected String id = ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getLabel() <em>Label</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLabel()
	 * @generated
	 * @ordered
	 */
	protected static final String LABEL_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getLabel() <em>Label</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLabel()
	 * @generated
	 * @ordered
	 */
	protected String label = LABEL_EDEFAULT;

	/**
	 * The default value of the '{@link #getLicense_plate() <em>License plate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLicense_plate()
	 * @generated
	 * @ordered
	 */
	protected static final String LICENSE_PLATE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getLicense_plate() <em>License plate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLicense_plate()
	 * @generated
	 * @ordered
	 */
	protected String license_plate = LICENSE_PLATE_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected VehicleDescriptorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MapNotesPackage.Literals.VEHICLE_DESCRIPTOR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getId() {
		return id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setId(String newId) {
		String oldId = id;
		id = newId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.VEHICLE_DESCRIPTOR__ID, oldId, id));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLabel() {
		return label;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLabel(String newLabel) {
		String oldLabel = label;
		label = newLabel;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.VEHICLE_DESCRIPTOR__LABEL, oldLabel, label));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLicense_plate() {
		return license_plate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLicense_plate(String newLicense_plate) {
		String oldLicense_plate = license_plate;
		license_plate = newLicense_plate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.VEHICLE_DESCRIPTOR__LICENSE_PLATE, oldLicense_plate, license_plate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case MapNotesPackage.VEHICLE_DESCRIPTOR__ID:
				return getId();
			case MapNotesPackage.VEHICLE_DESCRIPTOR__LABEL:
				return getLabel();
			case MapNotesPackage.VEHICLE_DESCRIPTOR__LICENSE_PLATE:
				return getLicense_plate();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case MapNotesPackage.VEHICLE_DESCRIPTOR__ID:
				setId((String)newValue);
				return;
			case MapNotesPackage.VEHICLE_DESCRIPTOR__LABEL:
				setLabel((String)newValue);
				return;
			case MapNotesPackage.VEHICLE_DESCRIPTOR__LICENSE_PLATE:
				setLicense_plate((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case MapNotesPackage.VEHICLE_DESCRIPTOR__ID:
				setId(ID_EDEFAULT);
				return;
			case MapNotesPackage.VEHICLE_DESCRIPTOR__LABEL:
				setLabel(LABEL_EDEFAULT);
				return;
			case MapNotesPackage.VEHICLE_DESCRIPTOR__LICENSE_PLATE:
				setLicense_plate(LICENSE_PLATE_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case MapNotesPackage.VEHICLE_DESCRIPTOR__ID:
				return ID_EDEFAULT == null ? id != null : !ID_EDEFAULT.equals(id);
			case MapNotesPackage.VEHICLE_DESCRIPTOR__LABEL:
				return LABEL_EDEFAULT == null ? label != null : !LABEL_EDEFAULT.equals(label);
			case MapNotesPackage.VEHICLE_DESCRIPTOR__LICENSE_PLATE:
				return LICENSE_PLATE_EDEFAULT == null ? license_plate != null : !LICENSE_PLATE_EDEFAULT.equals(license_plate);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (id: ");
		result.append(id);
		result.append(", label: ");
		result.append(label);
		result.append(", license_plate: ");
		result.append(license_plate);
		result.append(')');
		return result.toString();
	}

} //VehicleDescriptorImpl
