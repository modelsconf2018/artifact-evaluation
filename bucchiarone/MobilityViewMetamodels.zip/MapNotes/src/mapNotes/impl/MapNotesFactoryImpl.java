/**
 */
package mapNotes.impl;

import mapNotes.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class MapNotesFactoryImpl extends EFactoryImpl implements MapNotesFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static MapNotesFactory init() {
		try {
			MapNotesFactory theMapNotesFactory = (MapNotesFactory)EPackage.Registry.INSTANCE.getEFactory(MapNotesPackage.eNS_URI);
			if (theMapNotesFactory != null) {
				return theMapNotesFactory;
			}
		}
		catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new MapNotesFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MapNotesFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
			case MapNotesPackage.MAP_NOTES: return createMapNotes();
			case MapNotesPackage.TRAFFIC_REMARK: return createTrafficRemark();
			case MapNotesPackage.BIKE_SHARING_REMARK: return createBikeSharingRemark();
			case MapNotesPackage.PARKING_REMARK: return createParkingRemark();
			case MapNotesPackage.TRANSIT_REMARK: return createTransitRemark();
			case MapNotesPackage.TRIP_UPDATE: return createTripUpdate();
			case MapNotesPackage.VEHICLE: return createVehicle();
			case MapNotesPackage.ALERT: return createAlert();
			case MapNotesPackage.TRIP_DESCRIPTOR: return createTripDescriptor();
			case MapNotesPackage.VEHICLE_DESCRIPTOR: return createVehicleDescriptor();
			case MapNotesPackage.STOP_TIME_UPDATE: return createStopTimeUpdate();
			case MapNotesPackage.STOP_TIME_EVENT: return createStopTimeEvent();
			case MapNotesPackage.TIME_RANGE: return createTimeRange();
			case MapNotesPackage.ENTITY_SELECTOR: return createEntitySelector();
			case MapNotesPackage.POSITION: return createPosition();
			default:
				throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
			case MapNotesPackage.STOP_TIME_SCHEDULE_RELATIONSHIP:
				return createStopTimeScheduleRelationshipFromString(eDataType, initialValue);
			case MapNotesPackage.VEHICLE_STOP_STATUS:
				return createVehicleStopStatusFromString(eDataType, initialValue);
			case MapNotesPackage.CONGESTION_LEVEL:
				return createCongestionLevelFromString(eDataType, initialValue);
			case MapNotesPackage.OCCUPANCY_STATUS:
				return createOccupancyStatusFromString(eDataType, initialValue);
			case MapNotesPackage.CAUSE:
				return createCauseFromString(eDataType, initialValue);
			case MapNotesPackage.EFFECT:
				return createEffectFromString(eDataType, initialValue);
			case MapNotesPackage.TRIP_TIME_SCHEDULE_RELATIONSHIP:
				return createTripTimeScheduleRelationshipFromString(eDataType, initialValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
			case MapNotesPackage.STOP_TIME_SCHEDULE_RELATIONSHIP:
				return convertStopTimeScheduleRelationshipToString(eDataType, instanceValue);
			case MapNotesPackage.VEHICLE_STOP_STATUS:
				return convertVehicleStopStatusToString(eDataType, instanceValue);
			case MapNotesPackage.CONGESTION_LEVEL:
				return convertCongestionLevelToString(eDataType, instanceValue);
			case MapNotesPackage.OCCUPANCY_STATUS:
				return convertOccupancyStatusToString(eDataType, instanceValue);
			case MapNotesPackage.CAUSE:
				return convertCauseToString(eDataType, instanceValue);
			case MapNotesPackage.EFFECT:
				return convertEffectToString(eDataType, instanceValue);
			case MapNotesPackage.TRIP_TIME_SCHEDULE_RELATIONSHIP:
				return convertTripTimeScheduleRelationshipToString(eDataType, instanceValue);
			default:
				throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MapNotes createMapNotes() {
		MapNotesImpl mapNotes = new MapNotesImpl();
		return mapNotes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TrafficRemark createTrafficRemark() {
		TrafficRemarkImpl trafficRemark = new TrafficRemarkImpl();
		return trafficRemark;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public BikeSharingRemark createBikeSharingRemark() {
		BikeSharingRemarkImpl bikeSharingRemark = new BikeSharingRemarkImpl();
		return bikeSharingRemark;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ParkingRemark createParkingRemark() {
		ParkingRemarkImpl parkingRemark = new ParkingRemarkImpl();
		return parkingRemark;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TransitRemark createTransitRemark() {
		TransitRemarkImpl transitRemark = new TransitRemarkImpl();
		return transitRemark;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TripUpdate createTripUpdate() {
		TripUpdateImpl tripUpdate = new TripUpdateImpl();
		return tripUpdate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Vehicle createVehicle() {
		VehicleImpl vehicle = new VehicleImpl();
		return vehicle;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Alert createAlert() {
		AlertImpl alert = new AlertImpl();
		return alert;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TripDescriptor createTripDescriptor() {
		TripDescriptorImpl tripDescriptor = new TripDescriptorImpl();
		return tripDescriptor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VehicleDescriptor createVehicleDescriptor() {
		VehicleDescriptorImpl vehicleDescriptor = new VehicleDescriptorImpl();
		return vehicleDescriptor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public StopTimeUpdate createStopTimeUpdate() {
		StopTimeUpdateImpl stopTimeUpdate = new StopTimeUpdateImpl();
		return stopTimeUpdate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public StopTimeEvent createStopTimeEvent() {
		StopTimeEventImpl stopTimeEvent = new StopTimeEventImpl();
		return stopTimeEvent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TimeRange createTimeRange() {
		TimeRangeImpl timeRange = new TimeRangeImpl();
		return timeRange;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EntitySelector createEntitySelector() {
		EntitySelectorImpl entitySelector = new EntitySelectorImpl();
		return entitySelector;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Position createPosition() {
		PositionImpl position = new PositionImpl();
		return position;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public StopTimeScheduleRelationship createStopTimeScheduleRelationshipFromString(EDataType eDataType, String initialValue) {
		StopTimeScheduleRelationship result = StopTimeScheduleRelationship.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertStopTimeScheduleRelationshipToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public VehicleStopStatus createVehicleStopStatusFromString(EDataType eDataType, String initialValue) {
		VehicleStopStatus result = VehicleStopStatus.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertVehicleStopStatusToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CongestionLevel createCongestionLevelFromString(EDataType eDataType, String initialValue) {
		CongestionLevel result = CongestionLevel.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertCongestionLevelToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OccupancyStatus createOccupancyStatusFromString(EDataType eDataType, String initialValue) {
		OccupancyStatus result = OccupancyStatus.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertOccupancyStatusToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Cause createCauseFromString(EDataType eDataType, String initialValue) {
		Cause result = Cause.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertCauseToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Effect createEffectFromString(EDataType eDataType, String initialValue) {
		Effect result = Effect.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertEffectToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TripTimeScheduleRelationship createTripTimeScheduleRelationshipFromString(EDataType eDataType, String initialValue) {
		TripTimeScheduleRelationship result = TripTimeScheduleRelationship.get(initialValue);
		if (result == null) throw new IllegalArgumentException("The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertTripTimeScheduleRelationshipToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MapNotesPackage getMapNotesPackage() {
		return (MapNotesPackage)getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static MapNotesPackage getPackage() {
		return MapNotesPackage.eINSTANCE;
	}

} //MapNotesFactoryImpl
