/**
 */
package mapNotes.impl;

import java.util.Collection;

import mapNotes.Alert;
import mapNotes.Cause;
import mapNotes.Effect;
import mapNotes.EntitySelector;
import mapNotes.MapNotesPackage;
import mapNotes.TimeRange;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Alert</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mapNotes.impl.AlertImpl#getActive_period <em>Active period</em>}</li>
 *   <li>{@link mapNotes.impl.AlertImpl#getInformed_entity <em>Informed entity</em>}</li>
 *   <li>{@link mapNotes.impl.AlertImpl#getCause <em>Cause</em>}</li>
 *   <li>{@link mapNotes.impl.AlertImpl#getEffect <em>Effect</em>}</li>
 *   <li>{@link mapNotes.impl.AlertImpl#getUrl <em>Url</em>}</li>
 *   <li>{@link mapNotes.impl.AlertImpl#getHeader_text <em>Header text</em>}</li>
 *   <li>{@link mapNotes.impl.AlertImpl#getDescription_text <em>Description text</em>}</li>
 * </ul>
 *
 * @generated
 */
public class AlertImpl extends MinimalEObjectImpl.Container implements Alert {
	/**
	 * The cached value of the '{@link #getActive_period() <em>Active period</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getActive_period()
	 * @generated
	 * @ordered
	 */
	protected EList<TimeRange> active_period;

	/**
	 * The cached value of the '{@link #getInformed_entity() <em>Informed entity</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInformed_entity()
	 * @generated
	 * @ordered
	 */
	protected EList<EntitySelector> informed_entity;

	/**
	 * The default value of the '{@link #getCause() <em>Cause</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCause()
	 * @generated
	 * @ordered
	 */
	protected static final Cause CAUSE_EDEFAULT = Cause.UNKNOWN_CAUSE;

	/**
	 * The cached value of the '{@link #getCause() <em>Cause</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCause()
	 * @generated
	 * @ordered
	 */
	protected Cause cause = CAUSE_EDEFAULT;

	/**
	 * The default value of the '{@link #getEffect() <em>Effect</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEffect()
	 * @generated
	 * @ordered
	 */
	protected static final Effect EFFECT_EDEFAULT = Effect.NO_SERVICE;

	/**
	 * The cached value of the '{@link #getEffect() <em>Effect</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEffect()
	 * @generated
	 * @ordered
	 */
	protected Effect effect = EFFECT_EDEFAULT;

	/**
	 * The default value of the '{@link #getUrl() <em>Url</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUrl()
	 * @generated
	 * @ordered
	 */
	protected static final String URL_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getUrl() <em>Url</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getUrl()
	 * @generated
	 * @ordered
	 */
	protected String url = URL_EDEFAULT;

	/**
	 * The default value of the '{@link #getHeader_text() <em>Header text</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHeader_text()
	 * @generated
	 * @ordered
	 */
	protected static final String HEADER_TEXT_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getHeader_text() <em>Header text</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHeader_text()
	 * @generated
	 * @ordered
	 */
	protected String header_text = HEADER_TEXT_EDEFAULT;

	/**
	 * The default value of the '{@link #getDescription_text() <em>Description text</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDescription_text()
	 * @generated
	 * @ordered
	 */
	protected static final String DESCRIPTION_TEXT_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDescription_text() <em>Description text</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDescription_text()
	 * @generated
	 * @ordered
	 */
	protected String description_text = DESCRIPTION_TEXT_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AlertImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MapNotesPackage.Literals.ALERT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<TimeRange> getActive_period() {
		if (active_period == null) {
			active_period = new EObjectContainmentEList<TimeRange>(TimeRange.class, this, MapNotesPackage.ALERT__ACTIVE_PERIOD);
		}
		return active_period;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<EntitySelector> getInformed_entity() {
		if (informed_entity == null) {
			informed_entity = new EObjectContainmentEList<EntitySelector>(EntitySelector.class, this, MapNotesPackage.ALERT__INFORMED_ENTITY);
		}
		return informed_entity;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Cause getCause() {
		return cause;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setCause(Cause newCause) {
		Cause oldCause = cause;
		cause = newCause == null ? CAUSE_EDEFAULT : newCause;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.ALERT__CAUSE, oldCause, cause));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Effect getEffect() {
		return effect;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEffect(Effect newEffect) {
		Effect oldEffect = effect;
		effect = newEffect == null ? EFFECT_EDEFAULT : newEffect;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.ALERT__EFFECT, oldEffect, effect));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setUrl(String newUrl) {
		String oldUrl = url;
		url = newUrl;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.ALERT__URL, oldUrl, url));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getHeader_text() {
		return header_text;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setHeader_text(String newHeader_text) {
		String oldHeader_text = header_text;
		header_text = newHeader_text;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.ALERT__HEADER_TEXT, oldHeader_text, header_text));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getDescription_text() {
		return description_text;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDescription_text(String newDescription_text) {
		String oldDescription_text = description_text;
		description_text = newDescription_text;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.ALERT__DESCRIPTION_TEXT, oldDescription_text, description_text));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case MapNotesPackage.ALERT__ACTIVE_PERIOD:
				return ((InternalEList<?>)getActive_period()).basicRemove(otherEnd, msgs);
			case MapNotesPackage.ALERT__INFORMED_ENTITY:
				return ((InternalEList<?>)getInformed_entity()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case MapNotesPackage.ALERT__ACTIVE_PERIOD:
				return getActive_period();
			case MapNotesPackage.ALERT__INFORMED_ENTITY:
				return getInformed_entity();
			case MapNotesPackage.ALERT__CAUSE:
				return getCause();
			case MapNotesPackage.ALERT__EFFECT:
				return getEffect();
			case MapNotesPackage.ALERT__URL:
				return getUrl();
			case MapNotesPackage.ALERT__HEADER_TEXT:
				return getHeader_text();
			case MapNotesPackage.ALERT__DESCRIPTION_TEXT:
				return getDescription_text();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case MapNotesPackage.ALERT__ACTIVE_PERIOD:
				getActive_period().clear();
				getActive_period().addAll((Collection<? extends TimeRange>)newValue);
				return;
			case MapNotesPackage.ALERT__INFORMED_ENTITY:
				getInformed_entity().clear();
				getInformed_entity().addAll((Collection<? extends EntitySelector>)newValue);
				return;
			case MapNotesPackage.ALERT__CAUSE:
				setCause((Cause)newValue);
				return;
			case MapNotesPackage.ALERT__EFFECT:
				setEffect((Effect)newValue);
				return;
			case MapNotesPackage.ALERT__URL:
				setUrl((String)newValue);
				return;
			case MapNotesPackage.ALERT__HEADER_TEXT:
				setHeader_text((String)newValue);
				return;
			case MapNotesPackage.ALERT__DESCRIPTION_TEXT:
				setDescription_text((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case MapNotesPackage.ALERT__ACTIVE_PERIOD:
				getActive_period().clear();
				return;
			case MapNotesPackage.ALERT__INFORMED_ENTITY:
				getInformed_entity().clear();
				return;
			case MapNotesPackage.ALERT__CAUSE:
				setCause(CAUSE_EDEFAULT);
				return;
			case MapNotesPackage.ALERT__EFFECT:
				setEffect(EFFECT_EDEFAULT);
				return;
			case MapNotesPackage.ALERT__URL:
				setUrl(URL_EDEFAULT);
				return;
			case MapNotesPackage.ALERT__HEADER_TEXT:
				setHeader_text(HEADER_TEXT_EDEFAULT);
				return;
			case MapNotesPackage.ALERT__DESCRIPTION_TEXT:
				setDescription_text(DESCRIPTION_TEXT_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case MapNotesPackage.ALERT__ACTIVE_PERIOD:
				return active_period != null && !active_period.isEmpty();
			case MapNotesPackage.ALERT__INFORMED_ENTITY:
				return informed_entity != null && !informed_entity.isEmpty();
			case MapNotesPackage.ALERT__CAUSE:
				return cause != CAUSE_EDEFAULT;
			case MapNotesPackage.ALERT__EFFECT:
				return effect != EFFECT_EDEFAULT;
			case MapNotesPackage.ALERT__URL:
				return URL_EDEFAULT == null ? url != null : !URL_EDEFAULT.equals(url);
			case MapNotesPackage.ALERT__HEADER_TEXT:
				return HEADER_TEXT_EDEFAULT == null ? header_text != null : !HEADER_TEXT_EDEFAULT.equals(header_text);
			case MapNotesPackage.ALERT__DESCRIPTION_TEXT:
				return DESCRIPTION_TEXT_EDEFAULT == null ? description_text != null : !DESCRIPTION_TEXT_EDEFAULT.equals(description_text);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (cause: ");
		result.append(cause);
		result.append(", effect: ");
		result.append(effect);
		result.append(", url: ");
		result.append(url);
		result.append(", header_text: ");
		result.append(header_text);
		result.append(", description_text: ");
		result.append(description_text);
		result.append(')');
		return result.toString();
	}

} //AlertImpl
