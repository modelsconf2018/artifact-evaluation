/**
 */
package mapNotes.impl;

import mapNotes.EntitySelector;
import mapNotes.MapNotesPackage;
import mapNotes.TripDescriptor;

import mobilityResources.Agency;
import mobilityResources.Route;
import mobilityResources.Stop;
import mobilityResources.Transit;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Entity Selector</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mapNotes.impl.EntitySelectorImpl#getAgency_id <em>Agency id</em>}</li>
 *   <li>{@link mapNotes.impl.EntitySelectorImpl#getRoute_id <em>Route id</em>}</li>
 *   <li>{@link mapNotes.impl.EntitySelectorImpl#getRoute_type <em>Route type</em>}</li>
 *   <li>{@link mapNotes.impl.EntitySelectorImpl#getTrip <em>Trip</em>}</li>
 *   <li>{@link mapNotes.impl.EntitySelectorImpl#getStop_id <em>Stop id</em>}</li>
 *   <li>{@link mapNotes.impl.EntitySelectorImpl#getName <em>Name</em>}</li>
 * </ul>
 *
 * @generated
 */
public class EntitySelectorImpl extends MinimalEObjectImpl.Container implements EntitySelector {
	/**
	 * The cached value of the '{@link #getAgency_id() <em>Agency id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAgency_id()
	 * @generated
	 * @ordered
	 */
	protected Agency agency_id;

	/**
	 * The cached value of the '{@link #getRoute_id() <em>Route id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRoute_id()
	 * @generated
	 * @ordered
	 */
	protected Route route_id;

	/**
	 * The cached value of the '{@link #getRoute_type() <em>Route type</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRoute_type()
	 * @generated
	 * @ordered
	 */
	protected Transit route_type;

	/**
	 * The cached value of the '{@link #getTrip() <em>Trip</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTrip()
	 * @generated
	 * @ordered
	 */
	protected TripDescriptor trip;

	/**
	 * The cached value of the '{@link #getStop_id() <em>Stop id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStop_id()
	 * @generated
	 * @ordered
	 */
	protected Stop stop_id;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EntitySelectorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MapNotesPackage.Literals.ENTITY_SELECTOR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Agency getAgency_id() {
		if (agency_id != null && agency_id.eIsProxy()) {
			InternalEObject oldAgency_id = (InternalEObject)agency_id;
			agency_id = (Agency)eResolveProxy(oldAgency_id);
			if (agency_id != oldAgency_id) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, MapNotesPackage.ENTITY_SELECTOR__AGENCY_ID, oldAgency_id, agency_id));
			}
		}
		return agency_id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Agency basicGetAgency_id() {
		return agency_id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAgency_id(Agency newAgency_id) {
		Agency oldAgency_id = agency_id;
		agency_id = newAgency_id;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.ENTITY_SELECTOR__AGENCY_ID, oldAgency_id, agency_id));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Route getRoute_id() {
		if (route_id != null && route_id.eIsProxy()) {
			InternalEObject oldRoute_id = (InternalEObject)route_id;
			route_id = (Route)eResolveProxy(oldRoute_id);
			if (route_id != oldRoute_id) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, MapNotesPackage.ENTITY_SELECTOR__ROUTE_ID, oldRoute_id, route_id));
			}
		}
		return route_id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Route basicGetRoute_id() {
		return route_id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRoute_id(Route newRoute_id) {
		Route oldRoute_id = route_id;
		route_id = newRoute_id;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.ENTITY_SELECTOR__ROUTE_ID, oldRoute_id, route_id));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Transit getRoute_type() {
		if (route_type != null && route_type.eIsProxy()) {
			InternalEObject oldRoute_type = (InternalEObject)route_type;
			route_type = (Transit)eResolveProxy(oldRoute_type);
			if (route_type != oldRoute_type) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, MapNotesPackage.ENTITY_SELECTOR__ROUTE_TYPE, oldRoute_type, route_type));
			}
		}
		return route_type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Transit basicGetRoute_type() {
		return route_type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRoute_type(Transit newRoute_type) {
		Transit oldRoute_type = route_type;
		route_type = newRoute_type;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.ENTITY_SELECTOR__ROUTE_TYPE, oldRoute_type, route_type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TripDescriptor getTrip() {
		if (trip != null && trip.eIsProxy()) {
			InternalEObject oldTrip = (InternalEObject)trip;
			trip = (TripDescriptor)eResolveProxy(oldTrip);
			if (trip != oldTrip) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, MapNotesPackage.ENTITY_SELECTOR__TRIP, oldTrip, trip));
			}
		}
		return trip;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TripDescriptor basicGetTrip() {
		return trip;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTrip(TripDescriptor newTrip) {
		TripDescriptor oldTrip = trip;
		trip = newTrip;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.ENTITY_SELECTOR__TRIP, oldTrip, trip));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Stop getStop_id() {
		if (stop_id != null && stop_id.eIsProxy()) {
			InternalEObject oldStop_id = (InternalEObject)stop_id;
			stop_id = (Stop)eResolveProxy(oldStop_id);
			if (stop_id != oldStop_id) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, MapNotesPackage.ENTITY_SELECTOR__STOP_ID, oldStop_id, stop_id));
			}
		}
		return stop_id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Stop basicGetStop_id() {
		return stop_id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setStop_id(Stop newStop_id) {
		Stop oldStop_id = stop_id;
		stop_id = newStop_id;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.ENTITY_SELECTOR__STOP_ID, oldStop_id, stop_id));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.ENTITY_SELECTOR__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case MapNotesPackage.ENTITY_SELECTOR__AGENCY_ID:
				if (resolve) return getAgency_id();
				return basicGetAgency_id();
			case MapNotesPackage.ENTITY_SELECTOR__ROUTE_ID:
				if (resolve) return getRoute_id();
				return basicGetRoute_id();
			case MapNotesPackage.ENTITY_SELECTOR__ROUTE_TYPE:
				if (resolve) return getRoute_type();
				return basicGetRoute_type();
			case MapNotesPackage.ENTITY_SELECTOR__TRIP:
				if (resolve) return getTrip();
				return basicGetTrip();
			case MapNotesPackage.ENTITY_SELECTOR__STOP_ID:
				if (resolve) return getStop_id();
				return basicGetStop_id();
			case MapNotesPackage.ENTITY_SELECTOR__NAME:
				return getName();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case MapNotesPackage.ENTITY_SELECTOR__AGENCY_ID:
				setAgency_id((Agency)newValue);
				return;
			case MapNotesPackage.ENTITY_SELECTOR__ROUTE_ID:
				setRoute_id((Route)newValue);
				return;
			case MapNotesPackage.ENTITY_SELECTOR__ROUTE_TYPE:
				setRoute_type((Transit)newValue);
				return;
			case MapNotesPackage.ENTITY_SELECTOR__TRIP:
				setTrip((TripDescriptor)newValue);
				return;
			case MapNotesPackage.ENTITY_SELECTOR__STOP_ID:
				setStop_id((Stop)newValue);
				return;
			case MapNotesPackage.ENTITY_SELECTOR__NAME:
				setName((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case MapNotesPackage.ENTITY_SELECTOR__AGENCY_ID:
				setAgency_id((Agency)null);
				return;
			case MapNotesPackage.ENTITY_SELECTOR__ROUTE_ID:
				setRoute_id((Route)null);
				return;
			case MapNotesPackage.ENTITY_SELECTOR__ROUTE_TYPE:
				setRoute_type((Transit)null);
				return;
			case MapNotesPackage.ENTITY_SELECTOR__TRIP:
				setTrip((TripDescriptor)null);
				return;
			case MapNotesPackage.ENTITY_SELECTOR__STOP_ID:
				setStop_id((Stop)null);
				return;
			case MapNotesPackage.ENTITY_SELECTOR__NAME:
				setName(NAME_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case MapNotesPackage.ENTITY_SELECTOR__AGENCY_ID:
				return agency_id != null;
			case MapNotesPackage.ENTITY_SELECTOR__ROUTE_ID:
				return route_id != null;
			case MapNotesPackage.ENTITY_SELECTOR__ROUTE_TYPE:
				return route_type != null;
			case MapNotesPackage.ENTITY_SELECTOR__TRIP:
				return trip != null;
			case MapNotesPackage.ENTITY_SELECTOR__STOP_ID:
				return stop_id != null;
			case MapNotesPackage.ENTITY_SELECTOR__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //EntitySelectorImpl
