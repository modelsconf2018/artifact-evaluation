/**
 */
package mapNotes.impl;

import mapNotes.MapNotesPackage;
import mapNotes.TripDescriptor;
import mapNotes.TripTimeScheduleRelationship;

import mobilityResources.Route;
import mobilityResources.Trip;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Trip Descriptor</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mapNotes.impl.TripDescriptorImpl#getTrip_id <em>Trip id</em>}</li>
 *   <li>{@link mapNotes.impl.TripDescriptorImpl#getRoute_id <em>Route id</em>}</li>
 *   <li>{@link mapNotes.impl.TripDescriptorImpl#getDirection_id <em>Direction id</em>}</li>
 *   <li>{@link mapNotes.impl.TripDescriptorImpl#getStart_time <em>Start time</em>}</li>
 *   <li>{@link mapNotes.impl.TripDescriptorImpl#getStart_date <em>Start date</em>}</li>
 *   <li>{@link mapNotes.impl.TripDescriptorImpl#getSchedule_relationship <em>Schedule relationship</em>}</li>
 * </ul>
 *
 * @generated
 */
public class TripDescriptorImpl extends MinimalEObjectImpl.Container implements TripDescriptor {
	/**
	 * The cached value of the '{@link #getTrip_id() <em>Trip id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTrip_id()
	 * @generated
	 * @ordered
	 */
	protected Trip trip_id;

	/**
	 * The cached value of the '{@link #getRoute_id() <em>Route id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRoute_id()
	 * @generated
	 * @ordered
	 */
	protected Route route_id;

	/**
	 * The cached value of the '{@link #getDirection_id() <em>Direction id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDirection_id()
	 * @generated
	 * @ordered
	 */
	protected Trip direction_id;

	/**
	 * The default value of the '{@link #getStart_time() <em>Start time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStart_time()
	 * @generated
	 * @ordered
	 */
	protected static final String START_TIME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getStart_time() <em>Start time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStart_time()
	 * @generated
	 * @ordered
	 */
	protected String start_time = START_TIME_EDEFAULT;

	/**
	 * The default value of the '{@link #getStart_date() <em>Start date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStart_date()
	 * @generated
	 * @ordered
	 */
	protected static final String START_DATE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getStart_date() <em>Start date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStart_date()
	 * @generated
	 * @ordered
	 */
	protected String start_date = START_DATE_EDEFAULT;

	/**
	 * The default value of the '{@link #getSchedule_relationship() <em>Schedule relationship</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSchedule_relationship()
	 * @generated
	 * @ordered
	 */
	protected static final TripTimeScheduleRelationship SCHEDULE_RELATIONSHIP_EDEFAULT = TripTimeScheduleRelationship.SCHEDULED;

	/**
	 * The cached value of the '{@link #getSchedule_relationship() <em>Schedule relationship</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSchedule_relationship()
	 * @generated
	 * @ordered
	 */
	protected TripTimeScheduleRelationship schedule_relationship = SCHEDULE_RELATIONSHIP_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TripDescriptorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MapNotesPackage.Literals.TRIP_DESCRIPTOR;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Trip getTrip_id() {
		if (trip_id != null && trip_id.eIsProxy()) {
			InternalEObject oldTrip_id = (InternalEObject)trip_id;
			trip_id = (Trip)eResolveProxy(oldTrip_id);
			if (trip_id != oldTrip_id) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, MapNotesPackage.TRIP_DESCRIPTOR__TRIP_ID, oldTrip_id, trip_id));
			}
		}
		return trip_id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Trip basicGetTrip_id() {
		return trip_id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTrip_id(Trip newTrip_id) {
		Trip oldTrip_id = trip_id;
		trip_id = newTrip_id;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.TRIP_DESCRIPTOR__TRIP_ID, oldTrip_id, trip_id));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Route getRoute_id() {
		if (route_id != null && route_id.eIsProxy()) {
			InternalEObject oldRoute_id = (InternalEObject)route_id;
			route_id = (Route)eResolveProxy(oldRoute_id);
			if (route_id != oldRoute_id) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, MapNotesPackage.TRIP_DESCRIPTOR__ROUTE_ID, oldRoute_id, route_id));
			}
		}
		return route_id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Route basicGetRoute_id() {
		return route_id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setRoute_id(Route newRoute_id) {
		Route oldRoute_id = route_id;
		route_id = newRoute_id;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.TRIP_DESCRIPTOR__ROUTE_ID, oldRoute_id, route_id));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Trip getDirection_id() {
		if (direction_id != null && direction_id.eIsProxy()) {
			InternalEObject oldDirection_id = (InternalEObject)direction_id;
			direction_id = (Trip)eResolveProxy(oldDirection_id);
			if (direction_id != oldDirection_id) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, MapNotesPackage.TRIP_DESCRIPTOR__DIRECTION_ID, oldDirection_id, direction_id));
			}
		}
		return direction_id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Trip basicGetDirection_id() {
		return direction_id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDirection_id(Trip newDirection_id) {
		Trip oldDirection_id = direction_id;
		direction_id = newDirection_id;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.TRIP_DESCRIPTOR__DIRECTION_ID, oldDirection_id, direction_id));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getStart_time() {
		return start_time;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setStart_time(String newStart_time) {
		String oldStart_time = start_time;
		start_time = newStart_time;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.TRIP_DESCRIPTOR__START_TIME, oldStart_time, start_time));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getStart_date() {
		return start_date;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setStart_date(String newStart_date) {
		String oldStart_date = start_date;
		start_date = newStart_date;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.TRIP_DESCRIPTOR__START_DATE, oldStart_date, start_date));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TripTimeScheduleRelationship getSchedule_relationship() {
		return schedule_relationship;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSchedule_relationship(TripTimeScheduleRelationship newSchedule_relationship) {
		TripTimeScheduleRelationship oldSchedule_relationship = schedule_relationship;
		schedule_relationship = newSchedule_relationship == null ? SCHEDULE_RELATIONSHIP_EDEFAULT : newSchedule_relationship;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.TRIP_DESCRIPTOR__SCHEDULE_RELATIONSHIP, oldSchedule_relationship, schedule_relationship));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case MapNotesPackage.TRIP_DESCRIPTOR__TRIP_ID:
				if (resolve) return getTrip_id();
				return basicGetTrip_id();
			case MapNotesPackage.TRIP_DESCRIPTOR__ROUTE_ID:
				if (resolve) return getRoute_id();
				return basicGetRoute_id();
			case MapNotesPackage.TRIP_DESCRIPTOR__DIRECTION_ID:
				if (resolve) return getDirection_id();
				return basicGetDirection_id();
			case MapNotesPackage.TRIP_DESCRIPTOR__START_TIME:
				return getStart_time();
			case MapNotesPackage.TRIP_DESCRIPTOR__START_DATE:
				return getStart_date();
			case MapNotesPackage.TRIP_DESCRIPTOR__SCHEDULE_RELATIONSHIP:
				return getSchedule_relationship();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case MapNotesPackage.TRIP_DESCRIPTOR__TRIP_ID:
				setTrip_id((Trip)newValue);
				return;
			case MapNotesPackage.TRIP_DESCRIPTOR__ROUTE_ID:
				setRoute_id((Route)newValue);
				return;
			case MapNotesPackage.TRIP_DESCRIPTOR__DIRECTION_ID:
				setDirection_id((Trip)newValue);
				return;
			case MapNotesPackage.TRIP_DESCRIPTOR__START_TIME:
				setStart_time((String)newValue);
				return;
			case MapNotesPackage.TRIP_DESCRIPTOR__START_DATE:
				setStart_date((String)newValue);
				return;
			case MapNotesPackage.TRIP_DESCRIPTOR__SCHEDULE_RELATIONSHIP:
				setSchedule_relationship((TripTimeScheduleRelationship)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case MapNotesPackage.TRIP_DESCRIPTOR__TRIP_ID:
				setTrip_id((Trip)null);
				return;
			case MapNotesPackage.TRIP_DESCRIPTOR__ROUTE_ID:
				setRoute_id((Route)null);
				return;
			case MapNotesPackage.TRIP_DESCRIPTOR__DIRECTION_ID:
				setDirection_id((Trip)null);
				return;
			case MapNotesPackage.TRIP_DESCRIPTOR__START_TIME:
				setStart_time(START_TIME_EDEFAULT);
				return;
			case MapNotesPackage.TRIP_DESCRIPTOR__START_DATE:
				setStart_date(START_DATE_EDEFAULT);
				return;
			case MapNotesPackage.TRIP_DESCRIPTOR__SCHEDULE_RELATIONSHIP:
				setSchedule_relationship(SCHEDULE_RELATIONSHIP_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case MapNotesPackage.TRIP_DESCRIPTOR__TRIP_ID:
				return trip_id != null;
			case MapNotesPackage.TRIP_DESCRIPTOR__ROUTE_ID:
				return route_id != null;
			case MapNotesPackage.TRIP_DESCRIPTOR__DIRECTION_ID:
				return direction_id != null;
			case MapNotesPackage.TRIP_DESCRIPTOR__START_TIME:
				return START_TIME_EDEFAULT == null ? start_time != null : !START_TIME_EDEFAULT.equals(start_time);
			case MapNotesPackage.TRIP_DESCRIPTOR__START_DATE:
				return START_DATE_EDEFAULT == null ? start_date != null : !START_DATE_EDEFAULT.equals(start_date);
			case MapNotesPackage.TRIP_DESCRIPTOR__SCHEDULE_RELATIONSHIP:
				return schedule_relationship != SCHEDULE_RELATIONSHIP_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (start_time: ");
		result.append(start_time);
		result.append(", start_date: ");
		result.append(start_date);
		result.append(", schedule_relationship: ");
		result.append(schedule_relationship);
		result.append(')');
		return result.toString();
	}

} //TripDescriptorImpl
