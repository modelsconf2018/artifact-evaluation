/**
 */
package mapNotes.impl;

import mapNotes.MapNotesPackage;
import mapNotes.TrafficRemark;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Traffic Remark</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mapNotes.impl.TrafficRemarkImpl#getWayId <em>Way Id</em>}</li>
 *   <li>{@link mapNotes.impl.TrafficRemarkImpl#getStartNodeId <em>Start Node Id</em>}</li>
 *   <li>{@link mapNotes.impl.TrafficRemarkImpl#getEndNodeId <em>End Node Id</em>}</li>
 *   <li>{@link mapNotes.impl.TrafficRemarkImpl#getLon <em>Lon</em>}</li>
 *   <li>{@link mapNotes.impl.TrafficRemarkImpl#getLat <em>Lat</em>}</li>
 *   <li>{@link mapNotes.impl.TrafficRemarkImpl#getWhen <em>When</em>}</li>
 *   <li>{@link mapNotes.impl.TrafficRemarkImpl#getAppliesTo <em>Applies To</em>}</li>
 *   <li>{@link mapNotes.impl.TrafficRemarkImpl#getNextPoint <em>Next Point</em>}</li>
 *   <li>{@link mapNotes.impl.TrafficRemarkImpl#getName <em>Name</em>}</li>
 *   <li>{@link mapNotes.impl.TrafficRemarkImpl#getAverageSpeed <em>Average Speed</em>}</li>
 * </ul>
 *
 * @generated
 */
public class TrafficRemarkImpl extends StatusRemarkImpl implements TrafficRemark {
	/**
	 * The default value of the '{@link #getWayId() <em>Way Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWayId()
	 * @generated
	 * @ordered
	 */
	protected static final String WAY_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getWayId() <em>Way Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWayId()
	 * @generated
	 * @ordered
	 */
	protected String wayId = WAY_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getStartNodeId() <em>Start Node Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStartNodeId()
	 * @generated
	 * @ordered
	 */
	protected static final String START_NODE_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getStartNodeId() <em>Start Node Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStartNodeId()
	 * @generated
	 * @ordered
	 */
	protected String startNodeId = START_NODE_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getEndNodeId() <em>End Node Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEndNodeId()
	 * @generated
	 * @ordered
	 */
	protected static final String END_NODE_ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getEndNodeId() <em>End Node Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEndNodeId()
	 * @generated
	 * @ordered
	 */
	protected String endNodeId = END_NODE_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getLon() <em>Lon</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLon()
	 * @generated
	 * @ordered
	 */
	protected static final String LON_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getLon() <em>Lon</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLon()
	 * @generated
	 * @ordered
	 */
	protected String lon = LON_EDEFAULT;

	/**
	 * The default value of the '{@link #getLat() <em>Lat</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLat()
	 * @generated
	 * @ordered
	 */
	protected static final String LAT_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getLat() <em>Lat</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLat()
	 * @generated
	 * @ordered
	 */
	protected String lat = LAT_EDEFAULT;

	/**
	 * The default value of the '{@link #getWhen() <em>When</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWhen()
	 * @generated
	 * @ordered
	 */
	protected static final String WHEN_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getWhen() <em>When</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWhen()
	 * @generated
	 * @ordered
	 */
	protected String when = WHEN_EDEFAULT;

	/**
	 * The default value of the '{@link #getAppliesTo() <em>Applies To</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAppliesTo()
	 * @generated
	 * @ordered
	 */
	protected static final String APPLIES_TO_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getAppliesTo() <em>Applies To</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAppliesTo()
	 * @generated
	 * @ordered
	 */
	protected String appliesTo = APPLIES_TO_EDEFAULT;

	/**
	 * The cached value of the '{@link #getNextPoint() <em>Next Point</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNextPoint()
	 * @generated
	 * @ordered
	 */
	protected TrafficRemark nextPoint;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getAverageSpeed() <em>Average Speed</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAverageSpeed()
	 * @generated
	 * @ordered
	 */
	protected static final String AVERAGE_SPEED_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getAverageSpeed() <em>Average Speed</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAverageSpeed()
	 * @generated
	 * @ordered
	 */
	protected String averageSpeed = AVERAGE_SPEED_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TrafficRemarkImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MapNotesPackage.Literals.TRAFFIC_REMARK;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getWayId() {
		return wayId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setWayId(String newWayId) {
		String oldWayId = wayId;
		wayId = newWayId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.TRAFFIC_REMARK__WAY_ID, oldWayId, wayId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getStartNodeId() {
		return startNodeId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setStartNodeId(String newStartNodeId) {
		String oldStartNodeId = startNodeId;
		startNodeId = newStartNodeId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.TRAFFIC_REMARK__START_NODE_ID, oldStartNodeId, startNodeId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getEndNodeId() {
		return endNodeId;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setEndNodeId(String newEndNodeId) {
		String oldEndNodeId = endNodeId;
		endNodeId = newEndNodeId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.TRAFFIC_REMARK__END_NODE_ID, oldEndNodeId, endNodeId));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLon() {
		return lon;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLon(String newLon) {
		String oldLon = lon;
		lon = newLon;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.TRAFFIC_REMARK__LON, oldLon, lon));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLat() {
		return lat;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLat(String newLat) {
		String oldLat = lat;
		lat = newLat;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.TRAFFIC_REMARK__LAT, oldLat, lat));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getWhen() {
		return when;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setWhen(String newWhen) {
		String oldWhen = when;
		when = newWhen;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.TRAFFIC_REMARK__WHEN, oldWhen, when));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getAppliesTo() {
		return appliesTo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAppliesTo(String newAppliesTo) {
		String oldAppliesTo = appliesTo;
		appliesTo = newAppliesTo;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.TRAFFIC_REMARK__APPLIES_TO, oldAppliesTo, appliesTo));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TrafficRemark getNextPoint() {
		if (nextPoint != null && nextPoint.eIsProxy()) {
			InternalEObject oldNextPoint = (InternalEObject)nextPoint;
			nextPoint = (TrafficRemark)eResolveProxy(oldNextPoint);
			if (nextPoint != oldNextPoint) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, MapNotesPackage.TRAFFIC_REMARK__NEXT_POINT, oldNextPoint, nextPoint));
			}
		}
		return nextPoint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TrafficRemark basicGetNextPoint() {
		return nextPoint;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNextPoint(TrafficRemark newNextPoint) {
		TrafficRemark oldNextPoint = nextPoint;
		nextPoint = newNextPoint;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.TRAFFIC_REMARK__NEXT_POINT, oldNextPoint, nextPoint));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.TRAFFIC_REMARK__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getAverageSpeed() {
		return averageSpeed;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAverageSpeed(String newAverageSpeed) {
		String oldAverageSpeed = averageSpeed;
		averageSpeed = newAverageSpeed;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.TRAFFIC_REMARK__AVERAGE_SPEED, oldAverageSpeed, averageSpeed));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case MapNotesPackage.TRAFFIC_REMARK__WAY_ID:
				return getWayId();
			case MapNotesPackage.TRAFFIC_REMARK__START_NODE_ID:
				return getStartNodeId();
			case MapNotesPackage.TRAFFIC_REMARK__END_NODE_ID:
				return getEndNodeId();
			case MapNotesPackage.TRAFFIC_REMARK__LON:
				return getLon();
			case MapNotesPackage.TRAFFIC_REMARK__LAT:
				return getLat();
			case MapNotesPackage.TRAFFIC_REMARK__WHEN:
				return getWhen();
			case MapNotesPackage.TRAFFIC_REMARK__APPLIES_TO:
				return getAppliesTo();
			case MapNotesPackage.TRAFFIC_REMARK__NEXT_POINT:
				if (resolve) return getNextPoint();
				return basicGetNextPoint();
			case MapNotesPackage.TRAFFIC_REMARK__NAME:
				return getName();
			case MapNotesPackage.TRAFFIC_REMARK__AVERAGE_SPEED:
				return getAverageSpeed();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case MapNotesPackage.TRAFFIC_REMARK__WAY_ID:
				setWayId((String)newValue);
				return;
			case MapNotesPackage.TRAFFIC_REMARK__START_NODE_ID:
				setStartNodeId((String)newValue);
				return;
			case MapNotesPackage.TRAFFIC_REMARK__END_NODE_ID:
				setEndNodeId((String)newValue);
				return;
			case MapNotesPackage.TRAFFIC_REMARK__LON:
				setLon((String)newValue);
				return;
			case MapNotesPackage.TRAFFIC_REMARK__LAT:
				setLat((String)newValue);
				return;
			case MapNotesPackage.TRAFFIC_REMARK__WHEN:
				setWhen((String)newValue);
				return;
			case MapNotesPackage.TRAFFIC_REMARK__APPLIES_TO:
				setAppliesTo((String)newValue);
				return;
			case MapNotesPackage.TRAFFIC_REMARK__NEXT_POINT:
				setNextPoint((TrafficRemark)newValue);
				return;
			case MapNotesPackage.TRAFFIC_REMARK__NAME:
				setName((String)newValue);
				return;
			case MapNotesPackage.TRAFFIC_REMARK__AVERAGE_SPEED:
				setAverageSpeed((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case MapNotesPackage.TRAFFIC_REMARK__WAY_ID:
				setWayId(WAY_ID_EDEFAULT);
				return;
			case MapNotesPackage.TRAFFIC_REMARK__START_NODE_ID:
				setStartNodeId(START_NODE_ID_EDEFAULT);
				return;
			case MapNotesPackage.TRAFFIC_REMARK__END_NODE_ID:
				setEndNodeId(END_NODE_ID_EDEFAULT);
				return;
			case MapNotesPackage.TRAFFIC_REMARK__LON:
				setLon(LON_EDEFAULT);
				return;
			case MapNotesPackage.TRAFFIC_REMARK__LAT:
				setLat(LAT_EDEFAULT);
				return;
			case MapNotesPackage.TRAFFIC_REMARK__WHEN:
				setWhen(WHEN_EDEFAULT);
				return;
			case MapNotesPackage.TRAFFIC_REMARK__APPLIES_TO:
				setAppliesTo(APPLIES_TO_EDEFAULT);
				return;
			case MapNotesPackage.TRAFFIC_REMARK__NEXT_POINT:
				setNextPoint((TrafficRemark)null);
				return;
			case MapNotesPackage.TRAFFIC_REMARK__NAME:
				setName(NAME_EDEFAULT);
				return;
			case MapNotesPackage.TRAFFIC_REMARK__AVERAGE_SPEED:
				setAverageSpeed(AVERAGE_SPEED_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case MapNotesPackage.TRAFFIC_REMARK__WAY_ID:
				return WAY_ID_EDEFAULT == null ? wayId != null : !WAY_ID_EDEFAULT.equals(wayId);
			case MapNotesPackage.TRAFFIC_REMARK__START_NODE_ID:
				return START_NODE_ID_EDEFAULT == null ? startNodeId != null : !START_NODE_ID_EDEFAULT.equals(startNodeId);
			case MapNotesPackage.TRAFFIC_REMARK__END_NODE_ID:
				return END_NODE_ID_EDEFAULT == null ? endNodeId != null : !END_NODE_ID_EDEFAULT.equals(endNodeId);
			case MapNotesPackage.TRAFFIC_REMARK__LON:
				return LON_EDEFAULT == null ? lon != null : !LON_EDEFAULT.equals(lon);
			case MapNotesPackage.TRAFFIC_REMARK__LAT:
				return LAT_EDEFAULT == null ? lat != null : !LAT_EDEFAULT.equals(lat);
			case MapNotesPackage.TRAFFIC_REMARK__WHEN:
				return WHEN_EDEFAULT == null ? when != null : !WHEN_EDEFAULT.equals(when);
			case MapNotesPackage.TRAFFIC_REMARK__APPLIES_TO:
				return APPLIES_TO_EDEFAULT == null ? appliesTo != null : !APPLIES_TO_EDEFAULT.equals(appliesTo);
			case MapNotesPackage.TRAFFIC_REMARK__NEXT_POINT:
				return nextPoint != null;
			case MapNotesPackage.TRAFFIC_REMARK__NAME:
				return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
			case MapNotesPackage.TRAFFIC_REMARK__AVERAGE_SPEED:
				return AVERAGE_SPEED_EDEFAULT == null ? averageSpeed != null : !AVERAGE_SPEED_EDEFAULT.equals(averageSpeed);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (wayId: ");
		result.append(wayId);
		result.append(", startNodeId: ");
		result.append(startNodeId);
		result.append(", endNodeId: ");
		result.append(endNodeId);
		result.append(", lon: ");
		result.append(lon);
		result.append(", lat: ");
		result.append(lat);
		result.append(", when: ");
		result.append(when);
		result.append(", appliesTo: ");
		result.append(appliesTo);
		result.append(", name: ");
		result.append(name);
		result.append(", averageSpeed: ");
		result.append(averageSpeed);
		result.append(')');
		return result.toString();
	}

} //TrafficRemarkImpl
