/**
 */
package mapNotes.impl;

import mapNotes.Alert;
import mapNotes.BikeSharingRemark;
import mapNotes.Cause;
import mapNotes.CongestionLevel;
import mapNotes.Effect;
import mapNotes.EntitySelector;
import mapNotes.MapNotes;
import mapNotes.MapNotesFactory;
import mapNotes.MapNotesPackage;
import mapNotes.OccupancyStatus;
import mapNotes.ParkingRemark;
import mapNotes.Position;
import mapNotes.StatusRemark;
import mapNotes.StopTimeEvent;
import mapNotes.StopTimeScheduleRelationship;
import mapNotes.StopTimeUpdate;
import mapNotes.TimeRange;
import mapNotes.TrafficRemark;
import mapNotes.TransitRemark;
import mapNotes.TripDescriptor;
import mapNotes.TripTimeScheduleRelationship;
import mapNotes.TripUpdate;
import mapNotes.Vehicle;
import mapNotes.VehicleDescriptor;
import mapNotes.VehicleStopStatus;

import mobilityResources.MobilityResourcesPackage;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import org.eclipse.emf.ecore.xml.type.XMLTypePackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class MapNotesPackageImpl extends EPackageImpl implements MapNotesPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass mapNotesEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass trafficRemarkEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass statusRemarkEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass bikeSharingRemarkEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass parkingRemarkEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass transitRemarkEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass tripUpdateEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass vehicleEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass alertEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass tripDescriptorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass vehicleDescriptorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass stopTimeUpdateEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass stopTimeEventEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass timeRangeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass entitySelectorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass positionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum stopTimeScheduleRelationshipEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum vehicleStopStatusEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum congestionLevelEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum occupancyStatusEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum causeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum effectEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum tripTimeScheduleRelationshipEEnum = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see mapNotes.MapNotesPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private MapNotesPackageImpl() {
		super(eNS_URI, MapNotesFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 * 
	 * <p>This method is used to initialize {@link MapNotesPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static MapNotesPackage init() {
		if (isInited) return (MapNotesPackage)EPackage.Registry.INSTANCE.getEPackage(MapNotesPackage.eNS_URI);

		// Obtain or create and register package
		MapNotesPackageImpl theMapNotesPackage = (MapNotesPackageImpl)(EPackage.Registry.INSTANCE.get(eNS_URI) instanceof MapNotesPackageImpl ? EPackage.Registry.INSTANCE.get(eNS_URI) : new MapNotesPackageImpl());

		isInited = true;

		// Initialize simple dependencies
		MobilityResourcesPackage.eINSTANCE.eClass();
		XMLTypePackage.eINSTANCE.eClass();

		// Create package meta-data objects
		theMapNotesPackage.createPackageContents();

		// Initialize created meta-data
		theMapNotesPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theMapNotesPackage.freeze();

  
		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(MapNotesPackage.eNS_URI, theMapNotesPackage);
		return theMapNotesPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getMapNotes() {
		return mapNotesEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMapNotes_CityName() {
		return (EAttribute)mapNotesEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getMapNotes_LastUpdate() {
		return (EAttribute)mapNotesEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getMapNotes_StatusRemarks() {
		return (EReference)mapNotesEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTrafficRemark() {
		return trafficRemarkEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTrafficRemark_WayId() {
		return (EAttribute)trafficRemarkEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTrafficRemark_StartNodeId() {
		return (EAttribute)trafficRemarkEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTrafficRemark_EndNodeId() {
		return (EAttribute)trafficRemarkEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTrafficRemark_Lon() {
		return (EAttribute)trafficRemarkEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTrafficRemark_Lat() {
		return (EAttribute)trafficRemarkEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTrafficRemark_When() {
		return (EAttribute)trafficRemarkEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTrafficRemark_AppliesTo() {
		return (EAttribute)trafficRemarkEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTrafficRemark_NextPoint() {
		return (EReference)trafficRemarkEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTrafficRemark_Name() {
		return (EAttribute)trafficRemarkEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTrafficRemark_AverageSpeed() {
		return (EAttribute)trafficRemarkEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getStatusRemark() {
		return statusRemarkEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getStatusRemark_Timestamp() {
		return (EAttribute)statusRemarkEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getBikeSharingRemark() {
		return bikeSharingRemarkEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getBikeSharingRemark_Bikesharingstatus() {
		return (EReference)bikeSharingRemarkEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getParkingRemark() {
		return parkingRemarkEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getParkingRemark_Parkingstatus() {
		return (EReference)parkingRemarkEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTransitRemark() {
		return transitRemarkEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTransitRemark_Id() {
		return (EAttribute)transitRemarkEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTransitRemark_IsDeleted() {
		return (EAttribute)transitRemarkEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTransitRemark_Tripupdates() {
		return (EReference)transitRemarkEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTransitRemark_Vehicles() {
		return (EReference)transitRemarkEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTransitRemark_Alerts() {
		return (EReference)transitRemarkEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTripUpdate() {
		return tripUpdateEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTripUpdate_Timestamp() {
		return (EAttribute)tripUpdateEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTripUpdate_Delay() {
		return (EAttribute)tripUpdateEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTripUpdate_Tripdescriptor() {
		return (EReference)tripUpdateEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTripUpdate_Vehicledescriptor() {
		return (EReference)tripUpdateEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTripUpdate_Stop_time_updates() {
		return (EReference)tripUpdateEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getVehicle() {
		return vehicleEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getVehicle_Vehicledescriptor() {
		return (EReference)vehicleEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getVehicle_Tripdescriptor() {
		return (EReference)vehicleEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getVehicle_Current_stop_sequence() {
		return (EReference)vehicleEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getVehicle_Stop_id() {
		return (EReference)vehicleEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVehicle_Current_status() {
		return (EAttribute)vehicleEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVehicle_Timestamp() {
		return (EAttribute)vehicleEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVehicle_Congestion_level() {
		return (EAttribute)vehicleEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVehicle_OccupancyStatus() {
		return (EAttribute)vehicleEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getVehicle_Position() {
		return (EReference)vehicleEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getAlert() {
		return alertEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAlert_Active_period() {
		return (EReference)alertEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getAlert_Informed_entity() {
		return (EReference)alertEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAlert_Cause() {
		return (EAttribute)alertEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAlert_Effect() {
		return (EAttribute)alertEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAlert_Url() {
		return (EAttribute)alertEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAlert_Header_text() {
		return (EAttribute)alertEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getAlert_Description_text() {
		return (EAttribute)alertEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTripDescriptor() {
		return tripDescriptorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTripDescriptor_Trip_id() {
		return (EReference)tripDescriptorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTripDescriptor_Route_id() {
		return (EReference)tripDescriptorEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTripDescriptor_Direction_id() {
		return (EReference)tripDescriptorEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTripDescriptor_Start_time() {
		return (EAttribute)tripDescriptorEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTripDescriptor_Start_date() {
		return (EAttribute)tripDescriptorEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTripDescriptor_Schedule_relationship() {
		return (EAttribute)tripDescriptorEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getVehicleDescriptor() {
		return vehicleDescriptorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVehicleDescriptor_Id() {
		return (EAttribute)vehicleDescriptorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVehicleDescriptor_Label() {
		return (EAttribute)vehicleDescriptorEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getVehicleDescriptor_License_plate() {
		return (EAttribute)vehicleDescriptorEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getStopTimeUpdate() {
		return stopTimeUpdateEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getStopTimeUpdate_Stop_sequence() {
		return (EReference)stopTimeUpdateEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getStopTimeUpdate_Stop_id() {
		return (EReference)stopTimeUpdateEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getStopTimeUpdate_Arrival() {
		return (EReference)stopTimeUpdateEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getStopTimeUpdate_Departure() {
		return (EReference)stopTimeUpdateEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getStopTimeUpdate_Schedule_relationship() {
		return (EAttribute)stopTimeUpdateEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getStopTimeUpdate_Stoptimeevent() {
		return (EReference)stopTimeUpdateEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getStopTimeEvent() {
		return stopTimeEventEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getStopTimeEvent_Delay() {
		return (EAttribute)stopTimeEventEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getStopTimeEvent_Time() {
		return (EAttribute)stopTimeEventEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getStopTimeEvent_Uncertainty() {
		return (EAttribute)stopTimeEventEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTimeRange() {
		return timeRangeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTimeRange_Start() {
		return (EAttribute)timeRangeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTimeRange_End() {
		return (EAttribute)timeRangeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getEntitySelector() {
		return entitySelectorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getEntitySelector_Agency_id() {
		return (EReference)entitySelectorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getEntitySelector_Route_id() {
		return (EReference)entitySelectorEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getEntitySelector_Route_type() {
		return (EReference)entitySelectorEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getEntitySelector_Trip() {
		return (EReference)entitySelectorEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getEntitySelector_Stop_id() {
		return (EReference)entitySelectorEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getEntitySelector_Name() {
		return (EAttribute)entitySelectorEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getPosition() {
		return positionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPosition_Latitude() {
		return (EAttribute)positionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPosition_Longitude() {
		return (EAttribute)positionEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPosition_Bearing() {
		return (EAttribute)positionEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPosition_Odometer() {
		return (EAttribute)positionEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getPosition_Speed() {
		return (EAttribute)positionEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getStopTimeScheduleRelationship() {
		return stopTimeScheduleRelationshipEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getVehicleStopStatus() {
		return vehicleStopStatusEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getCongestionLevel() {
		return congestionLevelEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getOccupancyStatus() {
		return occupancyStatusEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getCause() {
		return causeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getEffect() {
		return effectEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EEnum getTripTimeScheduleRelationship() {
		return tripTimeScheduleRelationshipEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MapNotesFactory getMapNotesFactory() {
		return (MapNotesFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		mapNotesEClass = createEClass(MAP_NOTES);
		createEAttribute(mapNotesEClass, MAP_NOTES__CITY_NAME);
		createEAttribute(mapNotesEClass, MAP_NOTES__LAST_UPDATE);
		createEReference(mapNotesEClass, MAP_NOTES__STATUS_REMARKS);

		trafficRemarkEClass = createEClass(TRAFFIC_REMARK);
		createEAttribute(trafficRemarkEClass, TRAFFIC_REMARK__WAY_ID);
		createEAttribute(trafficRemarkEClass, TRAFFIC_REMARK__START_NODE_ID);
		createEAttribute(trafficRemarkEClass, TRAFFIC_REMARK__END_NODE_ID);
		createEAttribute(trafficRemarkEClass, TRAFFIC_REMARK__LON);
		createEAttribute(trafficRemarkEClass, TRAFFIC_REMARK__LAT);
		createEAttribute(trafficRemarkEClass, TRAFFIC_REMARK__WHEN);
		createEAttribute(trafficRemarkEClass, TRAFFIC_REMARK__APPLIES_TO);
		createEReference(trafficRemarkEClass, TRAFFIC_REMARK__NEXT_POINT);
		createEAttribute(trafficRemarkEClass, TRAFFIC_REMARK__NAME);
		createEAttribute(trafficRemarkEClass, TRAFFIC_REMARK__AVERAGE_SPEED);

		statusRemarkEClass = createEClass(STATUS_REMARK);
		createEAttribute(statusRemarkEClass, STATUS_REMARK__TIMESTAMP);

		bikeSharingRemarkEClass = createEClass(BIKE_SHARING_REMARK);
		createEReference(bikeSharingRemarkEClass, BIKE_SHARING_REMARK__BIKESHARINGSTATUS);

		parkingRemarkEClass = createEClass(PARKING_REMARK);
		createEReference(parkingRemarkEClass, PARKING_REMARK__PARKINGSTATUS);

		transitRemarkEClass = createEClass(TRANSIT_REMARK);
		createEAttribute(transitRemarkEClass, TRANSIT_REMARK__ID);
		createEAttribute(transitRemarkEClass, TRANSIT_REMARK__IS_DELETED);
		createEReference(transitRemarkEClass, TRANSIT_REMARK__TRIPUPDATES);
		createEReference(transitRemarkEClass, TRANSIT_REMARK__VEHICLES);
		createEReference(transitRemarkEClass, TRANSIT_REMARK__ALERTS);

		tripUpdateEClass = createEClass(TRIP_UPDATE);
		createEAttribute(tripUpdateEClass, TRIP_UPDATE__TIMESTAMP);
		createEAttribute(tripUpdateEClass, TRIP_UPDATE__DELAY);
		createEReference(tripUpdateEClass, TRIP_UPDATE__TRIPDESCRIPTOR);
		createEReference(tripUpdateEClass, TRIP_UPDATE__VEHICLEDESCRIPTOR);
		createEReference(tripUpdateEClass, TRIP_UPDATE__STOP_TIME_UPDATES);

		vehicleEClass = createEClass(VEHICLE);
		createEReference(vehicleEClass, VEHICLE__VEHICLEDESCRIPTOR);
		createEReference(vehicleEClass, VEHICLE__TRIPDESCRIPTOR);
		createEReference(vehicleEClass, VEHICLE__CURRENT_STOP_SEQUENCE);
		createEReference(vehicleEClass, VEHICLE__STOP_ID);
		createEAttribute(vehicleEClass, VEHICLE__CURRENT_STATUS);
		createEAttribute(vehicleEClass, VEHICLE__TIMESTAMP);
		createEAttribute(vehicleEClass, VEHICLE__CONGESTION_LEVEL);
		createEAttribute(vehicleEClass, VEHICLE__OCCUPANCY_STATUS);
		createEReference(vehicleEClass, VEHICLE__POSITION);

		alertEClass = createEClass(ALERT);
		createEReference(alertEClass, ALERT__ACTIVE_PERIOD);
		createEReference(alertEClass, ALERT__INFORMED_ENTITY);
		createEAttribute(alertEClass, ALERT__CAUSE);
		createEAttribute(alertEClass, ALERT__EFFECT);
		createEAttribute(alertEClass, ALERT__URL);
		createEAttribute(alertEClass, ALERT__HEADER_TEXT);
		createEAttribute(alertEClass, ALERT__DESCRIPTION_TEXT);

		tripDescriptorEClass = createEClass(TRIP_DESCRIPTOR);
		createEReference(tripDescriptorEClass, TRIP_DESCRIPTOR__TRIP_ID);
		createEReference(tripDescriptorEClass, TRIP_DESCRIPTOR__ROUTE_ID);
		createEReference(tripDescriptorEClass, TRIP_DESCRIPTOR__DIRECTION_ID);
		createEAttribute(tripDescriptorEClass, TRIP_DESCRIPTOR__START_TIME);
		createEAttribute(tripDescriptorEClass, TRIP_DESCRIPTOR__START_DATE);
		createEAttribute(tripDescriptorEClass, TRIP_DESCRIPTOR__SCHEDULE_RELATIONSHIP);

		vehicleDescriptorEClass = createEClass(VEHICLE_DESCRIPTOR);
		createEAttribute(vehicleDescriptorEClass, VEHICLE_DESCRIPTOR__ID);
		createEAttribute(vehicleDescriptorEClass, VEHICLE_DESCRIPTOR__LABEL);
		createEAttribute(vehicleDescriptorEClass, VEHICLE_DESCRIPTOR__LICENSE_PLATE);

		stopTimeUpdateEClass = createEClass(STOP_TIME_UPDATE);
		createEReference(stopTimeUpdateEClass, STOP_TIME_UPDATE__STOP_SEQUENCE);
		createEReference(stopTimeUpdateEClass, STOP_TIME_UPDATE__STOP_ID);
		createEReference(stopTimeUpdateEClass, STOP_TIME_UPDATE__ARRIVAL);
		createEReference(stopTimeUpdateEClass, STOP_TIME_UPDATE__DEPARTURE);
		createEAttribute(stopTimeUpdateEClass, STOP_TIME_UPDATE__SCHEDULE_RELATIONSHIP);
		createEReference(stopTimeUpdateEClass, STOP_TIME_UPDATE__STOPTIMEEVENT);

		stopTimeEventEClass = createEClass(STOP_TIME_EVENT);
		createEAttribute(stopTimeEventEClass, STOP_TIME_EVENT__DELAY);
		createEAttribute(stopTimeEventEClass, STOP_TIME_EVENT__TIME);
		createEAttribute(stopTimeEventEClass, STOP_TIME_EVENT__UNCERTAINTY);

		timeRangeEClass = createEClass(TIME_RANGE);
		createEAttribute(timeRangeEClass, TIME_RANGE__START);
		createEAttribute(timeRangeEClass, TIME_RANGE__END);

		entitySelectorEClass = createEClass(ENTITY_SELECTOR);
		createEReference(entitySelectorEClass, ENTITY_SELECTOR__AGENCY_ID);
		createEReference(entitySelectorEClass, ENTITY_SELECTOR__ROUTE_ID);
		createEReference(entitySelectorEClass, ENTITY_SELECTOR__ROUTE_TYPE);
		createEReference(entitySelectorEClass, ENTITY_SELECTOR__TRIP);
		createEReference(entitySelectorEClass, ENTITY_SELECTOR__STOP_ID);
		createEAttribute(entitySelectorEClass, ENTITY_SELECTOR__NAME);

		positionEClass = createEClass(POSITION);
		createEAttribute(positionEClass, POSITION__LATITUDE);
		createEAttribute(positionEClass, POSITION__LONGITUDE);
		createEAttribute(positionEClass, POSITION__BEARING);
		createEAttribute(positionEClass, POSITION__ODOMETER);
		createEAttribute(positionEClass, POSITION__SPEED);

		// Create enums
		stopTimeScheduleRelationshipEEnum = createEEnum(STOP_TIME_SCHEDULE_RELATIONSHIP);
		vehicleStopStatusEEnum = createEEnum(VEHICLE_STOP_STATUS);
		congestionLevelEEnum = createEEnum(CONGESTION_LEVEL);
		occupancyStatusEEnum = createEEnum(OCCUPANCY_STATUS);
		causeEEnum = createEEnum(CAUSE);
		effectEEnum = createEEnum(EFFECT);
		tripTimeScheduleRelationshipEEnum = createEEnum(TRIP_TIME_SCHEDULE_RELATIONSHIP);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Obtain other dependent packages
		XMLTypePackage theXMLTypePackage = (XMLTypePackage)EPackage.Registry.INSTANCE.getEPackage(XMLTypePackage.eNS_URI);
		MobilityResourcesPackage theMobilityResourcesPackage = (MobilityResourcesPackage)EPackage.Registry.INSTANCE.getEPackage(MobilityResourcesPackage.eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		trafficRemarkEClass.getESuperTypes().add(this.getStatusRemark());
		bikeSharingRemarkEClass.getESuperTypes().add(this.getStatusRemark());
		parkingRemarkEClass.getESuperTypes().add(this.getStatusRemark());
		transitRemarkEClass.getESuperTypes().add(this.getStatusRemark());

		// Initialize classes, features, and operations; add parameters
		initEClass(mapNotesEClass, MapNotes.class, "MapNotes", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getMapNotes_CityName(), ecorePackage.getEString(), "cityName", null, 0, 1, MapNotes.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getMapNotes_LastUpdate(), ecorePackage.getEDate(), "lastUpdate", null, 0, 1, MapNotes.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getMapNotes_StatusRemarks(), this.getStatusRemark(), null, "statusRemarks", null, 0, -1, MapNotes.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(trafficRemarkEClass, TrafficRemark.class, "TrafficRemark", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getTrafficRemark_WayId(), ecorePackage.getEString(), "wayId", null, 0, 1, TrafficRemark.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTrafficRemark_StartNodeId(), ecorePackage.getEString(), "startNodeId", null, 0, 1, TrafficRemark.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTrafficRemark_EndNodeId(), ecorePackage.getEString(), "endNodeId", null, 0, 1, TrafficRemark.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTrafficRemark_Lon(), ecorePackage.getEString(), "lon", null, 0, 1, TrafficRemark.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTrafficRemark_Lat(), ecorePackage.getEString(), "lat", null, 0, 1, TrafficRemark.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTrafficRemark_When(), ecorePackage.getEString(), "when", null, 0, 1, TrafficRemark.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTrafficRemark_AppliesTo(), ecorePackage.getEString(), "appliesTo", null, 0, 1, TrafficRemark.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTrafficRemark_NextPoint(), this.getTrafficRemark(), null, "nextPoint", null, 0, 1, TrafficRemark.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTrafficRemark_Name(), ecorePackage.getEString(), "name", null, 0, 1, TrafficRemark.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTrafficRemark_AverageSpeed(), ecorePackage.getEString(), "averageSpeed", null, 0, 1, TrafficRemark.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(statusRemarkEClass, StatusRemark.class, "StatusRemark", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getStatusRemark_Timestamp(), theXMLTypePackage.getUnsignedLong(), "timestamp", null, 0, 1, StatusRemark.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(bikeSharingRemarkEClass, BikeSharingRemark.class, "BikeSharingRemark", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getBikeSharingRemark_Bikesharingstatus(), theMobilityResourcesPackage.getBikeSharing(), null, "bikesharingstatus", null, 0, -1, BikeSharingRemark.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(parkingRemarkEClass, ParkingRemark.class, "ParkingRemark", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getParkingRemark_Parkingstatus(), theMobilityResourcesPackage.getParking(), null, "parkingstatus", null, 0, -1, ParkingRemark.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(transitRemarkEClass, TransitRemark.class, "TransitRemark", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getTransitRemark_Id(), ecorePackage.getEString(), "id", null, 0, 1, TransitRemark.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTransitRemark_IsDeleted(), ecorePackage.getEBoolean(), "isDeleted", null, 0, 1, TransitRemark.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTransitRemark_Tripupdates(), this.getTripUpdate(), null, "tripupdates", null, 0, -1, TransitRemark.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTransitRemark_Vehicles(), this.getVehicle(), null, "vehicles", null, 0, -1, TransitRemark.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTransitRemark_Alerts(), this.getAlert(), null, "alerts", null, 0, -1, TransitRemark.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(tripUpdateEClass, TripUpdate.class, "TripUpdate", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getTripUpdate_Timestamp(), theXMLTypePackage.getUnsignedLong(), "timestamp", null, 0, 1, TripUpdate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTripUpdate_Delay(), ecorePackage.getEInt(), "delay", null, 0, 1, TripUpdate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTripUpdate_Tripdescriptor(), this.getTripDescriptor(), null, "tripdescriptor", null, 0, 1, TripUpdate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTripUpdate_Vehicledescriptor(), this.getVehicleDescriptor(), null, "vehicledescriptor", null, 0, 1, TripUpdate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTripUpdate_Stop_time_updates(), this.getStopTimeUpdate(), null, "stop_time_updates", null, 0, -1, TripUpdate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(vehicleEClass, Vehicle.class, "Vehicle", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getVehicle_Vehicledescriptor(), this.getVehicleDescriptor(), null, "vehicledescriptor", null, 0, 1, Vehicle.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getVehicle_Tripdescriptor(), this.getTripDescriptor(), null, "tripdescriptor", null, 0, 1, Vehicle.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getVehicle_Current_stop_sequence(), theMobilityResourcesPackage.getStop_time(), null, "current_stop_sequence", null, 0, 1, Vehicle.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getVehicle_Stop_id(), theMobilityResourcesPackage.getStop(), null, "stop_id", null, 0, 1, Vehicle.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getVehicle_Current_status(), this.getVehicleStopStatus(), "current_status", null, 0, 1, Vehicle.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getVehicle_Timestamp(), theXMLTypePackage.getUnsignedLong(), "timestamp", null, 0, 1, Vehicle.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getVehicle_Congestion_level(), this.getCongestionLevel(), "congestion_level", null, 0, 1, Vehicle.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getVehicle_OccupancyStatus(), this.getOccupancyStatus(), "occupancyStatus", null, 0, 1, Vehicle.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getVehicle_Position(), this.getPosition(), null, "position", null, 0, 1, Vehicle.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(alertEClass, Alert.class, "Alert", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getAlert_Active_period(), this.getTimeRange(), null, "active_period", null, 0, -1, Alert.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAlert_Informed_entity(), this.getEntitySelector(), null, "informed_entity", null, 0, -1, Alert.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAlert_Cause(), this.getCause(), "cause", null, 0, 1, Alert.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAlert_Effect(), this.getEffect(), "effect", null, 0, 1, Alert.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAlert_Url(), ecorePackage.getEString(), "url", null, 0, 1, Alert.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAlert_Header_text(), ecorePackage.getEString(), "header_text", null, 0, 1, Alert.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getAlert_Description_text(), ecorePackage.getEString(), "description_text", null, 0, 1, Alert.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(tripDescriptorEClass, TripDescriptor.class, "TripDescriptor", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getTripDescriptor_Trip_id(), theMobilityResourcesPackage.getTrip(), null, "trip_id", null, 0, 1, TripDescriptor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTripDescriptor_Route_id(), theMobilityResourcesPackage.getRoute(), null, "route_id", null, 0, 1, TripDescriptor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTripDescriptor_Direction_id(), theMobilityResourcesPackage.getTrip(), null, "direction_id", null, 0, 1, TripDescriptor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTripDescriptor_Start_time(), ecorePackage.getEString(), "start_time", null, 0, 1, TripDescriptor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTripDescriptor_Start_date(), ecorePackage.getEString(), "start_date", null, 0, 1, TripDescriptor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTripDescriptor_Schedule_relationship(), this.getTripTimeScheduleRelationship(), "schedule_relationship", null, 0, 1, TripDescriptor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(vehicleDescriptorEClass, VehicleDescriptor.class, "VehicleDescriptor", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getVehicleDescriptor_Id(), ecorePackage.getEString(), "id", null, 0, 1, VehicleDescriptor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getVehicleDescriptor_Label(), ecorePackage.getEString(), "label", null, 0, 1, VehicleDescriptor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getVehicleDescriptor_License_plate(), ecorePackage.getEString(), "license_plate", null, 0, 1, VehicleDescriptor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(stopTimeUpdateEClass, StopTimeUpdate.class, "StopTimeUpdate", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getStopTimeUpdate_Stop_sequence(), theMobilityResourcesPackage.getStop_time(), null, "stop_sequence", null, 0, 1, StopTimeUpdate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getStopTimeUpdate_Stop_id(), theMobilityResourcesPackage.getStop(), null, "stop_id", null, 0, 1, StopTimeUpdate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getStopTimeUpdate_Arrival(), this.getStopTimeEvent(), null, "arrival", null, 0, 1, StopTimeUpdate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getStopTimeUpdate_Departure(), this.getStopTimeEvent(), null, "departure", null, 0, 1, StopTimeUpdate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getStopTimeUpdate_Schedule_relationship(), this.getStopTimeScheduleRelationship(), "schedule_relationship", null, 0, 1, StopTimeUpdate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getStopTimeUpdate_Stoptimeevent(), this.getStopTimeEvent(), null, "stoptimeevent", null, 0, -1, StopTimeUpdate.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(stopTimeEventEClass, StopTimeEvent.class, "StopTimeEvent", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getStopTimeEvent_Delay(), theXMLTypePackage.getUnsignedLong(), "delay", null, 0, 1, StopTimeEvent.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getStopTimeEvent_Time(), theXMLTypePackage.getUnsignedLong(), "time", null, 0, 1, StopTimeEvent.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getStopTimeEvent_Uncertainty(), theXMLTypePackage.getUnsignedLong(), "uncertainty", null, 0, 1, StopTimeEvent.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(timeRangeEClass, TimeRange.class, "TimeRange", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getTimeRange_Start(), theXMLTypePackage.getUnsignedLong(), "start", null, 0, 1, TimeRange.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTimeRange_End(), theXMLTypePackage.getUnsignedLong(), "end", null, 0, 1, TimeRange.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(entitySelectorEClass, EntitySelector.class, "EntitySelector", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getEntitySelector_Agency_id(), theMobilityResourcesPackage.getAgency(), null, "agency_id", null, 0, 1, EntitySelector.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getEntitySelector_Route_id(), theMobilityResourcesPackage.getRoute(), null, "route_id", null, 0, 1, EntitySelector.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getEntitySelector_Route_type(), theMobilityResourcesPackage.getTransit(), null, "route_type", null, 0, 1, EntitySelector.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getEntitySelector_Trip(), this.getTripDescriptor(), null, "trip", null, 0, 1, EntitySelector.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getEntitySelector_Stop_id(), theMobilityResourcesPackage.getStop(), null, "stop_id", null, 0, 1, EntitySelector.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getEntitySelector_Name(), ecorePackage.getEString(), "name", null, 0, 1, EntitySelector.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(positionEClass, Position.class, "Position", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPosition_Latitude(), ecorePackage.getEString(), "latitude", null, 0, 1, Position.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPosition_Longitude(), ecorePackage.getEString(), "longitude", null, 0, 1, Position.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPosition_Bearing(), ecorePackage.getEString(), "bearing", null, 0, 1, Position.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPosition_Odometer(), ecorePackage.getEDouble(), "odometer", null, 0, 1, Position.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPosition_Speed(), ecorePackage.getEFloat(), "speed", null, 0, 1, Position.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Initialize enums and add enum literals
		initEEnum(stopTimeScheduleRelationshipEEnum, StopTimeScheduleRelationship.class, "StopTimeScheduleRelationship");
		addEEnumLiteral(stopTimeScheduleRelationshipEEnum, StopTimeScheduleRelationship.SCHEDULED);
		addEEnumLiteral(stopTimeScheduleRelationshipEEnum, StopTimeScheduleRelationship.SKIPPED);
		addEEnumLiteral(stopTimeScheduleRelationshipEEnum, StopTimeScheduleRelationship.NO_DATA);

		initEEnum(vehicleStopStatusEEnum, VehicleStopStatus.class, "VehicleStopStatus");
		addEEnumLiteral(vehicleStopStatusEEnum, VehicleStopStatus.INCOMING_AT);
		addEEnumLiteral(vehicleStopStatusEEnum, VehicleStopStatus.STOPPED_AT);
		addEEnumLiteral(vehicleStopStatusEEnum, VehicleStopStatus.IN_TRANSIT_TO);

		initEEnum(congestionLevelEEnum, CongestionLevel.class, "CongestionLevel");
		addEEnumLiteral(congestionLevelEEnum, CongestionLevel.UNKNOWN_CONGESTION_LEVEL);
		addEEnumLiteral(congestionLevelEEnum, CongestionLevel.RUNNING_SMOOTHLY);
		addEEnumLiteral(congestionLevelEEnum, CongestionLevel.STOP_AND_GO);
		addEEnumLiteral(congestionLevelEEnum, CongestionLevel.CONGESTION);
		addEEnumLiteral(congestionLevelEEnum, CongestionLevel.SEVERE_CONGESTION);

		initEEnum(occupancyStatusEEnum, OccupancyStatus.class, "OccupancyStatus");
		addEEnumLiteral(occupancyStatusEEnum, OccupancyStatus.EMPTY);
		addEEnumLiteral(occupancyStatusEEnum, OccupancyStatus.MANY_SEATS_AVAILABLE);
		addEEnumLiteral(occupancyStatusEEnum, OccupancyStatus.FEW_SEATS_AVAILABLE);
		addEEnumLiteral(occupancyStatusEEnum, OccupancyStatus.STANDING_ROOM_ONLY);
		addEEnumLiteral(occupancyStatusEEnum, OccupancyStatus.CRUSHED_STANDING_ROOM_ONLY);
		addEEnumLiteral(occupancyStatusEEnum, OccupancyStatus.FULL);
		addEEnumLiteral(occupancyStatusEEnum, OccupancyStatus.NOT_ACCEPTING_PASSENGERS);

		initEEnum(causeEEnum, Cause.class, "Cause");
		addEEnumLiteral(causeEEnum, Cause.UNKNOWN_CAUSE);
		addEEnumLiteral(causeEEnum, Cause.OTHER_CAUSE);
		addEEnumLiteral(causeEEnum, Cause.TECHNICAL_PROBLEM);
		addEEnumLiteral(causeEEnum, Cause.STRIKE);
		addEEnumLiteral(causeEEnum, Cause.DEMONSTRATION);
		addEEnumLiteral(causeEEnum, Cause.ACCIDENT);
		addEEnumLiteral(causeEEnum, Cause.HOLIDAY);
		addEEnumLiteral(causeEEnum, Cause.WEATHER);
		addEEnumLiteral(causeEEnum, Cause.MAINTENANCE);
		addEEnumLiteral(causeEEnum, Cause.CONSTRUCTION);
		addEEnumLiteral(causeEEnum, Cause.POLICE_ACTIVITY);
		addEEnumLiteral(causeEEnum, Cause.MEDICAL_EMERGENCY);

		initEEnum(effectEEnum, Effect.class, "Effect");
		addEEnumLiteral(effectEEnum, Effect.NO_SERVICE);
		addEEnumLiteral(effectEEnum, Effect.REDUCED_SERVICE);
		addEEnumLiteral(effectEEnum, Effect.SIGNIFICANT_DELAYS);
		addEEnumLiteral(effectEEnum, Effect.DETOUR);
		addEEnumLiteral(effectEEnum, Effect.ADDITIONAL_SERVICE);
		addEEnumLiteral(effectEEnum, Effect.MODIFIED_SERVICE);
		addEEnumLiteral(effectEEnum, Effect.OTHER_EFFECT);
		addEEnumLiteral(effectEEnum, Effect.UNKNOWN_EFFECT);
		addEEnumLiteral(effectEEnum, Effect.STOP_MOVED);

		initEEnum(tripTimeScheduleRelationshipEEnum, TripTimeScheduleRelationship.class, "TripTimeScheduleRelationship");
		addEEnumLiteral(tripTimeScheduleRelationshipEEnum, TripTimeScheduleRelationship.SCHEDULED);
		addEEnumLiteral(tripTimeScheduleRelationshipEEnum, TripTimeScheduleRelationship.ADDED);
		addEEnumLiteral(tripTimeScheduleRelationshipEEnum, TripTimeScheduleRelationship.UNSCHEDULED);
		addEEnumLiteral(tripTimeScheduleRelationshipEEnum, TripTimeScheduleRelationship.CANCELLED);

		// Create resource
		createResource(eNS_URI);
	}

} //MapNotesPackageImpl
