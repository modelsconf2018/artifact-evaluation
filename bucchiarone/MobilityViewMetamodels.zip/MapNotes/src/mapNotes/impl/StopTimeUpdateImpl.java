/**
 */
package mapNotes.impl;

import java.util.Collection;

import mapNotes.MapNotesPackage;
import mapNotes.StopTimeEvent;
import mapNotes.StopTimeScheduleRelationship;
import mapNotes.StopTimeUpdate;

import mobilityResources.Stop;
import mobilityResources.Stop_time;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Stop Time Update</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link mapNotes.impl.StopTimeUpdateImpl#getStop_sequence <em>Stop sequence</em>}</li>
 *   <li>{@link mapNotes.impl.StopTimeUpdateImpl#getStop_id <em>Stop id</em>}</li>
 *   <li>{@link mapNotes.impl.StopTimeUpdateImpl#getArrival <em>Arrival</em>}</li>
 *   <li>{@link mapNotes.impl.StopTimeUpdateImpl#getDeparture <em>Departure</em>}</li>
 *   <li>{@link mapNotes.impl.StopTimeUpdateImpl#getSchedule_relationship <em>Schedule relationship</em>}</li>
 *   <li>{@link mapNotes.impl.StopTimeUpdateImpl#getStoptimeevent <em>Stoptimeevent</em>}</li>
 * </ul>
 *
 * @generated
 */
public class StopTimeUpdateImpl extends MinimalEObjectImpl.Container implements StopTimeUpdate {
	/**
	 * The cached value of the '{@link #getStop_sequence() <em>Stop sequence</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStop_sequence()
	 * @generated
	 * @ordered
	 */
	protected Stop_time stop_sequence;

	/**
	 * The cached value of the '{@link #getStop_id() <em>Stop id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStop_id()
	 * @generated
	 * @ordered
	 */
	protected Stop stop_id;

	/**
	 * The cached value of the '{@link #getArrival() <em>Arrival</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getArrival()
	 * @generated
	 * @ordered
	 */
	protected StopTimeEvent arrival;

	/**
	 * The cached value of the '{@link #getDeparture() <em>Departure</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDeparture()
	 * @generated
	 * @ordered
	 */
	protected StopTimeEvent departure;

	/**
	 * The default value of the '{@link #getSchedule_relationship() <em>Schedule relationship</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSchedule_relationship()
	 * @generated
	 * @ordered
	 */
	protected static final StopTimeScheduleRelationship SCHEDULE_RELATIONSHIP_EDEFAULT = StopTimeScheduleRelationship.SCHEDULED;

	/**
	 * The cached value of the '{@link #getSchedule_relationship() <em>Schedule relationship</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSchedule_relationship()
	 * @generated
	 * @ordered
	 */
	protected StopTimeScheduleRelationship schedule_relationship = SCHEDULE_RELATIONSHIP_EDEFAULT;

	/**
	 * The cached value of the '{@link #getStoptimeevent() <em>Stoptimeevent</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStoptimeevent()
	 * @generated
	 * @ordered
	 */
	protected EList<StopTimeEvent> stoptimeevent;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected StopTimeUpdateImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MapNotesPackage.Literals.STOP_TIME_UPDATE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Stop_time getStop_sequence() {
		if (stop_sequence != null && stop_sequence.eIsProxy()) {
			InternalEObject oldStop_sequence = (InternalEObject)stop_sequence;
			stop_sequence = (Stop_time)eResolveProxy(oldStop_sequence);
			if (stop_sequence != oldStop_sequence) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, MapNotesPackage.STOP_TIME_UPDATE__STOP_SEQUENCE, oldStop_sequence, stop_sequence));
			}
		}
		return stop_sequence;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Stop_time basicGetStop_sequence() {
		return stop_sequence;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setStop_sequence(Stop_time newStop_sequence) {
		Stop_time oldStop_sequence = stop_sequence;
		stop_sequence = newStop_sequence;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.STOP_TIME_UPDATE__STOP_SEQUENCE, oldStop_sequence, stop_sequence));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Stop getStop_id() {
		if (stop_id != null && stop_id.eIsProxy()) {
			InternalEObject oldStop_id = (InternalEObject)stop_id;
			stop_id = (Stop)eResolveProxy(oldStop_id);
			if (stop_id != oldStop_id) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, MapNotesPackage.STOP_TIME_UPDATE__STOP_ID, oldStop_id, stop_id));
			}
		}
		return stop_id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Stop basicGetStop_id() {
		return stop_id;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setStop_id(Stop newStop_id) {
		Stop oldStop_id = stop_id;
		stop_id = newStop_id;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.STOP_TIME_UPDATE__STOP_ID, oldStop_id, stop_id));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public StopTimeEvent getArrival() {
		if (arrival != null && arrival.eIsProxy()) {
			InternalEObject oldArrival = (InternalEObject)arrival;
			arrival = (StopTimeEvent)eResolveProxy(oldArrival);
			if (arrival != oldArrival) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, MapNotesPackage.STOP_TIME_UPDATE__ARRIVAL, oldArrival, arrival));
			}
		}
		return arrival;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public StopTimeEvent basicGetArrival() {
		return arrival;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setArrival(StopTimeEvent newArrival) {
		StopTimeEvent oldArrival = arrival;
		arrival = newArrival;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.STOP_TIME_UPDATE__ARRIVAL, oldArrival, arrival));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public StopTimeEvent getDeparture() {
		if (departure != null && departure.eIsProxy()) {
			InternalEObject oldDeparture = (InternalEObject)departure;
			departure = (StopTimeEvent)eResolveProxy(oldDeparture);
			if (departure != oldDeparture) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, MapNotesPackage.STOP_TIME_UPDATE__DEPARTURE, oldDeparture, departure));
			}
		}
		return departure;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public StopTimeEvent basicGetDeparture() {
		return departure;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDeparture(StopTimeEvent newDeparture) {
		StopTimeEvent oldDeparture = departure;
		departure = newDeparture;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.STOP_TIME_UPDATE__DEPARTURE, oldDeparture, departure));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public StopTimeScheduleRelationship getSchedule_relationship() {
		return schedule_relationship;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSchedule_relationship(StopTimeScheduleRelationship newSchedule_relationship) {
		StopTimeScheduleRelationship oldSchedule_relationship = schedule_relationship;
		schedule_relationship = newSchedule_relationship == null ? SCHEDULE_RELATIONSHIP_EDEFAULT : newSchedule_relationship;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, MapNotesPackage.STOP_TIME_UPDATE__SCHEDULE_RELATIONSHIP, oldSchedule_relationship, schedule_relationship));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<StopTimeEvent> getStoptimeevent() {
		if (stoptimeevent == null) {
			stoptimeevent = new EObjectContainmentEList<StopTimeEvent>(StopTimeEvent.class, this, MapNotesPackage.STOP_TIME_UPDATE__STOPTIMEEVENT);
		}
		return stoptimeevent;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case MapNotesPackage.STOP_TIME_UPDATE__STOPTIMEEVENT:
				return ((InternalEList<?>)getStoptimeevent()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case MapNotesPackage.STOP_TIME_UPDATE__STOP_SEQUENCE:
				if (resolve) return getStop_sequence();
				return basicGetStop_sequence();
			case MapNotesPackage.STOP_TIME_UPDATE__STOP_ID:
				if (resolve) return getStop_id();
				return basicGetStop_id();
			case MapNotesPackage.STOP_TIME_UPDATE__ARRIVAL:
				if (resolve) return getArrival();
				return basicGetArrival();
			case MapNotesPackage.STOP_TIME_UPDATE__DEPARTURE:
				if (resolve) return getDeparture();
				return basicGetDeparture();
			case MapNotesPackage.STOP_TIME_UPDATE__SCHEDULE_RELATIONSHIP:
				return getSchedule_relationship();
			case MapNotesPackage.STOP_TIME_UPDATE__STOPTIMEEVENT:
				return getStoptimeevent();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case MapNotesPackage.STOP_TIME_UPDATE__STOP_SEQUENCE:
				setStop_sequence((Stop_time)newValue);
				return;
			case MapNotesPackage.STOP_TIME_UPDATE__STOP_ID:
				setStop_id((Stop)newValue);
				return;
			case MapNotesPackage.STOP_TIME_UPDATE__ARRIVAL:
				setArrival((StopTimeEvent)newValue);
				return;
			case MapNotesPackage.STOP_TIME_UPDATE__DEPARTURE:
				setDeparture((StopTimeEvent)newValue);
				return;
			case MapNotesPackage.STOP_TIME_UPDATE__SCHEDULE_RELATIONSHIP:
				setSchedule_relationship((StopTimeScheduleRelationship)newValue);
				return;
			case MapNotesPackage.STOP_TIME_UPDATE__STOPTIMEEVENT:
				getStoptimeevent().clear();
				getStoptimeevent().addAll((Collection<? extends StopTimeEvent>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case MapNotesPackage.STOP_TIME_UPDATE__STOP_SEQUENCE:
				setStop_sequence((Stop_time)null);
				return;
			case MapNotesPackage.STOP_TIME_UPDATE__STOP_ID:
				setStop_id((Stop)null);
				return;
			case MapNotesPackage.STOP_TIME_UPDATE__ARRIVAL:
				setArrival((StopTimeEvent)null);
				return;
			case MapNotesPackage.STOP_TIME_UPDATE__DEPARTURE:
				setDeparture((StopTimeEvent)null);
				return;
			case MapNotesPackage.STOP_TIME_UPDATE__SCHEDULE_RELATIONSHIP:
				setSchedule_relationship(SCHEDULE_RELATIONSHIP_EDEFAULT);
				return;
			case MapNotesPackage.STOP_TIME_UPDATE__STOPTIMEEVENT:
				getStoptimeevent().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case MapNotesPackage.STOP_TIME_UPDATE__STOP_SEQUENCE:
				return stop_sequence != null;
			case MapNotesPackage.STOP_TIME_UPDATE__STOP_ID:
				return stop_id != null;
			case MapNotesPackage.STOP_TIME_UPDATE__ARRIVAL:
				return arrival != null;
			case MapNotesPackage.STOP_TIME_UPDATE__DEPARTURE:
				return departure != null;
			case MapNotesPackage.STOP_TIME_UPDATE__SCHEDULE_RELATIONSHIP:
				return schedule_relationship != SCHEDULE_RELATIONSHIP_EDEFAULT;
			case MapNotesPackage.STOP_TIME_UPDATE__STOPTIMEEVENT:
				return stoptimeevent != null && !stoptimeevent.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (schedule_relationship: ");
		result.append(schedule_relationship);
		result.append(')');
		return result.toString();
	}

} //StopTimeUpdateImpl
