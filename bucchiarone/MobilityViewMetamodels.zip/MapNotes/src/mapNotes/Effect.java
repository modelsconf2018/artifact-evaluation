/**
 */
package mapNotes;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Effect</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see mapNotes.MapNotesPackage#getEffect()
 * @model
 * @generated
 */
public enum Effect implements Enumerator {
	/**
	 * The '<em><b>NO SERVICE</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #NO_SERVICE_VALUE
	 * @generated
	 * @ordered
	 */
	NO_SERVICE(0, "NO_SERVICE", "NO_SERVICE"),

	/**
	 * The '<em><b>REDUCED SERVICE</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #REDUCED_SERVICE_VALUE
	 * @generated
	 * @ordered
	 */
	REDUCED_SERVICE(1, "REDUCED_SERVICE", "REDUCED_SERVICE"),

	/**
	 * The '<em><b>SIGNIFICANT DELAYS</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SIGNIFICANT_DELAYS_VALUE
	 * @generated
	 * @ordered
	 */
	SIGNIFICANT_DELAYS(2, "SIGNIFICANT_DELAYS", "SIGNIFICANT_DELAYS"),

	/**
	 * The '<em><b>DETOUR</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #DETOUR_VALUE
	 * @generated
	 * @ordered
	 */
	DETOUR(3, "DETOUR", "DETOUR"),

	/**
	 * The '<em><b>ADDITIONAL SERVICE</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #ADDITIONAL_SERVICE_VALUE
	 * @generated
	 * @ordered
	 */
	ADDITIONAL_SERVICE(4, "ADDITIONAL_SERVICE", "ADDITIONAL_SERVICE"),

	/**
	 * The '<em><b>MODIFIED SERVICE</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #MODIFIED_SERVICE_VALUE
	 * @generated
	 * @ordered
	 */
	MODIFIED_SERVICE(5, "MODIFIED_SERVICE", "MODIFIED_SERVICE"),

	/**
	 * The '<em><b>OTHER EFFECT</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #OTHER_EFFECT_VALUE
	 * @generated
	 * @ordered
	 */
	OTHER_EFFECT(6, "OTHER_EFFECT", "OTHER_EFFECT"),

	/**
	 * The '<em><b>UNKNOWN EFFECT</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #UNKNOWN_EFFECT_VALUE
	 * @generated
	 * @ordered
	 */
	UNKNOWN_EFFECT(7, "UNKNOWN_EFFECT", "UNKNOWN_EFFECT"),

	/**
	 * The '<em><b>STOP MOVED</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #STOP_MOVED_VALUE
	 * @generated
	 * @ordered
	 */
	STOP_MOVED(8, "STOP_MOVED", "STOP_MOVED");

	/**
	 * The '<em><b>NO SERVICE</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>NO SERVICE</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #NO_SERVICE
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int NO_SERVICE_VALUE = 0;

	/**
	 * The '<em><b>REDUCED SERVICE</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>REDUCED SERVICE</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #REDUCED_SERVICE
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int REDUCED_SERVICE_VALUE = 1;

	/**
	 * The '<em><b>SIGNIFICANT DELAYS</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>SIGNIFICANT DELAYS</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #SIGNIFICANT_DELAYS
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int SIGNIFICANT_DELAYS_VALUE = 2;

	/**
	 * The '<em><b>DETOUR</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>DETOUR</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #DETOUR
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int DETOUR_VALUE = 3;

	/**
	 * The '<em><b>ADDITIONAL SERVICE</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>ADDITIONAL SERVICE</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #ADDITIONAL_SERVICE
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int ADDITIONAL_SERVICE_VALUE = 4;

	/**
	 * The '<em><b>MODIFIED SERVICE</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>MODIFIED SERVICE</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #MODIFIED_SERVICE
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int MODIFIED_SERVICE_VALUE = 5;

	/**
	 * The '<em><b>OTHER EFFECT</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>OTHER EFFECT</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #OTHER_EFFECT
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int OTHER_EFFECT_VALUE = 6;

	/**
	 * The '<em><b>UNKNOWN EFFECT</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>UNKNOWN EFFECT</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #UNKNOWN_EFFECT
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int UNKNOWN_EFFECT_VALUE = 7;

	/**
	 * The '<em><b>STOP MOVED</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>STOP MOVED</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #STOP_MOVED
	 * @model
	 * @generated
	 * @ordered
	 */
	public static final int STOP_MOVED_VALUE = 8;

	/**
	 * An array of all the '<em><b>Effect</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final Effect[] VALUES_ARRAY =
		new Effect[] {
			NO_SERVICE,
			REDUCED_SERVICE,
			SIGNIFICANT_DELAYS,
			DETOUR,
			ADDITIONAL_SERVICE,
			MODIFIED_SERVICE,
			OTHER_EFFECT,
			UNKNOWN_EFFECT,
			STOP_MOVED,
		};

	/**
	 * A public read-only list of all the '<em><b>Effect</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<Effect> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Effect</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param literal the literal.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static Effect get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			Effect result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Effect</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param name the name.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static Effect getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			Effect result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Effect</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the integer value.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static Effect get(int value) {
		switch (value) {
			case NO_SERVICE_VALUE: return NO_SERVICE;
			case REDUCED_SERVICE_VALUE: return REDUCED_SERVICE;
			case SIGNIFICANT_DELAYS_VALUE: return SIGNIFICANT_DELAYS;
			case DETOUR_VALUE: return DETOUR;
			case ADDITIONAL_SERVICE_VALUE: return ADDITIONAL_SERVICE;
			case MODIFIED_SERVICE_VALUE: return MODIFIED_SERVICE;
			case OTHER_EFFECT_VALUE: return OTHER_EFFECT;
			case UNKNOWN_EFFECT_VALUE: return UNKNOWN_EFFECT;
			case STOP_MOVED_VALUE: return STOP_MOVED;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private Effect(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getValue() {
	  return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getName() {
	  return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getLiteral() {
	  return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}
	
} //Effect
