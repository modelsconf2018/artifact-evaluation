/**
 */
package mapNotes;

import java.math.BigInteger;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Trip Update</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mapNotes.TripUpdate#getTimestamp <em>Timestamp</em>}</li>
 *   <li>{@link mapNotes.TripUpdate#getDelay <em>Delay</em>}</li>
 *   <li>{@link mapNotes.TripUpdate#getTripdescriptor <em>Tripdescriptor</em>}</li>
 *   <li>{@link mapNotes.TripUpdate#getVehicledescriptor <em>Vehicledescriptor</em>}</li>
 *   <li>{@link mapNotes.TripUpdate#getStop_time_updates <em>Stop time updates</em>}</li>
 * </ul>
 *
 * @see mapNotes.MapNotesPackage#getTripUpdate()
 * @model
 * @generated
 */
public interface TripUpdate extends EObject {
	/**
	 * Returns the value of the '<em><b>Timestamp</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Timestamp</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Timestamp</em>' attribute.
	 * @see #setTimestamp(BigInteger)
	 * @see mapNotes.MapNotesPackage#getTripUpdate_Timestamp()
	 * @model dataType="org.eclipse.emf.ecore.xml.type.UnsignedLong"
	 * @generated
	 */
	BigInteger getTimestamp();

	/**
	 * Sets the value of the '{@link mapNotes.TripUpdate#getTimestamp <em>Timestamp</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Timestamp</em>' attribute.
	 * @see #getTimestamp()
	 * @generated
	 */
	void setTimestamp(BigInteger value);

	/**
	 * Returns the value of the '<em><b>Delay</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Delay</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Delay</em>' attribute.
	 * @see #setDelay(int)
	 * @see mapNotes.MapNotesPackage#getTripUpdate_Delay()
	 * @model
	 * @generated
	 */
	int getDelay();

	/**
	 * Sets the value of the '{@link mapNotes.TripUpdate#getDelay <em>Delay</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Delay</em>' attribute.
	 * @see #getDelay()
	 * @generated
	 */
	void setDelay(int value);

	/**
	 * Returns the value of the '<em><b>Tripdescriptor</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Tripdescriptor</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Tripdescriptor</em>' containment reference.
	 * @see #setTripdescriptor(TripDescriptor)
	 * @see mapNotes.MapNotesPackage#getTripUpdate_Tripdescriptor()
	 * @model containment="true"
	 * @generated
	 */
	TripDescriptor getTripdescriptor();

	/**
	 * Sets the value of the '{@link mapNotes.TripUpdate#getTripdescriptor <em>Tripdescriptor</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Tripdescriptor</em>' containment reference.
	 * @see #getTripdescriptor()
	 * @generated
	 */
	void setTripdescriptor(TripDescriptor value);

	/**
	 * Returns the value of the '<em><b>Vehicledescriptor</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Vehicledescriptor</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Vehicledescriptor</em>' reference.
	 * @see #setVehicledescriptor(VehicleDescriptor)
	 * @see mapNotes.MapNotesPackage#getTripUpdate_Vehicledescriptor()
	 * @model
	 * @generated
	 */
	VehicleDescriptor getVehicledescriptor();

	/**
	 * Sets the value of the '{@link mapNotes.TripUpdate#getVehicledescriptor <em>Vehicledescriptor</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Vehicledescriptor</em>' reference.
	 * @see #getVehicledescriptor()
	 * @generated
	 */
	void setVehicledescriptor(VehicleDescriptor value);

	/**
	 * Returns the value of the '<em><b>Stop time updates</b></em>' containment reference list.
	 * The list contents are of type {@link mapNotes.StopTimeUpdate}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Stop time updates</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Stop time updates</em>' containment reference list.
	 * @see mapNotes.MapNotesPackage#getTripUpdate_Stop_time_updates()
	 * @model containment="true"
	 * @generated
	 */
	EList<StopTimeUpdate> getStop_time_updates();

} // TripUpdate
