/**
 */
package mapNotes.util;

import mapNotes.*;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see mapNotes.MapNotesPackage
 * @generated
 */
public class MapNotesAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static MapNotesPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MapNotesAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = MapNotesPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject)object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MapNotesSwitch<Adapter> modelSwitch =
		new MapNotesSwitch<Adapter>() {
			@Override
			public Adapter caseMapNotes(MapNotes object) {
				return createMapNotesAdapter();
			}
			@Override
			public Adapter caseTrafficRemark(TrafficRemark object) {
				return createTrafficRemarkAdapter();
			}
			@Override
			public Adapter caseStatusRemark(StatusRemark object) {
				return createStatusRemarkAdapter();
			}
			@Override
			public Adapter caseBikeSharingRemark(BikeSharingRemark object) {
				return createBikeSharingRemarkAdapter();
			}
			@Override
			public Adapter caseParkingRemark(ParkingRemark object) {
				return createParkingRemarkAdapter();
			}
			@Override
			public Adapter caseTransitRemark(TransitRemark object) {
				return createTransitRemarkAdapter();
			}
			@Override
			public Adapter caseTripUpdate(TripUpdate object) {
				return createTripUpdateAdapter();
			}
			@Override
			public Adapter caseVehicle(Vehicle object) {
				return createVehicleAdapter();
			}
			@Override
			public Adapter caseAlert(Alert object) {
				return createAlertAdapter();
			}
			@Override
			public Adapter caseTripDescriptor(TripDescriptor object) {
				return createTripDescriptorAdapter();
			}
			@Override
			public Adapter caseVehicleDescriptor(VehicleDescriptor object) {
				return createVehicleDescriptorAdapter();
			}
			@Override
			public Adapter caseStopTimeUpdate(StopTimeUpdate object) {
				return createStopTimeUpdateAdapter();
			}
			@Override
			public Adapter caseStopTimeEvent(StopTimeEvent object) {
				return createStopTimeEventAdapter();
			}
			@Override
			public Adapter caseTimeRange(TimeRange object) {
				return createTimeRangeAdapter();
			}
			@Override
			public Adapter caseEntitySelector(EntitySelector object) {
				return createEntitySelectorAdapter();
			}
			@Override
			public Adapter casePosition(Position object) {
				return createPositionAdapter();
			}
			@Override
			public Adapter defaultCase(EObject object) {
				return createEObjectAdapter();
			}
		};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject)target);
	}


	/**
	 * Creates a new adapter for an object of class '{@link mapNotes.MapNotes <em>Map Notes</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mapNotes.MapNotes
	 * @generated
	 */
	public Adapter createMapNotesAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mapNotes.TrafficRemark <em>Traffic Remark</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mapNotes.TrafficRemark
	 * @generated
	 */
	public Adapter createTrafficRemarkAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mapNotes.StatusRemark <em>Status Remark</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mapNotes.StatusRemark
	 * @generated
	 */
	public Adapter createStatusRemarkAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mapNotes.BikeSharingRemark <em>Bike Sharing Remark</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mapNotes.BikeSharingRemark
	 * @generated
	 */
	public Adapter createBikeSharingRemarkAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mapNotes.ParkingRemark <em>Parking Remark</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mapNotes.ParkingRemark
	 * @generated
	 */
	public Adapter createParkingRemarkAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mapNotes.TransitRemark <em>Transit Remark</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mapNotes.TransitRemark
	 * @generated
	 */
	public Adapter createTransitRemarkAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mapNotes.TripUpdate <em>Trip Update</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mapNotes.TripUpdate
	 * @generated
	 */
	public Adapter createTripUpdateAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mapNotes.Vehicle <em>Vehicle</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mapNotes.Vehicle
	 * @generated
	 */
	public Adapter createVehicleAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mapNotes.Alert <em>Alert</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mapNotes.Alert
	 * @generated
	 */
	public Adapter createAlertAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mapNotes.TripDescriptor <em>Trip Descriptor</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mapNotes.TripDescriptor
	 * @generated
	 */
	public Adapter createTripDescriptorAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mapNotes.VehicleDescriptor <em>Vehicle Descriptor</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mapNotes.VehicleDescriptor
	 * @generated
	 */
	public Adapter createVehicleDescriptorAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mapNotes.StopTimeUpdate <em>Stop Time Update</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mapNotes.StopTimeUpdate
	 * @generated
	 */
	public Adapter createStopTimeUpdateAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mapNotes.StopTimeEvent <em>Stop Time Event</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mapNotes.StopTimeEvent
	 * @generated
	 */
	public Adapter createStopTimeEventAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mapNotes.TimeRange <em>Time Range</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mapNotes.TimeRange
	 * @generated
	 */
	public Adapter createTimeRangeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mapNotes.EntitySelector <em>Entity Selector</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mapNotes.EntitySelector
	 * @generated
	 */
	public Adapter createEntitySelectorAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link mapNotes.Position <em>Position</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see mapNotes.Position
	 * @generated
	 */
	public Adapter createPositionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //MapNotesAdapterFactory
