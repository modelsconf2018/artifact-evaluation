/**
 */
package mapNotes;

import mobilityResources.Stop;
import mobilityResources.Stop_time;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Stop Time Update</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mapNotes.StopTimeUpdate#getStop_sequence <em>Stop sequence</em>}</li>
 *   <li>{@link mapNotes.StopTimeUpdate#getStop_id <em>Stop id</em>}</li>
 *   <li>{@link mapNotes.StopTimeUpdate#getArrival <em>Arrival</em>}</li>
 *   <li>{@link mapNotes.StopTimeUpdate#getDeparture <em>Departure</em>}</li>
 *   <li>{@link mapNotes.StopTimeUpdate#getSchedule_relationship <em>Schedule relationship</em>}</li>
 *   <li>{@link mapNotes.StopTimeUpdate#getStoptimeevent <em>Stoptimeevent</em>}</li>
 * </ul>
 *
 * @see mapNotes.MapNotesPackage#getStopTimeUpdate()
 * @model
 * @generated
 */
public interface StopTimeUpdate extends EObject {
	/**
	 * Returns the value of the '<em><b>Stop sequence</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Stop sequence</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Stop sequence</em>' reference.
	 * @see #setStop_sequence(Stop_time)
	 * @see mapNotes.MapNotesPackage#getStopTimeUpdate_Stop_sequence()
	 * @model
	 * @generated
	 */
	Stop_time getStop_sequence();

	/**
	 * Sets the value of the '{@link mapNotes.StopTimeUpdate#getStop_sequence <em>Stop sequence</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Stop sequence</em>' reference.
	 * @see #getStop_sequence()
	 * @generated
	 */
	void setStop_sequence(Stop_time value);

	/**
	 * Returns the value of the '<em><b>Stop id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Stop id</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Stop id</em>' reference.
	 * @see #setStop_id(Stop)
	 * @see mapNotes.MapNotesPackage#getStopTimeUpdate_Stop_id()
	 * @model
	 * @generated
	 */
	Stop getStop_id();

	/**
	 * Sets the value of the '{@link mapNotes.StopTimeUpdate#getStop_id <em>Stop id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Stop id</em>' reference.
	 * @see #getStop_id()
	 * @generated
	 */
	void setStop_id(Stop value);

	/**
	 * Returns the value of the '<em><b>Arrival</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Arrival</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Arrival</em>' reference.
	 * @see #setArrival(StopTimeEvent)
	 * @see mapNotes.MapNotesPackage#getStopTimeUpdate_Arrival()
	 * @model
	 * @generated
	 */
	StopTimeEvent getArrival();

	/**
	 * Sets the value of the '{@link mapNotes.StopTimeUpdate#getArrival <em>Arrival</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Arrival</em>' reference.
	 * @see #getArrival()
	 * @generated
	 */
	void setArrival(StopTimeEvent value);

	/**
	 * Returns the value of the '<em><b>Departure</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Departure</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Departure</em>' reference.
	 * @see #setDeparture(StopTimeEvent)
	 * @see mapNotes.MapNotesPackage#getStopTimeUpdate_Departure()
	 * @model
	 * @generated
	 */
	StopTimeEvent getDeparture();

	/**
	 * Sets the value of the '{@link mapNotes.StopTimeUpdate#getDeparture <em>Departure</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Departure</em>' reference.
	 * @see #getDeparture()
	 * @generated
	 */
	void setDeparture(StopTimeEvent value);

	/**
	 * Returns the value of the '<em><b>Schedule relationship</b></em>' attribute.
	 * The literals are from the enumeration {@link mapNotes.StopTimeScheduleRelationship}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Schedule relationship</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Schedule relationship</em>' attribute.
	 * @see mapNotes.StopTimeScheduleRelationship
	 * @see #setSchedule_relationship(StopTimeScheduleRelationship)
	 * @see mapNotes.MapNotesPackage#getStopTimeUpdate_Schedule_relationship()
	 * @model
	 * @generated
	 */
	StopTimeScheduleRelationship getSchedule_relationship();

	/**
	 * Sets the value of the '{@link mapNotes.StopTimeUpdate#getSchedule_relationship <em>Schedule relationship</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Schedule relationship</em>' attribute.
	 * @see mapNotes.StopTimeScheduleRelationship
	 * @see #getSchedule_relationship()
	 * @generated
	 */
	void setSchedule_relationship(StopTimeScheduleRelationship value);

	/**
	 * Returns the value of the '<em><b>Stoptimeevent</b></em>' containment reference list.
	 * The list contents are of type {@link mapNotes.StopTimeEvent}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Stoptimeevent</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Stoptimeevent</em>' containment reference list.
	 * @see mapNotes.MapNotesPackage#getStopTimeUpdate_Stoptimeevent()
	 * @model containment="true"
	 * @generated
	 */
	EList<StopTimeEvent> getStoptimeevent();

} // StopTimeUpdate
