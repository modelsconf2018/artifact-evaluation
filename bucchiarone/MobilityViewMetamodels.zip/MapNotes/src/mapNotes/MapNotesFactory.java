/**
 */
package mapNotes;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see mapNotes.MapNotesPackage
 * @generated
 */
public interface MapNotesFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	MapNotesFactory eINSTANCE = mapNotes.impl.MapNotesFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Map Notes</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Map Notes</em>'.
	 * @generated
	 */
	MapNotes createMapNotes();

	/**
	 * Returns a new object of class '<em>Traffic Remark</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Traffic Remark</em>'.
	 * @generated
	 */
	TrafficRemark createTrafficRemark();

	/**
	 * Returns a new object of class '<em>Bike Sharing Remark</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Bike Sharing Remark</em>'.
	 * @generated
	 */
	BikeSharingRemark createBikeSharingRemark();

	/**
	 * Returns a new object of class '<em>Parking Remark</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Parking Remark</em>'.
	 * @generated
	 */
	ParkingRemark createParkingRemark();

	/**
	 * Returns a new object of class '<em>Transit Remark</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Transit Remark</em>'.
	 * @generated
	 */
	TransitRemark createTransitRemark();

	/**
	 * Returns a new object of class '<em>Trip Update</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Trip Update</em>'.
	 * @generated
	 */
	TripUpdate createTripUpdate();

	/**
	 * Returns a new object of class '<em>Vehicle</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Vehicle</em>'.
	 * @generated
	 */
	Vehicle createVehicle();

	/**
	 * Returns a new object of class '<em>Alert</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Alert</em>'.
	 * @generated
	 */
	Alert createAlert();

	/**
	 * Returns a new object of class '<em>Trip Descriptor</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Trip Descriptor</em>'.
	 * @generated
	 */
	TripDescriptor createTripDescriptor();

	/**
	 * Returns a new object of class '<em>Vehicle Descriptor</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Vehicle Descriptor</em>'.
	 * @generated
	 */
	VehicleDescriptor createVehicleDescriptor();

	/**
	 * Returns a new object of class '<em>Stop Time Update</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Stop Time Update</em>'.
	 * @generated
	 */
	StopTimeUpdate createStopTimeUpdate();

	/**
	 * Returns a new object of class '<em>Stop Time Event</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Stop Time Event</em>'.
	 * @generated
	 */
	StopTimeEvent createStopTimeEvent();

	/**
	 * Returns a new object of class '<em>Time Range</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Time Range</em>'.
	 * @generated
	 */
	TimeRange createTimeRange();

	/**
	 * Returns a new object of class '<em>Entity Selector</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Entity Selector</em>'.
	 * @generated
	 */
	EntitySelector createEntitySelector();

	/**
	 * Returns a new object of class '<em>Position</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Position</em>'.
	 * @generated
	 */
	Position createPosition();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	MapNotesPackage getMapNotesPackage();

} //MapNotesFactory
