/**
 */
package mapNotes;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Traffic Remark</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mapNotes.TrafficRemark#getWayId <em>Way Id</em>}</li>
 *   <li>{@link mapNotes.TrafficRemark#getStartNodeId <em>Start Node Id</em>}</li>
 *   <li>{@link mapNotes.TrafficRemark#getEndNodeId <em>End Node Id</em>}</li>
 *   <li>{@link mapNotes.TrafficRemark#getLon <em>Lon</em>}</li>
 *   <li>{@link mapNotes.TrafficRemark#getLat <em>Lat</em>}</li>
 *   <li>{@link mapNotes.TrafficRemark#getWhen <em>When</em>}</li>
 *   <li>{@link mapNotes.TrafficRemark#getAppliesTo <em>Applies To</em>}</li>
 *   <li>{@link mapNotes.TrafficRemark#getNextPoint <em>Next Point</em>}</li>
 *   <li>{@link mapNotes.TrafficRemark#getName <em>Name</em>}</li>
 *   <li>{@link mapNotes.TrafficRemark#getAverageSpeed <em>Average Speed</em>}</li>
 * </ul>
 *
 * @see mapNotes.MapNotesPackage#getTrafficRemark()
 * @model
 * @generated
 */
public interface TrafficRemark extends StatusRemark {
	/**
	 * Returns the value of the '<em><b>Way Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Way Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Way Id</em>' attribute.
	 * @see #setWayId(String)
	 * @see mapNotes.MapNotesPackage#getTrafficRemark_WayId()
	 * @model
	 * @generated
	 */
	String getWayId();

	/**
	 * Sets the value of the '{@link mapNotes.TrafficRemark#getWayId <em>Way Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Way Id</em>' attribute.
	 * @see #getWayId()
	 * @generated
	 */
	void setWayId(String value);

	/**
	 * Returns the value of the '<em><b>Start Node Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Start Node Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Start Node Id</em>' attribute.
	 * @see #setStartNodeId(String)
	 * @see mapNotes.MapNotesPackage#getTrafficRemark_StartNodeId()
	 * @model
	 * @generated
	 */
	String getStartNodeId();

	/**
	 * Sets the value of the '{@link mapNotes.TrafficRemark#getStartNodeId <em>Start Node Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Start Node Id</em>' attribute.
	 * @see #getStartNodeId()
	 * @generated
	 */
	void setStartNodeId(String value);

	/**
	 * Returns the value of the '<em><b>End Node Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>End Node Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>End Node Id</em>' attribute.
	 * @see #setEndNodeId(String)
	 * @see mapNotes.MapNotesPackage#getTrafficRemark_EndNodeId()
	 * @model
	 * @generated
	 */
	String getEndNodeId();

	/**
	 * Sets the value of the '{@link mapNotes.TrafficRemark#getEndNodeId <em>End Node Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>End Node Id</em>' attribute.
	 * @see #getEndNodeId()
	 * @generated
	 */
	void setEndNodeId(String value);

	/**
	 * Returns the value of the '<em><b>Lon</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Lon</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Lon</em>' attribute.
	 * @see #setLon(String)
	 * @see mapNotes.MapNotesPackage#getTrafficRemark_Lon()
	 * @model
	 * @generated
	 */
	String getLon();

	/**
	 * Sets the value of the '{@link mapNotes.TrafficRemark#getLon <em>Lon</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Lon</em>' attribute.
	 * @see #getLon()
	 * @generated
	 */
	void setLon(String value);

	/**
	 * Returns the value of the '<em><b>Lat</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Lat</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Lat</em>' attribute.
	 * @see #setLat(String)
	 * @see mapNotes.MapNotesPackage#getTrafficRemark_Lat()
	 * @model
	 * @generated
	 */
	String getLat();

	/**
	 * Sets the value of the '{@link mapNotes.TrafficRemark#getLat <em>Lat</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Lat</em>' attribute.
	 * @see #getLat()
	 * @generated
	 */
	void setLat(String value);

	/**
	 * Returns the value of the '<em><b>When</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>When</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>When</em>' attribute.
	 * @see #setWhen(String)
	 * @see mapNotes.MapNotesPackage#getTrafficRemark_When()
	 * @model
	 * @generated
	 */
	String getWhen();

	/**
	 * Sets the value of the '{@link mapNotes.TrafficRemark#getWhen <em>When</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>When</em>' attribute.
	 * @see #getWhen()
	 * @generated
	 */
	void setWhen(String value);

	/**
	 * Returns the value of the '<em><b>Applies To</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Applies To</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Applies To</em>' attribute.
	 * @see #setAppliesTo(String)
	 * @see mapNotes.MapNotesPackage#getTrafficRemark_AppliesTo()
	 * @model
	 * @generated
	 */
	String getAppliesTo();

	/**
	 * Sets the value of the '{@link mapNotes.TrafficRemark#getAppliesTo <em>Applies To</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Applies To</em>' attribute.
	 * @see #getAppliesTo()
	 * @generated
	 */
	void setAppliesTo(String value);

	/**
	 * Returns the value of the '<em><b>Next Point</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Next Point</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Next Point</em>' reference.
	 * @see #setNextPoint(TrafficRemark)
	 * @see mapNotes.MapNotesPackage#getTrafficRemark_NextPoint()
	 * @model
	 * @generated
	 */
	TrafficRemark getNextPoint();

	/**
	 * Sets the value of the '{@link mapNotes.TrafficRemark#getNextPoint <em>Next Point</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Next Point</em>' reference.
	 * @see #getNextPoint()
	 * @generated
	 */
	void setNextPoint(TrafficRemark value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see mapNotes.MapNotesPackage#getTrafficRemark_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link mapNotes.TrafficRemark#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Average Speed</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Average Speed</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Average Speed</em>' attribute.
	 * @see #setAverageSpeed(String)
	 * @see mapNotes.MapNotesPackage#getTrafficRemark_AverageSpeed()
	 * @model
	 * @generated
	 */
	String getAverageSpeed();

	/**
	 * Sets the value of the '{@link mapNotes.TrafficRemark#getAverageSpeed <em>Average Speed</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Average Speed</em>' attribute.
	 * @see #getAverageSpeed()
	 * @generated
	 */
	void setAverageSpeed(String value);

} // TrafficRemark
