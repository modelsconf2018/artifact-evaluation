/**
 */
package mapNotes;

import mobilityResources.Agency;
import mobilityResources.Route;
import mobilityResources.Stop;
import mobilityResources.Transit;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Entity Selector</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mapNotes.EntitySelector#getAgency_id <em>Agency id</em>}</li>
 *   <li>{@link mapNotes.EntitySelector#getRoute_id <em>Route id</em>}</li>
 *   <li>{@link mapNotes.EntitySelector#getRoute_type <em>Route type</em>}</li>
 *   <li>{@link mapNotes.EntitySelector#getTrip <em>Trip</em>}</li>
 *   <li>{@link mapNotes.EntitySelector#getStop_id <em>Stop id</em>}</li>
 *   <li>{@link mapNotes.EntitySelector#getName <em>Name</em>}</li>
 * </ul>
 *
 * @see mapNotes.MapNotesPackage#getEntitySelector()
 * @model
 * @generated
 */
public interface EntitySelector extends EObject {
	/**
	 * Returns the value of the '<em><b>Agency id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Agency id</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Agency id</em>' reference.
	 * @see #setAgency_id(Agency)
	 * @see mapNotes.MapNotesPackage#getEntitySelector_Agency_id()
	 * @model
	 * @generated
	 */
	Agency getAgency_id();

	/**
	 * Sets the value of the '{@link mapNotes.EntitySelector#getAgency_id <em>Agency id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Agency id</em>' reference.
	 * @see #getAgency_id()
	 * @generated
	 */
	void setAgency_id(Agency value);

	/**
	 * Returns the value of the '<em><b>Route id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Route id</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Route id</em>' reference.
	 * @see #setRoute_id(Route)
	 * @see mapNotes.MapNotesPackage#getEntitySelector_Route_id()
	 * @model
	 * @generated
	 */
	Route getRoute_id();

	/**
	 * Sets the value of the '{@link mapNotes.EntitySelector#getRoute_id <em>Route id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Route id</em>' reference.
	 * @see #getRoute_id()
	 * @generated
	 */
	void setRoute_id(Route value);

	/**
	 * Returns the value of the '<em><b>Route type</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Route type</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Route type</em>' reference.
	 * @see #setRoute_type(Transit)
	 * @see mapNotes.MapNotesPackage#getEntitySelector_Route_type()
	 * @model
	 * @generated
	 */
	Transit getRoute_type();

	/**
	 * Sets the value of the '{@link mapNotes.EntitySelector#getRoute_type <em>Route type</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Route type</em>' reference.
	 * @see #getRoute_type()
	 * @generated
	 */
	void setRoute_type(Transit value);

	/**
	 * Returns the value of the '<em><b>Trip</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Trip</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Trip</em>' reference.
	 * @see #setTrip(TripDescriptor)
	 * @see mapNotes.MapNotesPackage#getEntitySelector_Trip()
	 * @model
	 * @generated
	 */
	TripDescriptor getTrip();

	/**
	 * Sets the value of the '{@link mapNotes.EntitySelector#getTrip <em>Trip</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Trip</em>' reference.
	 * @see #getTrip()
	 * @generated
	 */
	void setTrip(TripDescriptor value);

	/**
	 * Returns the value of the '<em><b>Stop id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Stop id</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Stop id</em>' reference.
	 * @see #setStop_id(Stop)
	 * @see mapNotes.MapNotesPackage#getEntitySelector_Stop_id()
	 * @model
	 * @generated
	 */
	Stop getStop_id();

	/**
	 * Sets the value of the '{@link mapNotes.EntitySelector#getStop_id <em>Stop id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Stop id</em>' reference.
	 * @see #getStop_id()
	 * @generated
	 */
	void setStop_id(Stop value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see mapNotes.MapNotesPackage#getEntitySelector_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link mapNotes.EntitySelector#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

} // EntitySelector
