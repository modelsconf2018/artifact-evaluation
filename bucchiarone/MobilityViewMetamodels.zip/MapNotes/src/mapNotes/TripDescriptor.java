/**
 */
package mapNotes;

import mobilityResources.Route;
import mobilityResources.Trip;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Trip Descriptor</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mapNotes.TripDescriptor#getTrip_id <em>Trip id</em>}</li>
 *   <li>{@link mapNotes.TripDescriptor#getRoute_id <em>Route id</em>}</li>
 *   <li>{@link mapNotes.TripDescriptor#getDirection_id <em>Direction id</em>}</li>
 *   <li>{@link mapNotes.TripDescriptor#getStart_time <em>Start time</em>}</li>
 *   <li>{@link mapNotes.TripDescriptor#getStart_date <em>Start date</em>}</li>
 *   <li>{@link mapNotes.TripDescriptor#getSchedule_relationship <em>Schedule relationship</em>}</li>
 * </ul>
 *
 * @see mapNotes.MapNotesPackage#getTripDescriptor()
 * @model
 * @generated
 */
public interface TripDescriptor extends EObject {
	/**
	 * Returns the value of the '<em><b>Trip id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Trip id</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Trip id</em>' reference.
	 * @see #setTrip_id(Trip)
	 * @see mapNotes.MapNotesPackage#getTripDescriptor_Trip_id()
	 * @model
	 * @generated
	 */
	Trip getTrip_id();

	/**
	 * Sets the value of the '{@link mapNotes.TripDescriptor#getTrip_id <em>Trip id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Trip id</em>' reference.
	 * @see #getTrip_id()
	 * @generated
	 */
	void setTrip_id(Trip value);

	/**
	 * Returns the value of the '<em><b>Route id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Route id</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Route id</em>' reference.
	 * @see #setRoute_id(Route)
	 * @see mapNotes.MapNotesPackage#getTripDescriptor_Route_id()
	 * @model
	 * @generated
	 */
	Route getRoute_id();

	/**
	 * Sets the value of the '{@link mapNotes.TripDescriptor#getRoute_id <em>Route id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Route id</em>' reference.
	 * @see #getRoute_id()
	 * @generated
	 */
	void setRoute_id(Route value);

	/**
	 * Returns the value of the '<em><b>Direction id</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Direction id</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Direction id</em>' reference.
	 * @see #setDirection_id(Trip)
	 * @see mapNotes.MapNotesPackage#getTripDescriptor_Direction_id()
	 * @model
	 * @generated
	 */
	Trip getDirection_id();

	/**
	 * Sets the value of the '{@link mapNotes.TripDescriptor#getDirection_id <em>Direction id</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Direction id</em>' reference.
	 * @see #getDirection_id()
	 * @generated
	 */
	void setDirection_id(Trip value);

	/**
	 * Returns the value of the '<em><b>Start time</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Start time</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Start time</em>' attribute.
	 * @see #setStart_time(String)
	 * @see mapNotes.MapNotesPackage#getTripDescriptor_Start_time()
	 * @model
	 * @generated
	 */
	String getStart_time();

	/**
	 * Sets the value of the '{@link mapNotes.TripDescriptor#getStart_time <em>Start time</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Start time</em>' attribute.
	 * @see #getStart_time()
	 * @generated
	 */
	void setStart_time(String value);

	/**
	 * Returns the value of the '<em><b>Start date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Start date</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Start date</em>' attribute.
	 * @see #setStart_date(String)
	 * @see mapNotes.MapNotesPackage#getTripDescriptor_Start_date()
	 * @model
	 * @generated
	 */
	String getStart_date();

	/**
	 * Sets the value of the '{@link mapNotes.TripDescriptor#getStart_date <em>Start date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Start date</em>' attribute.
	 * @see #getStart_date()
	 * @generated
	 */
	void setStart_date(String value);

	/**
	 * Returns the value of the '<em><b>Schedule relationship</b></em>' attribute.
	 * The literals are from the enumeration {@link mapNotes.TripTimeScheduleRelationship}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Schedule relationship</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Schedule relationship</em>' attribute.
	 * @see mapNotes.TripTimeScheduleRelationship
	 * @see #setSchedule_relationship(TripTimeScheduleRelationship)
	 * @see mapNotes.MapNotesPackage#getTripDescriptor_Schedule_relationship()
	 * @model
	 * @generated
	 */
	TripTimeScheduleRelationship getSchedule_relationship();

	/**
	 * Sets the value of the '{@link mapNotes.TripDescriptor#getSchedule_relationship <em>Schedule relationship</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Schedule relationship</em>' attribute.
	 * @see mapNotes.TripTimeScheduleRelationship
	 * @see #getSchedule_relationship()
	 * @generated
	 */
	void setSchedule_relationship(TripTimeScheduleRelationship value);

} // TripDescriptor
