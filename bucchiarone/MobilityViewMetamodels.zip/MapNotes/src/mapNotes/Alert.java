/**
 */
package mapNotes;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Alert</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link mapNotes.Alert#getActive_period <em>Active period</em>}</li>
 *   <li>{@link mapNotes.Alert#getInformed_entity <em>Informed entity</em>}</li>
 *   <li>{@link mapNotes.Alert#getCause <em>Cause</em>}</li>
 *   <li>{@link mapNotes.Alert#getEffect <em>Effect</em>}</li>
 *   <li>{@link mapNotes.Alert#getUrl <em>Url</em>}</li>
 *   <li>{@link mapNotes.Alert#getHeader_text <em>Header text</em>}</li>
 *   <li>{@link mapNotes.Alert#getDescription_text <em>Description text</em>}</li>
 * </ul>
 *
 * @see mapNotes.MapNotesPackage#getAlert()
 * @model
 * @generated
 */
public interface Alert extends EObject {
	/**
	 * Returns the value of the '<em><b>Active period</b></em>' containment reference list.
	 * The list contents are of type {@link mapNotes.TimeRange}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Active period</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Active period</em>' containment reference list.
	 * @see mapNotes.MapNotesPackage#getAlert_Active_period()
	 * @model containment="true"
	 * @generated
	 */
	EList<TimeRange> getActive_period();

	/**
	 * Returns the value of the '<em><b>Informed entity</b></em>' containment reference list.
	 * The list contents are of type {@link mapNotes.EntitySelector}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Informed entity</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Informed entity</em>' containment reference list.
	 * @see mapNotes.MapNotesPackage#getAlert_Informed_entity()
	 * @model containment="true"
	 * @generated
	 */
	EList<EntitySelector> getInformed_entity();

	/**
	 * Returns the value of the '<em><b>Cause</b></em>' attribute.
	 * The literals are from the enumeration {@link mapNotes.Cause}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Cause</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cause</em>' attribute.
	 * @see mapNotes.Cause
	 * @see #setCause(Cause)
	 * @see mapNotes.MapNotesPackage#getAlert_Cause()
	 * @model
	 * @generated
	 */
	Cause getCause();

	/**
	 * Sets the value of the '{@link mapNotes.Alert#getCause <em>Cause</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Cause</em>' attribute.
	 * @see mapNotes.Cause
	 * @see #getCause()
	 * @generated
	 */
	void setCause(Cause value);

	/**
	 * Returns the value of the '<em><b>Effect</b></em>' attribute.
	 * The literals are from the enumeration {@link mapNotes.Effect}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Effect</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Effect</em>' attribute.
	 * @see mapNotes.Effect
	 * @see #setEffect(Effect)
	 * @see mapNotes.MapNotesPackage#getAlert_Effect()
	 * @model
	 * @generated
	 */
	Effect getEffect();

	/**
	 * Sets the value of the '{@link mapNotes.Alert#getEffect <em>Effect</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Effect</em>' attribute.
	 * @see mapNotes.Effect
	 * @see #getEffect()
	 * @generated
	 */
	void setEffect(Effect value);

	/**
	 * Returns the value of the '<em><b>Url</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Url</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Url</em>' attribute.
	 * @see #setUrl(String)
	 * @see mapNotes.MapNotesPackage#getAlert_Url()
	 * @model
	 * @generated
	 */
	String getUrl();

	/**
	 * Sets the value of the '{@link mapNotes.Alert#getUrl <em>Url</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Url</em>' attribute.
	 * @see #getUrl()
	 * @generated
	 */
	void setUrl(String value);

	/**
	 * Returns the value of the '<em><b>Header text</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Header text</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Header text</em>' attribute.
	 * @see #setHeader_text(String)
	 * @see mapNotes.MapNotesPackage#getAlert_Header_text()
	 * @model
	 * @generated
	 */
	String getHeader_text();

	/**
	 * Sets the value of the '{@link mapNotes.Alert#getHeader_text <em>Header text</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Header text</em>' attribute.
	 * @see #getHeader_text()
	 * @generated
	 */
	void setHeader_text(String value);

	/**
	 * Returns the value of the '<em><b>Description text</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Description text</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Description text</em>' attribute.
	 * @see #setDescription_text(String)
	 * @see mapNotes.MapNotesPackage#getAlert_Description_text()
	 * @model
	 * @generated
	 */
	String getDescription_text();

	/**
	 * Sets the value of the '{@link mapNotes.Alert#getDescription_text <em>Description text</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Description text</em>' attribute.
	 * @see #getDescription_text()
	 * @generated
	 */
	void setDescription_text(String value);

} // Alert
