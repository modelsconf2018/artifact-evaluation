/**
 */
package mapNotes.provider;


import java.util.Collection;
import java.util.List;

import mapNotes.MapNotesPackage;
import mapNotes.TrafficRemark;

import org.eclipse.emf.common.notify.AdapterFactory;
import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.edit.provider.ComposeableAdapterFactory;
import org.eclipse.emf.edit.provider.IItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ItemPropertyDescriptor;
import org.eclipse.emf.edit.provider.ViewerNotification;

/**
 * This is the item provider adapter for a {@link mapNotes.TrafficRemark} object.
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class TrafficRemarkItemProvider extends StatusRemarkItemProvider {
	/**
	 * This constructs an instance from a factory and a notifier.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public TrafficRemarkItemProvider(AdapterFactory adapterFactory) {
		super(adapterFactory);
	}

	/**
	 * This returns the property descriptors for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public List<IItemPropertyDescriptor> getPropertyDescriptors(Object object) {
		if (itemPropertyDescriptors == null) {
			super.getPropertyDescriptors(object);

			addWayIdPropertyDescriptor(object);
			addStartNodeIdPropertyDescriptor(object);
			addEndNodeIdPropertyDescriptor(object);
			addLonPropertyDescriptor(object);
			addLatPropertyDescriptor(object);
			addWhenPropertyDescriptor(object);
			addAppliesToPropertyDescriptor(object);
			addNextPointPropertyDescriptor(object);
			addNamePropertyDescriptor(object);
			addAverageSpeedPropertyDescriptor(object);
		}
		return itemPropertyDescriptors;
	}

	/**
	 * This adds a property descriptor for the Way Id feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addWayIdPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_TrafficRemark_wayId_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_TrafficRemark_wayId_feature", "_UI_TrafficRemark_type"),
				 MapNotesPackage.Literals.TRAFFIC_REMARK__WAY_ID,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Start Node Id feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addStartNodeIdPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_TrafficRemark_startNodeId_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_TrafficRemark_startNodeId_feature", "_UI_TrafficRemark_type"),
				 MapNotesPackage.Literals.TRAFFIC_REMARK__START_NODE_ID,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the End Node Id feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addEndNodeIdPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_TrafficRemark_endNodeId_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_TrafficRemark_endNodeId_feature", "_UI_TrafficRemark_type"),
				 MapNotesPackage.Literals.TRAFFIC_REMARK__END_NODE_ID,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Lon feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addLonPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_TrafficRemark_lon_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_TrafficRemark_lon_feature", "_UI_TrafficRemark_type"),
				 MapNotesPackage.Literals.TRAFFIC_REMARK__LON,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Lat feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addLatPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_TrafficRemark_lat_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_TrafficRemark_lat_feature", "_UI_TrafficRemark_type"),
				 MapNotesPackage.Literals.TRAFFIC_REMARK__LAT,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the When feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addWhenPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_TrafficRemark_when_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_TrafficRemark_when_feature", "_UI_TrafficRemark_type"),
				 MapNotesPackage.Literals.TRAFFIC_REMARK__WHEN,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Applies To feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addAppliesToPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_TrafficRemark_appliesTo_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_TrafficRemark_appliesTo_feature", "_UI_TrafficRemark_type"),
				 MapNotesPackage.Literals.TRAFFIC_REMARK__APPLIES_TO,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Next Point feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addNextPointPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_TrafficRemark_nextPoint_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_TrafficRemark_nextPoint_feature", "_UI_TrafficRemark_type"),
				 MapNotesPackage.Literals.TRAFFIC_REMARK__NEXT_POINT,
				 true,
				 false,
				 true,
				 null,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Name feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addNamePropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_TrafficRemark_name_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_TrafficRemark_name_feature", "_UI_TrafficRemark_type"),
				 MapNotesPackage.Literals.TRAFFIC_REMARK__NAME,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This adds a property descriptor for the Average Speed feature.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void addAverageSpeedPropertyDescriptor(Object object) {
		itemPropertyDescriptors.add
			(createItemPropertyDescriptor
				(((ComposeableAdapterFactory)adapterFactory).getRootAdapterFactory(),
				 getResourceLocator(),
				 getString("_UI_TrafficRemark_averageSpeed_feature"),
				 getString("_UI_PropertyDescriptor_description", "_UI_TrafficRemark_averageSpeed_feature", "_UI_TrafficRemark_type"),
				 MapNotesPackage.Literals.TRAFFIC_REMARK__AVERAGE_SPEED,
				 true,
				 false,
				 false,
				 ItemPropertyDescriptor.GENERIC_VALUE_IMAGE,
				 null,
				 null));
	}

	/**
	 * This returns TrafficRemark.gif.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getImage(Object object) {
		return overlayImage(object, getResourceLocator().getImage("full/obj16/TrafficRemark"));
	}

	/**
	 * This returns the label text for the adapted class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getText(Object object) {
		String label = ((TrafficRemark)object).getName();
		return label == null || label.length() == 0 ?
			getString("_UI_TrafficRemark_type") :
			getString("_UI_TrafficRemark_type") + " " + label;
	}
	

	/**
	 * This handles model notifications by calling {@link #updateChildren} to update any cached
	 * children and by creating a viewer notification, which it passes to {@link #fireNotifyChanged}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void notifyChanged(Notification notification) {
		updateChildren(notification);

		switch (notification.getFeatureID(TrafficRemark.class)) {
			case MapNotesPackage.TRAFFIC_REMARK__WAY_ID:
			case MapNotesPackage.TRAFFIC_REMARK__START_NODE_ID:
			case MapNotesPackage.TRAFFIC_REMARK__END_NODE_ID:
			case MapNotesPackage.TRAFFIC_REMARK__LON:
			case MapNotesPackage.TRAFFIC_REMARK__LAT:
			case MapNotesPackage.TRAFFIC_REMARK__WHEN:
			case MapNotesPackage.TRAFFIC_REMARK__APPLIES_TO:
			case MapNotesPackage.TRAFFIC_REMARK__NAME:
			case MapNotesPackage.TRAFFIC_REMARK__AVERAGE_SPEED:
				fireNotifyChanged(new ViewerNotification(notification, notification.getNotifier(), false, true));
				return;
		}
		super.notifyChanged(notification);
	}

	/**
	 * This adds {@link org.eclipse.emf.edit.command.CommandParameter}s describing the children
	 * that can be created under this object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected void collectNewChildDescriptors(Collection<Object> newChildDescriptors, Object object) {
		super.collectNewChildDescriptors(newChildDescriptors, object);
	}

}
